# ENGINE003-XPLAT-FIX001 successor replay

This archive is a frozen successor to the immutable replay object that failed
Windows run `31235015491`. Verify this archive's external SHA-256 sidecar and
then verify every entry in the root `SHA256SUMS` before execution.

From the extracted archive root, run unchanged:

```text
python -B dev/ENGINE003-PREFLIGHT/independent/check_xplat_newline_contract.py \
  --output NEWLINE_CONTRACT_RESULTS.tsv

python -B dev/ENGINE003-PREFLIGHT/independent/check_xplat_failure_diagnostics.py \
  --output FAILURE_DIAGNOSTIC_RESULTS.tsv

python -B dev/ENGINE003-PREFLIGHT/xplat/run_xplat_replay.py \
  --output-dir xplat_raw
```

On Windows, use `py -3 -B` in place of `python -B` and report the exact
invocation. Do not execute the Windows command until main control authorizes
the frozen successor object.

Success produces exactly these five replay outputs:

```text
xplat_raw/RUN_METADATA.json
xplat_raw/WIRE_REPLAY_RESULTS.tsv
xplat_raw/DESCRIPTOR_BYTE_CASE_RESULTS.tsv
xplat_raw/AUTHORITY_VECTOR_RESULTS.tsv
xplat_raw/SHA256SUMS
```

Preserve raw files byte-for-byte. If any run fails, stop without repair or
rerun and preserve the output directory, console log and any
`FAILURE_DIAGNOSTICS.json` / `FAILED_OBSERVED_*` artifacts. A byte/parser PASS
does not establish Windows `DURABLE_PUBLISH_V1`.
