#!/usr/bin/env python3
"""Capture fresh host resource inputs for the no-timing admission table."""

from __future__ import annotations

import argparse
import datetime
import json
import os
import platform
import re
import shutil
import socket
import subprocess
from pathlib import Path

from probe_durability_capabilities import filesystem_type


def command(argv: list[str]) -> str:
    value = subprocess.run(argv, check=True, capture_output=True, text=True)
    return value.stdout.strip()


def capture(destination: Path) -> dict[str, object]:
    if not destination.is_dir():
        raise ValueError("destination must be an existing directory")
    physical = int(command(["sysctl", "-n", "hw.memsize"]))
    pressure = command(["/usr/bin/memory_pressure", "-Q"])
    match = re.search(r"System-wide memory free percentage:\s*(\d+)%", pressure)
    if not match:
        raise ValueError("memory_pressure did not report a free percentage")
    disk = shutil.disk_usage(destination)
    statvfs = os.statvfs(destination)
    allocation_unit = statvfs.f_frsize or statvfs.f_bsize
    now = datetime.datetime.now(datetime.timezone.utc).astimezone().isoformat()
    return {
        "status": "FRESH_PRETIMING_RESOURCE_CAPTURE_PASS",
        "capture_time": now,
        "host_id": socket.gethostname(),
        "platform_system": platform.system(),
        "platform_release": platform.release(),
        "platform_machine": platform.machine(),
        "os_build": (
            f"macOS-{command(['sw_vers', '-productVersion'])}-"
            f"{command(['sw_vers', '-buildVersion'])}-Darwin-"
            f"{platform.release()}-{platform.machine()}"
        ),
        "filesystem": filesystem_type(destination),
        "destination": str(destination.resolve()),
        "physical_memory_bytes": physical,
        "observed_memory_free_percent": int(match.group(1)),
        "observed_available_memory_bytes": "NOT_EXACTLY_REPORTED_BY_OS",
        "admission_memory_ceiling_policy": "50_PERCENT_OF_PHYSICAL_MEMORY",
        "admission_memory_ceiling_bytes": physical // 2,
        "available_local_disk_bytes": disk.free,
        "disk_total_bytes": disk.total,
        "disk_used_bytes": disk.used,
        "allocation_unit_bytes": allocation_unit,
        "capture_commands": [
            "sysctl -n hw.memsize", "memory_pressure -Q", "shutil.disk_usage",
            "os.statvfs", "sw_vers", "platform", "socket.gethostname",
        ],
        "timing_executed": False,
        "backend_allocation_executed": False,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--destination", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    report = capture(args.destination)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps(report, sort_keys=True))


if __name__ == "__main__":
    main()
