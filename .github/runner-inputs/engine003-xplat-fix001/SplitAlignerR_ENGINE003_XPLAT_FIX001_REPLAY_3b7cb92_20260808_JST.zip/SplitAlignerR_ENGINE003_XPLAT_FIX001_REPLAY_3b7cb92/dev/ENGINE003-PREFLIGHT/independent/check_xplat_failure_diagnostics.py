#!/usr/bin/env python3
"""Exercise preservation and fields for XPLAT byte-mismatch diagnostics."""

from __future__ import annotations

import argparse
import importlib.util
import json
import tempfile
from pathlib import Path


SCRIPT = Path(__file__).resolve()
ROOT = SCRIPT.parents[1]


def load_replay_module():
    path = ROOT / "xplat" / "run_xplat_replay.py"
    spec = importlib.util.spec_from_file_location("engine003_xplat_replay", path)
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot load XPLAT replay module")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    replay = load_replay_module()
    with tempfile.TemporaryDirectory(prefix="e3-xplat-diagnostic-") as temporary:
        temp = Path(temporary)
        expected = temp / "expected.json"
        observed = temp / "observed.json"
        evidence = temp / "evidence"
        evidence.mkdir()
        expected.write_bytes(b"a\nb\n")
        observed.write_bytes(b"a\r\nb\n")
        try:
            replay.record_byte_mismatch(
                evidence, "diagnostic_probe", expected, observed, "descriptor"
            )
        except RuntimeError as error:
            message = str(error)
        else:
            raise RuntimeError("byte mismatch probe did not fail")
        diagnostic = json.loads(
            (evidence / "FAILURE_DIAGNOSTICS.json").read_bytes()
        )
        preserved = evidence / diagnostic["preserved_observed_path"]
        checks = {
            "case_id": diagnostic["case_id"] == "diagnostic_probe",
            "artifact_class": diagnostic["observed_artifact_class"] == "descriptor",
            "expected_length": diagnostic["expected_byte_length"] == 4,
            "observed_length": diagnostic["observed_byte_length"] == 5,
            "first_offset": diagnostic["first_differing_byte_offset"] == 1,
            "expected_no_cr": diagnostic["expected_contains_cr"] is False,
            "observed_has_cr": diagnostic["observed_contains_cr"] is True,
            "observed_crlf": diagnostic["observed_crlf_count"] == 1,
            "expected_sha": len(diagnostic["expected_sha256"]) == 64,
            "observed_sha": len(diagnostic["observed_sha256"]) == 64,
            "expected_excerpt": diagnostic["expected_excerpt"]["hex"] == b"a\nb\n".hex(),
            "observed_excerpt": diagnostic["observed_excerpt"]["hex"] == b"a\r\nb\n".hex(),
            "observed_preserved": preserved.read_bytes() == b"a\r\nb\n",
            "message_complete": all(
                token in message for token in (
                    "case=diagnostic_probe", "class=descriptor",
                    "expected_len=4", "observed_len=5", "first_offset=1",
                    "observed_cr=True", "observed_crlf=1", "preserved=",
                )
            ),
        }
    rows = ["check\tresult"] + [
        f"{name}\t{'PASS' if passed else 'FAIL'}"
        for name, passed in checks.items()
    ]
    raw = ("\n".join(rows) + "\n").encode("utf-8")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_bytes(raw)
    failed = [name for name, passed in checks.items() if not passed]
    if failed:
        raise RuntimeError("diagnostic checks failed: " + ",".join(failed))
    print(json.dumps({
        "status": "XPLAT_FAILURE_DIAGNOSTICS_PASS",
        "passed": len(checks),
        "failed": 0,
    }, sort_keys=True))


if __name__ == "__main__":
    main()
