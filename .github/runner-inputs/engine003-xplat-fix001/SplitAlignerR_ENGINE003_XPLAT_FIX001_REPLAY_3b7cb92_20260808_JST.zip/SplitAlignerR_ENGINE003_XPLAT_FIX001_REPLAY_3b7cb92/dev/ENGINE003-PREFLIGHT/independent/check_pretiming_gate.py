#!/usr/bin/env python3
"""Independent shape/identity checker for pre-timing gate evidence."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path


CASES = {"tiny_correctness", "catnip10_like", "tile_boundary_257"}
V3_CASES = {"tiny_correctness", "catnip10_like"}
ADMISSION_CASES = {
    "tiny_correctness", "catnip10_like", "authority_shape", "moderate_churn",
}
BACKENDS = {
    "COMPACT_IN_MEMORY", "ROW_MAJOR_DISK", "COLUMN_MAJOR_DISK", "TILED_DISK",
}
EXPECTED_V3 = {
    "tiny_correctness": (
        "36f4fa3bca88a6490bfc67d936f9b0167b6f90e0ba711fd7b942a21a4281997c",
        "b5a92c2c982330a69a27539432de46865c0b40ccf71fdea646667f5cc6142a03",
        "29ccc16616d83cf19761d3131e62a768dc5169668d6c952890609893db859d8e",
    ),
    "catnip10_like": (
        "227bece88355fddb428924d6e76ad0b45b3051c140e97cab7b71f0886d10886c",
        "9bd2644882e40b6916e67c81a45d018be396c480e81383a07bb95139ab8d6ccd",
        "195f1af662bf558f104b9836985852b3030e3034098d7f5096a18c0a89f0e266",
    ),
}


def load_tsv(path: Path):
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--allocation", required=True, type=Path)
    parser.add_argument("--prototype", required=True, type=Path)
    parser.add_argument("--resources", required=True, type=Path)
    parser.add_argument("--admission", required=True, type=Path)
    args = parser.parse_args()

    allocation = json.loads(args.allocation.read_text(encoding="utf-8"))
    if allocation.get("timing_executed") is not False:
        raise AssertionError("allocation timing flag")
    if allocation.get("all_required_backends_supported") is not True:
        raise AssertionError("allocation aggregate")
    if set(allocation.get("cases", {})) != {"COLUMN_MAJOR_DISK", "TILED_DISK"}:
        raise AssertionError("allocation backend set")
    for value in allocation["cases"].values():
        if value["status"] != "PASS" or not value["all_logical_bytes_verified_zero"]:
            raise AssertionError("allocation case status")
        if len(value["snapshots"]) != 3:
            raise AssertionError("allocation phase count")
        for phase in value["snapshots"][1:]:
            if (phase["logical_length_bytes"] != value["requested_bytes"] or
                    phase["physical_allocated_bytes"] < value["requested_bytes"] or
                    phase["seek_extent_status"] != "PASS_NO_HOLE"):
                raise AssertionError("allocation physical/no-hole evidence")

    prototypes = load_tsv(args.prototype)
    if len(prototypes) != len(CASES) * len(BACKENDS):
        raise AssertionError("prototype row count")
    if {(row["case_id"], row["backend"]) for row in prototypes} != {
        (case, backend) for case in CASES for backend in BACKENDS
    }:
        raise AssertionError("prototype case/backend grid")
    for row in prototypes:
        if (row["status"] != "PASS" or row["timing_executed"] != "FALSE" or
                row["production_store_published"] != "FALSE"):
            raise AssertionError("prototype status boundary")
        if int(row["sequential_row_writes_verified"]) != int(row["rows"]):
            raise AssertionError("prototype row writes")
        if int(row["row_reads_verified"]) != int(row["rows"]):
            raise AssertionError("prototype row reads")
    for case in CASES:
        values = [row for row in prototypes if row["case_id"] == case]
        for key in (
            "state_stream_sha256", "numeric_stream_sha256",
            "validity_stream_sha256", "logical_content_sha256",
        ):
            if len({row[key] for row in values}) != 1:
                raise AssertionError(f"prototype {case} {key} differs")
        if case in V3_CASES:
            observed = tuple(values[0][key] for key in (
                "state_stream_sha256", "numeric_stream_sha256",
                "validity_stream_sha256",
            ))
            if observed != EXPECTED_V3[case]:
                raise AssertionError(f"prototype {case} frozen V3 identity")

    resources = json.loads(args.resources.read_text(encoding="utf-8"))
    if (resources.get("status") != "FRESH_PRETIMING_RESOURCE_CAPTURE_PASS" or
            resources.get("timing_executed") is not False or
            resources.get("backend_allocation_executed") is not False):
        raise AssertionError("resource capture boundary")
    if resources["admission_memory_ceiling_bytes"] != resources["physical_memory_bytes"] // 2:
        raise AssertionError("resource ceiling policy")

    admission = load_tsv(args.admission)
    if len(admission) != len(ADMISSION_CASES) * len(BACKENDS):
        raise AssertionError("admission row count")
    if {(row["case_id"], row["backend"]) for row in admission} != {
        (case, backend) for case in ADMISSION_CASES for backend in BACKENDS
    }:
        raise AssertionError("admission case/backend grid")
    for row in admission:
        if (row["execution_admission"] != "PASS" or
                row["proposal_status"] != "EXECUTION_ADMISSION_PASS_BUT_TIMING_SUSPENDED" or
                row["timing_executed"] != "FALSE" or
                row["allocation_or_backend_mutation_executed"] != "FALSE"):
            raise AssertionError("admission status boundary")
        if row["capture_time"] != resources["capture_time"]:
            raise AssertionError("admission capture identity")
        if int(row["available_local_disk_bytes"]) != resources["available_local_disk_bytes"]:
            raise AssertionError("admission disk capture")
        if int(row["admission_memory_ceiling_bytes"]) != resources["admission_memory_ceiling_bytes"]:
            raise AssertionError("admission memory capture")
        if row["backend"] in {"COLUMN_MAJOR_DISK", "TILED_DISK"}:
            if (row["allocation_capabilities_ok"] != "TRUE" or
                    not row["physical_allocation_capability"].startswith("PASS:")):
                raise AssertionError("admission allocation binding")
    print("PRETIMING_GATE_EVIDENCE_PASS 4/4 NO_TIMING")


if __name__ == "__main__":
    main()
