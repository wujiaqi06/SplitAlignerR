#!/usr/bin/env python3
"""Regression guard for canonical LF-only ENGINE003 XPLAT artifacts."""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
import tempfile
from pathlib import Path


SCRIPT = Path(__file__).resolve()
ROOT = SCRIPT.parents[1]
FIXTURES = ROOT / "fixtures"
REFERENCE = ROOT / "reference"

CASES = (
    ("tiny", "tiny", "registry_input.json"),
    ("zero_rows", "tiny", "zero_rows_registry.json"),
    ("zero_columns", "tiny", "zero_columns_registry.json"),
    ("raw_ff", "tiny", "raw_ff_registry.json"),
    ("one_cell", "boundary", "one_cell_registry.json"),
    ("exact_256", "boundary", "exact_256_registry.json"),
    ("multi_257", "boundary", "multi_257_registry.json"),
    ("bstar_u32le", "boundary", "bstar_u32le_registry.json"),
)

PORTABLE_WRITERS = (
    REFERENCE / "canonical_text.py",
    REFERENCE / "encode_tiny_fixture.py",
    REFERENCE / "encode_boundary_fixture.py",
    REFERENCE / "run_encoder_authority_cases.py",
    ROOT / "independent" / "check_bounded_store.py",
    ROOT / "independent" / "run_descriptor_byte_cases.py",
    ROOT / "xplat" / "run_xplat_replay.py",
)

TINY_LENGTH = 860
TINY_SHA256 = "de8261bff01cbbb1880413438ed97e19f28fad954eaed6fd9476efee973b4866"


def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def generate(case_id: str, kind: str, store: Path, descriptor: Path) -> None:
    script = "encode_tiny_fixture.py" if kind == "tiny" else "encode_boundary_fixture.py"
    command = [
        sys.executable, "-B", str(REFERENCE / script), "--profile", case_id,
        "--store", str(store), "--registry", str(descriptor),
    ]
    result = subprocess.run(
        command, check=False, capture_output=True, text=True, timeout=180
    )
    if result.returncode != 0:
        raise RuntimeError(
            f"descriptor regeneration failed: {case_id} rc={result.returncode}\n"
            f"stdout:\n{result.stdout}\nstderr:\n{result.stderr}"
        )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    rows = ["case\texpected_bytes\texpected_sha256\tcontains_cr\tresult"]
    with tempfile.TemporaryDirectory(prefix="e3-newline-contract-") as temporary:
        temp = Path(temporary)
        for case_id, kind, committed_name in CASES:
            observed_store = temp / case_id / "store"
            observed_descriptor = temp / case_id / "descriptor.json"
            generate(case_id, kind, observed_store, observed_descriptor)
            expected = (FIXTURES / committed_name).read_bytes()
            observed = observed_descriptor.read_bytes()
            contains_cr = b"\r" in observed
            passed = expected == observed and not contains_cr
            if case_id == "tiny":
                passed = (
                    passed and len(observed) == TINY_LENGTH
                    and sha(observed) == TINY_SHA256
                )
            rows.append(
                f"{case_id}\t{len(observed)}\t{sha(observed)}\t"
                f"{'TRUE' if contains_cr else 'FALSE'}\t"
                f"{'PASS' if passed else 'FAIL'}"
            )
            if not passed:
                raise RuntimeError(f"canonical descriptor mismatch: {case_id}")

    forbidden = (".write_text(", '.open("w"', ".open('w'")
    for path in PORTABLE_WRITERS:
        source = path.read_text(encoding="utf-8")
        matches = [value for value in forbidden if value in source]
        passed = not matches
        rows.append(
            f"source_guard:{path.relative_to(ROOT).as_posix()}\tNA\tNA\tNA\t"
            f"{'PASS' if passed else 'FAIL'}"
        )
        if not passed:
            raise RuntimeError(
                f"host-default text writer in portable path: {path}: {matches}"
            )

    raw = ("\n".join(rows) + "\n").encode("utf-8")
    if b"\r" in raw:
        raise RuntimeError("newline regression output contains CR")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_bytes(raw)
    print(json.dumps({
        "status": "XPLAT_NEWLINE_CONTRACT_PASS",
        "descriptor_cases": len(CASES),
        "source_guards": len(PORTABLE_WRITERS),
        "tiny_length": TINY_LENGTH,
        "tiny_sha256": TINY_SHA256,
    }, sort_keys=True))


if __name__ == "__main__":
    main()
