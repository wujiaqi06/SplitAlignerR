#!/usr/bin/env python3
"""Bounded non-production checker for ENGINE003-PREFLIGHT tiled stores.

This is deliberately separate from ``check_tiny_store.py``.  It never
materializes a complete matrix or logical stream.  The POSIX mode uses opened
regular-file descriptors; the portable mode is diagnostic byte replay only and
must not be presented as a safe store-open or durability result.
"""

from __future__ import annotations

import argparse
import bisect
import hashlib
import json
import math
import os
import stat
import struct
import sys
from pathlib import Path

from descriptor_bytes_v1 import DescriptorBytesError, parse_descriptor_bytes


TILE_ROWS = 256
TILE_COLS = 256
HEADER_BYTES = 256
ENTRY_BYTES = 128
FOOTER_BYTES = 512
READ_CHUNK = 1024 * 1024
U64_MAX = (1 << 64) - 1
DESCRIPTOR_CAP = 8 * 1024 * 1024
MANIFEST_CAP = 8 * 1024
PUBLISHED_NAMES = (
    "STATE.bin", "NUMERIC.bin", "VALIDITY.bin", "TILE_INDEX.bin",
    "COMPLETION.bin", "VALIDATED",
)
PREPUBLICATION_NAMES = PUBLISHED_NAMES[:-1]
STATE_MAPPED = 0
STATE_NA_FUSE = 2
STATE_NA_TOPO = 3
ALGORITHM = "MULTIPASS_ROW_SEGMENT_V1"


class ValidationError(Exception):
    def __init__(self, code: str, detail: str):
        detail = str(detail).encode("ascii", "backslashreplace")[:384].decode("ascii")
        super().__init__(f"{code}: {detail}")
        self.code = code


def fail(code: str, detail: str) -> None:
    raise ValidationError(code, detail)


def checked_add(left: int, right: int, label: str) -> int:
    value = left + right
    if value > U64_MAX:
        fail("E3_OVERFLOW", label)
    return value


def checked_mul(left: int, right: int, label: str) -> int:
    value = left * right
    if value > U64_MAX:
        fail("E3_OVERFLOW", label)
    return value


def ceil_div(value: int, divisor: int) -> int:
    return divmod(value, divisor)[0] + int(value % divisor != 0)


def le16(value: bytes, offset: int) -> int:
    return struct.unpack_from("<H", value, offset)[0]


def le32(value: bytes, offset: int) -> int:
    return struct.unpack_from("<I", value, offset)[0]


def le64(value: bytes, offset: int) -> int:
    return struct.unpack_from("<Q", value, offset)[0]


def enc16(value: int) -> bytes:
    return struct.pack("<H", value)


def enc32(value: int) -> bytes:
    return struct.pack("<I", value)


def enc64(value: int) -> bytes:
    return struct.pack("<Q", value)


def sized(value: bytes) -> bytes:
    return enc64(len(value)) + value


def digest(value: bytes) -> bytes:
    return hashlib.sha256(value).digest()


def require_zero(value: bytes, start: int, end: int, label: str) -> None:
    if any(value[start:end]):
        fail("E3_RESERVED_NONZERO", label)


def bounded_directory_names(values) -> tuple[str, ...]:
    """Collect at most the six names admitted by the published grammar."""
    output = []
    for item in values:
        output.append(item.name if hasattr(item, "name") else item)
        if len(output) > len(PUBLISHED_NAMES):
            fail("E3_UNDECLARED_ENTRY", "more than six directory entries")
    return tuple(sorted(output))


class StoreSource:
    """Small read-at interface with exact byte-accounting."""

    mode = "ABSTRACT"

    def __init__(self) -> None:
        self.bytes_streamed = 0

    def names(self) -> tuple[str, ...]:
        raise NotImplementedError

    def size(self, name: str) -> int:
        raise NotImplementedError

    def read_at(self, name: str, offset: int, length: int) -> bytes:
        raise NotImplementedError

    def close(self) -> None:
        pass

    def final_barrier(self) -> None:
        pass

    def stream_hash(self, name: str) -> str:
        hasher = hashlib.sha256()
        size = self.size(name)
        offset = 0
        while offset < size:
            chunk = self.read_at(name, offset, min(READ_CHUNK, size - offset))
            hasher.update(chunk)
            offset += len(chunk)
        return hasher.hexdigest()


def open_directory_chain_posix(path: Path) -> int:
    required = ("O_NOFOLLOW", "O_CLOEXEC", "O_NONBLOCK", "O_DIRECTORY")
    if any(not hasattr(os, name) for name in required):
        fail("E3_PLATFORM", "POSIX directory traversal primitives unavailable")
    flags = os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK | os.O_DIRECTORY
    try:
        if path.is_absolute():
            current = os.open("/", flags)
            parts = path.parts[1:]
        else:
            current = os.open(".", flags)
            parts = path.parts
    except OSError as error:
        fail("E3_STORE_PATH", error)
    for part in parts:
        if part in ("", "."):
            continue
        if part == "..":
            os.close(current)
            fail("E3_STORE_PATH", "parent traversal forbidden")
        try:
            following = os.open(part, flags, dir_fd=current)
        except OSError as error:
            os.close(current)
            fail("E3_STORE_PATH", f"no-follow traversal at {part}: {error}")
        os.close(current)
        current = following
    return current


class PortableReplaySource(StoreSource):
    """Platform-neutral trusted-fixture replay; not a store acceptance path."""

    mode = "PORTABLE_TRUSTED_BYTE_REPLAY_ONLY"

    def __init__(self, root: Path):
        super().__init__()
        self.root = root
        if not root.is_dir():
            fail("E3_STORE_PATH", "portable replay root is not a directory")
        self._names = bounded_directory_names(root.iterdir())
        self._sizes = {}
        for name in self._names:
            path = root / name
            if path.is_symlink() or not path.is_file():
                fail("E3_NOT_REGULAR", name)
            self._sizes[name] = path.stat().st_size

    def names(self) -> tuple[str, ...]:
        return self._names

    def size(self, name: str) -> int:
        return self._sizes[name]

    def read_at(self, name: str, offset: int, length: int) -> bytes:
        if offset < 0 or length < 0 or offset + length > self.size(name):
            fail("E3_LENGTH", f"portable bounded read {name}")
        with (self.root / name).open("rb") as handle:
            handle.seek(offset)
            value = handle.read(length)
        if len(value) != length:
            fail("E3_LENGTH", f"short portable read {name}")
        self.bytes_streamed += len(value)
        return value


class PosixSafeSource(StoreSource):
    """POSIX no-follow store source retaining all component descriptors."""

    mode = "POSIX_SAFE_OPENED_DESCRIPTOR_STORE"

    def __init__(self, root: Path):
        super().__init__()
        required = ("O_NOFOLLOW", "O_CLOEXEC", "O_NONBLOCK", "O_DIRECTORY")
        missing = [item for item in required if not hasattr(os, item)]
        if missing or not hasattr(os, "pread"):
            fail("E3_PLATFORM", "POSIX safe-open primitives unavailable")
        flags = os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK
        self.directory = open_directory_chain_posix(root)
        before = os.fstat(self.directory)
        if not stat.S_ISDIR(before.st_mode):
            os.close(self.directory)
            fail("E3_STORE_PATH", "opened store is not a directory")
        self.directory_identity = (before.st_dev, before.st_ino)
        with os.scandir(self.directory) as entries:
            self._names = bounded_directory_names(entries)
        self.fds: dict[str, int] = {}
        self.identities: dict[str, tuple[int, int, int]] = {}
        try:
            for name in self._names:
                try:
                    fd = os.open(name, flags, dir_fd=self.directory)
                except OSError as error:
                    fail("E3_SYMLINK_OR_OPEN", f"{name}: {error}")
                info = os.fstat(fd)
                if not stat.S_ISREG(info.st_mode):
                    os.close(fd)
                    fail("E3_NOT_REGULAR", name)
                self.fds[name] = fd
                self.identities[name] = (info.st_dev, info.st_ino, info.st_size)
        except Exception:
            self.close()
            raise

    def names(self) -> tuple[str, ...]:
        return self._names

    def size(self, name: str) -> int:
        return self.identities[name][2]

    def read_at(self, name: str, offset: int, length: int) -> bytes:
        if offset < 0 or length < 0 or offset + length > self.size(name):
            fail("E3_LENGTH", f"POSIX bounded read {name}")
        value = os.pread(self.fds[name], length, offset)
        if len(value) != length:
            fail("E3_LENGTH", f"short POSIX read {name}")
        self.bytes_streamed += len(value)
        return value

    def final_barrier(self) -> None:
        with os.scandir(self.directory) as entries:
            current = bounded_directory_names(entries)
        if current != self._names:
            fail("E3_DIRECTORY_CHANGED", "directory name set changed")
        flags = os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK
        for name, expected in self.identities.items():
            try:
                reopened = os.open(name, flags, dir_fd=self.directory)
            except OSError as error:
                fail("E3_DIRECTORY_CHANGED", f"{name}: {error}")
            try:
                info = os.fstat(reopened)
                observed = (info.st_dev, info.st_ino, info.st_size)
            finally:
                os.close(reopened)
            if observed != expected or not stat.S_ISREG(info.st_mode):
                fail("E3_DIRECTORY_CHANGED", name)

    def close(self) -> None:
        for fd in getattr(self, "fds", {}).values():
            try:
                os.close(fd)
            except OSError:
                pass
        self.fds = {}
        if hasattr(self, "directory"):
            try:
                os.close(self.directory)
            except OSError:
                pass
            del self.directory


def read_descriptor(path: Path, portable: bool) -> tuple[dict, int, object]:
    """Descriptor byte parse. POSIX mode refuses symlink/nonregular input."""
    if portable:
        if path.is_symlink() or not path.is_file():
            fail("E3_DESCRIPTOR", "portable descriptor is not a regular file")
        size = path.stat().st_size
        if size > DESCRIPTOR_CAP:
            fail("E3_DESCRIPTOR_LIMIT", "descriptor exceeds 8 MiB")
        raw = path.read_bytes()
        snapshot = None
    else:
        flags = os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK
        parent = open_directory_chain_posix(path.parent)
        try:
            fd = os.open(path.name, flags, dir_fd=parent)
        except OSError as error:
            os.close(parent)
            fail("E3_DESCRIPTOR", error)
        try:
            info = os.fstat(fd)
            if not stat.S_ISREG(info.st_mode):
                fail("E3_DESCRIPTOR", "descriptor is not regular")
            if info.st_size > DESCRIPTOR_CAP:
                fail("E3_DESCRIPTOR_LIMIT", "descriptor exceeds 8 MiB")
            raw = os.read(fd, info.st_size)
            if len(raw) != info.st_size:
                fail("E3_DESCRIPTOR", "short descriptor read")
            snapshot = (
                path.parent, path.name, info.st_dev, info.st_ino, info.st_size,
                info.st_mtime_ns, info.st_ctime_ns,
            )
        finally:
            os.close(fd)
            os.close(parent)
    try:
        return parse_descriptor_bytes(raw), len(raw), snapshot
    except DescriptorBytesError as error:
        fail(error.code, str(error))


def verify_descriptor_snapshot(snapshot: object) -> None:
    if snapshot is None:
        return
    parent_path, name, *expected = snapshot
    parent = open_directory_chain_posix(parent_path)
    flags = os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK
    try:
        fd = os.open(name, flags, dir_fd=parent)
    except OSError as error:
        os.close(parent)
        fail("E3_DIRECTORY_CHANGED", f"descriptor: {error}")
    try:
        info = os.fstat(fd)
        observed = [
            info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns,
            info.st_ctime_ns,
        ]
    finally:
        os.close(fd)
        os.close(parent)
    if observed != expected or not stat.S_ISREG(info.st_mode):
        fail("E3_DIRECTORY_CHANGED", "descriptor binding changed")


def exact_hex(value: str, label: str, allow_empty: bool = False) -> bytes:
    if not isinstance(value, str) or len(value) % 2:
        fail("E3_DESCRIPTOR", f"{label} hex grammar")
    if not allow_empty and not value:
        fail("E3_DESCRIPTOR", f"{label} empty")
    if any(item not in "0123456789abcdef" for item in value):
        fail("E3_DESCRIPTOR", f"{label} noncanonical hex")
    return bytes.fromhex(value)


def authority_digests(registry: dict) -> dict[str, object]:
    """Independent registry validation and canonical digest reconstruction."""
    taxa_input = registry["taxon_label_bytes_hex"]
    primitives = registry["primitive_entries"]
    if not taxa_input or len(taxa_input) > 0xFFFFFFFF or len(primitives) > 0xFFFFFFFF:
        fail("E3_AUTHORITY", "taxon/primitive count")
    taxa = []
    seen_taxa = set()
    for index, value in enumerate(taxa_input):
        raw = exact_hex(value, f"taxon {index}")
        if raw in seen_taxa:
            fail("E3_AUTHORITY", "duplicate taxon")
        seen_taxa.add(raw)
        taxa.append(raw)
    species_stream = bytearray(b"SplitAlignerR/SpeciesAuthority/v1\0")
    species_stream += enc32(len(taxa)) + enc32(len(primitives))
    for taxon_id, raw in enumerate(taxa):
        species_stream += enc32(taxon_id) + sized(raw)
    width = ceil_div(len(taxa), 8)
    all_mask = (1 << len(taxa)) - 1
    terminals = []
    for primitive_id, item in enumerate(primitives):
        split = exact_hex(item["authority_edge_split_hex"], "split", allow_empty=False)
        if len(split) != width:
            fail("E3_AUTHORITY", "split width")
        used = len(taxa) % 8 or 8
        if split[-1] & ~((1 << used) - 1):
            fail("E3_AUTHORITY", "split padding")
        terminal = item["terminal"]
        taxon_id = item["terminal_taxon_id"]
        if not isinstance(terminal, bool) or not isinstance(taxon_id, int) or isinstance(taxon_id, bool):
            fail("E3_AUTHORITY", "primitive scalar type")
        if not 0 <= taxon_id <= 0xFFFFFFFF:
            fail("E3_AUTHORITY", "terminal taxon range")
        selected = int.from_bytes(split, "little")
        if terminal:
            if taxon_id >= len(taxa) or selected != 1 << taxon_id:
                fail("E3_AUTHORITY", "terminal singleton")
        else:
            complement = all_mask ^ selected
            if taxon_id != 0xFFFFFFFF or not selected or not complement:
                fail("E3_AUTHORITY", "internal primitive")
            left_count = selected.bit_count() if hasattr(int, "bit_count") else bin(selected).count("1")
            right_count = complement.bit_count() if hasattr(int, "bit_count") else bin(complement).count("1")
            if left_count > right_count or (
                left_count == right_count and split > complement.to_bytes(width, "little")
            ):
                fail("E3_AUTHORITY", "internal canonical side")
        terminals.append(terminal)
        species_stream += enc32(primitive_id) + bytes([int(terminal)]) + bytes(3)
        species_stream += enc32(taxon_id) + sized(split)
    species = digest(species_stream)

    gene_ids = registry["gene_ids"]
    gene_stream = bytearray(b"SplitAlignerR/GeneRegistry/v1\0") + enc64(len(gene_ids))
    seen_genes = set()
    for index, gene in enumerate(gene_ids):
        if not isinstance(gene, str):
            fail("E3_REGISTRY", "gene ID type")
        try:
            raw = gene.encode("utf-8")
        except UnicodeError:
            fail("E3_REGISTRY", "invalid gene UTF-8")
        if not raw or b"\0" in raw or raw in seen_genes:
            fail("E3_REGISTRY", "gene ID grammar/duplicate")
        seen_genes.add(raw)
        gene_stream += enc64(index) + sized(raw)
    genes = digest(gene_stream)

    members = registry["bstar_members"]
    encoded_members = []
    normalized_members = []
    for item in members:
        if (not isinstance(item, list) or len(item) < 2 or
                any(not isinstance(x, int) or isinstance(x, bool) for x in item) or
                item != sorted(set(item)) or item[0] < 0 or item[-1] >= len(primitives)):
            fail("E3_REGISTRY", "B* member set")
        raw = b"".join(enc32(value) for value in item)
        encoded_members.append(raw)
        normalized_members.append(tuple(item))
    if encoded_members != sorted(encoded_members) or len(set(encoded_members)) != len(encoded_members):
        fail("E3_REGISTRY", "B* canonical order")
    bstar_stream = bytearray(b"SplitAlignerR/BStarRegistry/v1\0")
    bstar_stream += species + enc64(len(encoded_members))
    for index, raw in enumerate(encoded_members):
        bstar_stream += enc64(index) + sized(raw)
    bstar = digest(bstar_stream)
    numeric_stream = bytearray(b"SplitAlignerR/NumericCoordinateRegistry/v1\0")
    numeric_stream += species + enc64(len(primitives)) + bstar + enc64(len(encoded_members))
    for index, raw in enumerate(encoded_members):
        numeric_stream += enc64(index) + sized(raw)
    numeric = digest(numeric_stream)
    return {
        "species": species, "primitive": species, "genes": genes,
        "bstar": bstar, "numeric": numeric, "terminals": terminals,
        "members": normalized_members,
    }


def parse_manifest(raw: bytes) -> dict[str, str]:
    if not raw.endswith(b"\n") or b"\r" in raw or raw.startswith(b"\xef\xbb\xbf"):
        fail("E3_MANIFEST_GRAMMAR", "line ending/BOM")
    try:
        lines = raw.decode("ascii")[:-1].split("\n")
    except UnicodeDecodeError:
        fail("E3_MANIFEST_GRAMMAR", "non-ASCII")
    keys = [
        "magic", "manifest_schema_major", "manifest_schema_minor", "completion_state",
        "store_schema", "layout", "tile_rows", "tile_columns", "row_count",
        "primitive_count", "bstar_count", "numeric_coordinate_count",
        "species_authority_sha256", "gene_registry_sha256", "primitive_registry_sha256",
        "bstar_registry_sha256", "numeric_coordinate_registry_sha256",
        "logical_content_sha256", "state_component", "state_bytes", "state_sha256",
        "numeric_component", "numeric_bytes", "numeric_sha256", "validity_component",
        "validity_bytes", "validity_sha256", "index_component", "index_bytes",
        "index_sha256", "footer_component", "footer_bytes", "footer_sha256",
        "publication_timestamp_policy",
    ]
    if len(lines) != len(keys):
        fail("E3_MANIFEST_GRAMMAR", "key count")
    result = {}
    for expected, line in zip(keys, lines):
        if "=" not in line:
            fail("E3_MANIFEST_GRAMMAR", "missing equals")
        key, value = line.split("=", 1)
        if key != expected or not value or value != value.strip():
            fail("E3_MANIFEST_GRAMMAR", expected)
        result[key] = value
    fixed = {
        "magic": "SplitAlignerR-MatrixStore-VALIDATED", "manifest_schema_major": "1",
        "manifest_schema_minor": "0", "completion_state": "VALIDATED",
        "store_schema": "1.0-candidate", "layout": "tiled_row_major_provisional",
        "tile_rows": "256", "tile_columns": "256", "state_component": "STATE.bin",
        "numeric_component": "NUMERIC.bin", "validity_component": "VALIDITY.bin",
        "index_component": "TILE_INDEX.bin", "footer_component": "COMPLETION.bin",
        "footer_bytes": "512", "publication_timestamp_policy": "OMITTED_V1",
    }
    for key, value in fixed.items():
        if result[key] != value:
            fail("E3_MANIFEST_VALUE", key)
    for key in (
        "row_count", "primitive_count", "bstar_count",
        "numeric_coordinate_count", "state_bytes", "numeric_bytes",
        "validity_bytes", "index_bytes",
    ):
        value = result[key]
        if not value.isdigit() or (len(value) > 1 and value[0] == "0"):
            fail("E3_MANIFEST_GRAMMAR", f"canonical decimal {key}")
        if len(value) > 20 or (len(value) == 20 and value > str(U64_MAX)):
            fail("E3_OVERFLOW", key)
    for key in (
        "species_authority_sha256", "gene_registry_sha256",
        "primitive_registry_sha256", "bstar_registry_sha256",
        "numeric_coordinate_registry_sha256", "logical_content_sha256",
        "state_sha256", "numeric_sha256", "validity_sha256",
        "index_sha256", "footer_sha256",
    ):
        value = result[key]
        if len(value) != 64 or any(ch not in "0123456789abcdef" for ch in value):
            fail("E3_MANIFEST_GRAMMAR", f"lowercase digest {key}")
    return result


def parse_data_header(source: StoreSource, name: str, magic: bytes, component: int,
                      columns_digest: bytes, authority: dict[str, object]) -> dict[str, int]:
    raw = source.read_at(name, 0, HEADER_BYTES)
    if raw[:8] != magic or (le16(raw, 8), le16(raw, 10), le16(raw, 12), le16(raw, 14)) != (1, 0, 256, component):
        fail("E3_HEADER", name)
    if raw[16:20] != bytes([1, 1, component, 0]) or le32(raw, 20) != 256 or le32(raw, 24) != 256:
        fail("E3_HEADER", f"encoding/geometry {name}")
    require_zero(raw, 28, 32, "data header 28")
    require_zero(raw, 104, 128, "data header 104")
    require_zero(raw, 224, 256, "data header 224")
    rows, columns = le64(raw, 32), le64(raw, 40)
    row_tiles, column_tiles, count = le64(raw, 48), le64(raw, 56), le64(raw, 64)
    if row_tiles != (ceil_div(rows, 256) if rows else 0) or column_tiles != (ceil_div(columns, 256) if columns else 0):
        fail("E3_GEOMETRY", name)
    if count != checked_mul(row_tiles, column_tiles, "tile count"):
        fail("E3_GEOMETRY", name)
    tile_bytes = {1: 65536, 2: 524288, 3: 8192}[component]
    payload = checked_mul(count, tile_bytes, "component payload")
    exact = checked_add(HEADER_BYTES, payload, "component length")
    if le64(raw, 72) != tile_bytes or le64(raw, 80) != 256 or le64(raw, 88) != payload or le64(raw, 96) != exact or source.size(name) != exact:
        fail("E3_LENGTH", name)
    if raw[128:160] != authority["species"] or raw[160:192] != authority["genes"] or raw[192:224] != columns_digest:
        fail("E3_AUTHORITY", name)
    return {"component": component, "rows": rows, "columns": columns,
            "row_tiles": row_tiles, "column_tiles": column_tiles,
            "tile_count": count, "tile_bytes": tile_bytes}


def parse_index_header(source: StoreSource, authority: dict[str, object]) -> dict[str, int]:
    raw = source.read_at("TILE_INDEX.bin", 0, HEADER_BYTES)
    if raw[:8] != b"SARIX001" or (le16(raw, 8), le16(raw, 10), le16(raw, 12), le16(raw, 14)) != (1, 0, 256, 4):
        fail("E3_INDEX", "header")
    if raw[16:18] != b"\x01\x01" or le32(raw, 20) != ENTRY_BYTES:
        fail("E3_INDEX", "header encoding")
    require_zero(raw, 18, 20, "index header 18")
    require_zero(raw, 240, 256, "index header 240")
    count = le64(raw, 24)
    expected_bytes = checked_add(
        HEADER_BYTES, checked_mul(count, ENTRY_BYTES, "index entry bytes"),
        "index component bytes",
    )
    if le64(raw, 32) != expected_bytes or source.size("TILE_INDEX.bin") != expected_bytes:
        fail("E3_LENGTH", "index")
    if le32(raw, 72) != 256 or le32(raw, 76) != 256:
        fail("E3_INDEX", "tile geometry")
    expected = (authority["species"], authority["genes"], authority["primitive"], authority["bstar"], authority["numeric"])
    observed = (raw[80:112], raw[112:144], raw[144:176], raw[176:208], raw[208:240])
    if observed != expected:
        fail("E3_AUTHORITY", "index")
    return {"count": count, "rows": le64(raw, 40), "primitive": le64(raw, 48),
            "bstar": le64(raw, 56), "numeric": le64(raw, 64)}


def entry_position(headers: dict[int, dict[str, int]], component: int,
                   tile_row: int, tile_column: int) -> int:
    position = 0
    for prior in range(1, component):
        position += headers[prior]["tile_count"]
    return position + tile_row * headers[component]["column_tiles"] + tile_column


def parse_entry(source: StoreSource, headers: dict[int, dict[str, int]], component: int,
                tile_row: int, tile_column: int) -> dict[str, object]:
    position = entry_position(headers, component, tile_row, tile_column)
    raw = source.read_at("TILE_INDEX.bin", HEADER_BYTES + position * ENTRY_BYTES, ENTRY_BYTES)
    header = headers[component]
    row_start, column_start = tile_row * 256, tile_column * 256
    row_extent = min(256, header["rows"] - row_start)
    column_extent = min(256, header["columns"] - column_start)
    offset = HEADER_BYTES + (tile_row * header["column_tiles"] + tile_column) * header["tile_bytes"]
    if (le16(raw, 0), le16(raw, 2), le64(raw, 8), le64(raw, 16)) != (component, 1, tile_row, tile_column):
        fail("E3_INDEX_ORDER", position)
    require_zero(raw, 4, 8, "entry 4")
    require_zero(raw, 74, 80, "entry 74")
    require_zero(raw, 112, 128, "entry 112")
    if (le64(raw, 24), le64(raw, 32), le32(raw, 40), le32(raw, 44)) != (row_start, column_start, row_extent, column_extent):
        fail("E3_INDEX", f"logical geometry {position}")
    if (le64(raw, 48), le64(raw, 56), le32(raw, 64), le32(raw, 68), le16(raw, 72)) != (offset, header["tile_bytes"], 256, 256, component):
        fail("E3_INDEX", f"physical geometry {position}")
    return {"position": position, "offset": offset, "row_extent": row_extent,
            "column_extent": column_extent, "sha256": raw[80:112]}


def validate_physical_tiles(source: StoreSource, headers: dict[int, dict[str, int]]) -> tuple[int, int]:
    checked = 0
    max_tile = 0
    names = {1: "STATE.bin", 2: "NUMERIC.bin", 3: "VALIDITY.bin"}
    for component in (1, 2, 3):
        header = headers[component]
        for tile_row in range(header["row_tiles"]):
            for tile_column in range(header["column_tiles"]):
                entry = parse_entry(source, headers, component, tile_row, tile_column)
                payload = source.read_at(names[component], entry["offset"], header["tile_bytes"])
                max_tile = max(max_tile, len(payload))
                if digest(payload) != entry["sha256"]:
                    fail("E3_TILE_HASH", entry["position"])
                row_extent = entry["row_extent"]
                column_extent = entry["column_extent"]
                for local_row in range(256):
                    for local_column in range(256):
                        logical = local_row < row_extent and local_column < column_extent
                        cell = local_row * 256 + local_column
                        if component == 1:
                            value = payload[cell]
                            if logical and value > 3:
                                fail("E3_STATE", value)
                            if not logical and value:
                                fail("E3_PADDING", "state")
                        elif component == 2:
                            value = payload[cell * 8:cell * 8 + 8]
                            if not logical and value != bytes(8):
                                fail("E3_PADDING", "numeric")
                        elif not logical and payload[cell // 8] & (1 << (cell % 8)):
                            fail("E3_PADDING", "validity")
                checked += 1
    return checked, max_tile


def read_scalar_segment(source: StoreSource, header: dict[str, int], name: str,
                        row: int, start: int, count: int, width: int) -> bytes:
    output = bytearray()
    remaining = count
    cursor = start
    while remaining:
        tile_row, local_row = divmod(row, 256)
        tile_column, local_column = divmod(cursor, 256)
        take = min(remaining, 256 - local_column)
        tile_offset = HEADER_BYTES + (tile_row * header["column_tiles"] + tile_column) * header["tile_bytes"]
        offset = tile_offset + (local_row * 256 + local_column) * width
        output += source.read_at(name, offset, take * width)
        cursor += take
        remaining -= take
    return bytes(output)


def read_validity_segment(source: StoreSource, header: dict[str, int], row: int,
                          start: int, count: int) -> tuple[bytes, int]:
    output = bytearray(ceil_div(count, 8))
    remaining, cursor, target_bit, source_bytes = count, start, 0, 0
    while remaining:
        tile_row, local_row = divmod(row, 256)
        tile_column, local_column = divmod(cursor, 256)
        take = min(remaining, 256 - local_column)
        first_byte = local_column // 8
        bit_offset = local_column % 8
        byte_count = ceil_div(bit_offset + take, 8)
        tile_offset = HEADER_BYTES + (tile_row * header["column_tiles"] + tile_column) * header["tile_bytes"]
        raw = source.read_at("VALIDITY.bin", tile_offset + local_row * 32 + first_byte, byte_count)
        source_bytes += len(raw)
        for bit in range(take):
            if raw[(bit_offset + bit) // 8] & (1 << ((bit_offset + bit) % 8)):
                output[target_bit // 8] |= 1 << (target_bit % 8)
            target_bit += 1
        cursor += take
        remaining -= take
    return bytes(output), source_bytes


def bit_is_set(raw: bytes, index: int) -> bool:
    return bool(raw[index // 8] & (1 << (index % 8)))


def validate_standard_semantics(source: StoreSource, headers: dict[int, dict[str, int]],
                                authority: dict[str, object]) -> dict[str, int]:
    rows = headers[1]["rows"]
    primitive = headers[1]["columns"]
    numeric = headers[2]["columns"]
    terminals = authority["terminals"]
    checked_numeric = checked_primitive = 0
    max_live = 0
    for row in range(rows):
        for start in range(0, numeric, 256):
            count = min(256, numeric - start)
            numeric_raw = read_scalar_segment(source, headers[2], "NUMERIC.bin", row, start, count, 8)
            validity, _ = read_validity_segment(source, headers[3], row, start, count)
            state_count = max(0, min(count, primitive - start)) if start < primitive else 0
            state = (read_scalar_segment(source, headers[1], "STATE.bin", row, start, state_count, 1)
                     if state_count else b"")
            max_live = max(max_live, len(numeric_raw) + len(validity) + len(state))
            for local in range(count):
                valid = bit_is_set(validity, local)
                bits = numeric_raw[local * 8:local * 8 + 8]
                if valid:
                    if not math.isfinite(struct.unpack("<d", bits)[0]):
                        fail("E3_NUMERIC", f"row {row} coordinate {start + local}")
                elif bits != bytes(8):
                    fail("E3_NUMERIC", "invalid payload not +0.0")
                checked_numeric += 1
            for local, state_value in enumerate(state):
                primitive_id = start + local
                if state_value > 3:
                    fail("E3_STATE", state_value)
                if state_value != STATE_MAPPED and bit_is_set(validity, local):
                    fail("E3_PRIMITIVE_ROW_CONSISTENCY", "non-Mapped available")
                if terminals[primitive_id] and state_value == STATE_NA_TOPO:
                    fail("E3_PRIMITIVE_ROW_CONSISTENCY", "terminal NA_topo")
                checked_primitive += 1
    return {"checked_numeric_cells": checked_numeric,
            "checked_primitive_cells": checked_primitive,
            "max_standard_buffers_bytes": max_live}


def validate_composites(source: StoreSource, headers: dict[int, dict[str, int]],
                        authority: dict[str, object]) -> dict[str, int]:
    rows = headers[1]["rows"]
    primitive = headers[1]["columns"]
    members = authority["members"]
    bstar = len(members)
    primitive_segments = validity_rescans = registry_probes = 0
    checked_members = active = source_validity_bytes = 0
    max_live = 0
    for row in range(rows):
        for start in range(0, primitive, 256):
            count = min(256, primitive - start)
            state = read_scalar_segment(source, headers[1], "STATE.bin", row, start, count, 1)
            occupied = bytearray(ceil_div(count, 8))
            primitive_segments += 1
            for window_start in range(0, bstar, 256):
                window_count = min(256, bstar - window_start)
                validity, read_bytes = read_validity_segment(
                    source, headers[3], row, primitive + window_start, window_count
                )
                source_validity_bytes += read_bytes
                validity_rescans += 1
                max_live = max(max_live, len(state) + len(occupied) + len(validity))
                for local_bstar in range(window_count):
                    bstar_id = window_start + local_bstar
                    registry_probes += 1
                    if not bit_is_set(validity, local_bstar):
                        continue
                    active += 1
                    fiber = members[bstar_id]
                    left = bisect.bisect_left(fiber, start)
                    right = bisect.bisect_left(fiber, start + count, left)
                    for member in fiber[left:right]:
                        local = member - start
                        if state[local] != STATE_NA_FUSE:
                            fail("E3_COMPOSITE_ROW_CONSISTENCY", "active B* non-NA_fuse")
                        if occupied[local // 8] & (1 << (local % 8)):
                            fail("E3_COMPOSITE_ROW_CONSISTENCY", "active B* overlap")
                        occupied[local // 8] |= 1 << (local % 8)
                        checked_members += 1
    return {"primitive_segment_count": primitive_segments,
            "bstar_validity_window_rescans": validity_rescans,
            "registry_probes": registry_probes, "active_bstar_segment_visits": active,
            "checked_composite_members": checked_members,
            "bstar_validity_source_bytes": source_validity_bytes,
            "max_composite_buffers_bytes": max_live}


class ContinuousBits:
    def __init__(self, hasher):
        self.hasher = hasher
        self.current = 0
        self.used = 0
        self.bytes = 0

    def add(self, value: bool) -> None:
        if value:
            self.current |= 1 << self.used
        self.used += 1
        if self.used == 8:
            self.hasher.update(bytes([self.current]))
            self.bytes += 1
            self.current = self.used = 0

    def finish(self) -> None:
        if self.used:
            self.hasher.update(bytes([self.current]))
            self.bytes += 1
            self.current = self.used = 0


def reconstruct_logical_hash(source: StoreSource, headers: dict[int, dict[str, int]],
                             authority: dict[str, object]) -> tuple[str, int]:
    rows, primitive = headers[1]["rows"], headers[1]["columns"]
    numeric, bstar = headers[2]["columns"], len(authority["members"])
    hasher = hashlib.sha256()
    hasher.update(b"SplitAlignerR/MatrixLogicalContent/v1\0")
    hasher.update(enc16(1) + enc16(0) + enc64(rows) + enc64(primitive) + enc64(bstar) + enc64(numeric))
    for key in ("species", "genes", "primitive", "bstar", "numeric"):
        hasher.update(authority[key])
    state_length = checked_mul(rows, primitive, "logical state length")
    hasher.update(enc64(state_length))
    max_buffer = 0
    for row in range(rows):
        for start in range(0, primitive, 256):
            value = read_scalar_segment(source, headers[1], "STATE.bin", row, start, min(256, primitive - start), 1)
            max_buffer = max(max_buffer, len(value))
            hasher.update(value)
    numeric_length = checked_mul(checked_mul(rows, numeric, "numeric cells"), 8, "numeric bytes")
    hasher.update(enc64(numeric_length))
    for row in range(rows):
        for start in range(0, numeric, 256):
            value = read_scalar_segment(source, headers[2], "NUMERIC.bin", row, start, min(256, numeric - start), 8)
            max_buffer = max(max_buffer, len(value))
            hasher.update(value)
    validity_length = ceil_div(checked_mul(rows, numeric, "validity cells"), 8)
    hasher.update(enc64(validity_length))
    packer = ContinuousBits(hasher)
    for row in range(rows):
        for start in range(0, numeric, 256):
            count = min(256, numeric - start)
            value, _ = read_validity_segment(source, headers[3], row, start, count)
            max_buffer = max(max_buffer, len(value) + 1)
            for bit in range(count):
                packer.add(bit_is_set(value, bit))
    packer.finish()
    if packer.bytes != validity_length:
        fail("E3_LOGICAL_HASH", "validity packer length")
    return hasher.hexdigest(), max_buffer


def parse_footer(source: StoreSource, physical: dict[str, str], logical: str,
                 authority: dict[str, object], dimensions: tuple[int, int, int, int]) -> None:
    if source.size("COMPLETION.bin") != FOOTER_BYTES:
        fail("E3_FOOTER", "length")
    raw = source.read_at("COMPLETION.bin", 0, FOOTER_BYTES)
    if raw[:8] != b"SARFT001" or (le16(raw, 8), le16(raw, 10), le16(raw, 12), le16(raw, 14), le32(raw, 16)) != (1, 0, 512, 0, 4):
        fail("E3_FOOTER", "header")
    require_zero(raw, 20, 32, "footer 20")
    require_zero(raw, 426, 512, "footer 426")
    names = ("STATE.bin", "NUMERIC.bin", "VALIDITY.bin", "TILE_INDEX.bin")
    for index, name in enumerate(names):
        if le64(raw, 32 + index * 8) != source.size(name) or raw[64 + index * 32:96 + index * 32].hex() != physical[name]:
            fail("E3_FOOTER", name)
    if raw[192:224].hex() != logical:
        fail("E3_LOGICAL_HASH", "footer")
    expected = (authority["species"], authority["genes"], authority["primitive"], authority["bstar"], authority["numeric"])
    observed = (raw[224:256], raw[256:288], raw[288:320], raw[320:352], raw[352:384])
    if observed != expected or tuple(le64(raw, offset) for offset in (384, 392, 400, 408)) != dimensions:
        fail("E3_FOOTER", "authority/dimensions")
    if le32(raw, 416) != 256 or le32(raw, 420) != 256 or le16(raw, 424) != 1:
        fail("E3_FOOTER", "layout")


def peak_rss() -> tuple[object, str]:
    try:
        import resource
        value = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        if sys.platform == "darwin":
            return int(value), "getrusage_ru_maxrss_bytes"
        return int(value) * 1024, "getrusage_ru_maxrss_kib_converted_to_bytes"
    except (ImportError, AttributeError, OSError):
        return "NOT_MEASURED", "NOT_AVAILABLE_ON_RUNTIME"


def validate(store: Path, descriptor: Path, portable: bool,
             phase: str = "PUBLISHED_STORE") -> dict[str, object]:
    if phase not in {"PREPUBLICATION_BYTES", "PUBLISHED_STORE"}:
        fail("E3_PHASE", phase)
    source: StoreSource = PortableReplaySource(store) if portable else PosixSafeSource(store)
    passes = []
    try:
        selected_names = (
            PUBLISHED_NAMES if phase == "PUBLISHED_STORE" else PREPUBLICATION_NAMES
        )
        if (phase == "PUBLISHED_STORE" and
                source.names() == tuple(sorted(PREPUBLICATION_NAMES))):
            fail("E3_INCOMPLETE", "VALIDATED missing in published phase")
        if source.names() != tuple(sorted(selected_names)):
            fail("E3_UNDECLARED_ENTRY", ",".join(source.names()))
        passes.append("directory_grammar")
        registry, descriptor_bytes, descriptor_snapshot = read_descriptor(
            descriptor, portable
        )
        authority = authority_digests(registry)
        passes.append("external_authority")
        physical = {name: source.stream_hash(name) for name in selected_names}
        passes.append("physical_hashes")
        manifest = None
        if phase == "PUBLISHED_STORE":
            if source.size("VALIDATED") > MANIFEST_CAP:
                fail("E3_MANIFEST_GRAMMAR", "manifest exceeds 8 KiB")
            manifest = parse_manifest(
                source.read_at("VALIDATED", 0, source.size("VALIDATED"))
            )
            passes.append("manifest_grammar")
        headers = {
            1: parse_data_header(source, "STATE.bin", b"SARST001", 1, authority["primitive"], authority),
            2: parse_data_header(source, "NUMERIC.bin", b"SARNM001", 2, authority["numeric"], authority),
            3: parse_data_header(source, "VALIDITY.bin", b"SARVL001", 3, authority["numeric"], authority),
        }
        rows, primitive, bstar = len(registry["gene_ids"]), len(registry["primitive_entries"]), len(registry["bstar_members"])
        numeric = primitive + bstar
        if any(header["rows"] != rows for header in headers.values()) or headers[1]["columns"] != primitive or headers[2]["columns"] != numeric or headers[3]["columns"] != numeric:
            fail("E3_GEOMETRY", "descriptor versus components")
        index_header = parse_index_header(source, authority)
        if (index_header["rows"], index_header["primitive"], index_header["bstar"], index_header["numeric"]) != (rows, primitive, bstar, numeric):
            fail("E3_INDEX", "dimensions")
        if index_header["count"] != sum(header["tile_count"] for header in headers.values()):
            fail("E3_INDEX", "entry count")
        passes.append("headers_and_index")
        tiles, max_tile = validate_physical_tiles(source, headers)
        passes.append("tile_bytes")
        standard = validate_standard_semantics(source, headers, authority)
        passes.append("standard_semantics")
        composite = validate_composites(source, headers, authority)
        passes.append("multipass_composite")
        logical, logical_buffer = reconstruct_logical_hash(source, headers, authority)
        passes.append("logical_hash")
        parse_footer(source, physical, logical, authority, (rows, primitive, bstar, numeric))
        if manifest is not None:
            digest_keys = {
                "species_authority_sha256": "species", "gene_registry_sha256": "genes",
                "primitive_registry_sha256": "primitive", "bstar_registry_sha256": "bstar",
                "numeric_coordinate_registry_sha256": "numeric",
            }
            for manifest_key, authority_key in digest_keys.items():
                if manifest[manifest_key] != authority[authority_key].hex():
                    fail("E3_MANIFEST_VALUE", manifest_key)
            if manifest["logical_content_sha256"] != logical:
                fail("E3_MANIFEST_VALUE", "logical hash")
            component_fields = {
                "STATE.bin": ("state_bytes", "state_sha256"),
                "NUMERIC.bin": ("numeric_bytes", "numeric_sha256"),
                "VALIDITY.bin": ("validity_bytes", "validity_sha256"),
                "TILE_INDEX.bin": ("index_bytes", "index_sha256"),
                "COMPLETION.bin": ("footer_bytes", "footer_sha256"),
            }
            for name, (size_key, hash_key) in component_fields.items():
                if int(manifest[size_key]) != source.size(name) or manifest[hash_key] != physical[name]:
                    fail("E3_MANIFEST_VALUE", name)
            if tuple(int(manifest[key]) for key in ("row_count", "primitive_count", "bstar_count", "numeric_coordinate_count")) != (rows, primitive, bstar, numeric):
                fail("E3_MANIFEST_VALUE", "dimensions")
        passes.append("footer_and_bindings")
        source.final_barrier()
        verify_descriptor_snapshot(descriptor_snapshot)
        passes.append("acceptance_barrier")
        rss, rss_method = peak_rss()
        max_semantic = max(standard["max_standard_buffers_bytes"],
                           composite["max_composite_buffers_bytes"], logical_buffer)
        return {
            "status": (
                "BOUNDED_PREFLIGHT_CHECKER_PASS" if phase == "PUBLISHED_STORE"
                else "BOUNDED_PREFLIGHT_PREPUBLICATION_BYTES_PASS"
            ),
            "phase": phase,
            "checker_role": "NON_PRODUCTION_PREFLIGHT_ONLY",
            "input_mode": source.mode,
            "portable_mode_limit": ("NOT_A_SAFE_STORE_OPEN_OR_DURABILITY_RESULT" if portable else "NOT_APPLICABLE"),
            "algorithm": ALGORITHM,
            "pass_count": len(passes),
            "required_pass_count": 11 if phase == "PUBLISHED_STORE" else 10,
            "passes": passes, "rows": rows, "primitive_count": primitive,
            "bstar_count": bstar, "numeric_coordinate_count": numeric,
            "descriptor_bytes": descriptor_bytes, "bytes_streamed": source.bytes_streamed,
            "physical_hash_passes": len(selected_names), "logical_hash_passes": 1,
            "logical_source_streams": 3, "physical_tile_count": tiles,
            "maximum_physical_tile_buffer_bytes": max_tile,
            "maximum_live_semantic_validation_buffers_bytes": max_semantic,
            "maximum_live_validation_buffers_bytes": max(
                READ_CHUNK, max_tile, max_semantic, ENTRY_BYTES
            ),
            "decoded_index_window_bytes": ENTRY_BYTES, "hash_io_buffer_bytes": READ_CHUNK,
            "logical_content_sha256": logical, "physical_sha256": physical,
            "peak_rss_bytes": rss, "peak_rss_method": rss_method,
            **standard, **composite,
        }
    finally:
        source.close()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--store", required=True, type=Path)
    parser.add_argument("--descriptor", required=True, type=Path)
    parser.add_argument("--portable-trusted-byte-replay", action="store_true")
    parser.add_argument(
        "--phase", choices=("PREPUBLICATION_BYTES", "PUBLISHED_STORE"),
        default="PUBLISHED_STORE",
    )
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    try:
        result = validate(
            args.store, args.descriptor, args.portable_trusted_byte_replay,
            args.phase,
        )
    except ValidationError as error:
        print(str(error), file=sys.stderr)
        raise SystemExit(1)
    rendered = json.dumps(result, indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_bytes(rendered.encode("utf-8"))
    print(rendered, end="")


if __name__ == "__main__":
    main()
