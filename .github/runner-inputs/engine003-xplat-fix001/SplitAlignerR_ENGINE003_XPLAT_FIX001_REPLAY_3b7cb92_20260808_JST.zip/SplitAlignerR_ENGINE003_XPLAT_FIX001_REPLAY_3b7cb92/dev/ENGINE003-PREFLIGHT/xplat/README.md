# Platform-neutral replay

Run from any checkout of the reviewed commit with standard-library Python:

```text
python -B dev/ENGINE003-PREFLIGHT/xplat/run_xplat_replay.py \
  --output-dir <new-empty-output-directory>
```

The command performs no timing and writes five evidence files. The output
directory must not already exist. Preserve it byte-for-byte and report the
runtime, commit and external run identifier alongside its `SHA256SUMS`.

Portable text output is an exact byte contract. Descriptor JSON is
`UTF-8(json.dumps(value, indent=2))` followed by one byte `0x0a`. Replay TSV,
JSON and `SHA256SUMS` outputs are likewise emitted as explicit bytes with LF
line endings; host-default text newline translation is not permitted.

On a byte mismatch the replay stops, preserves the observed artifact in the
output directory and writes `FAILURE_DIAGNOSTICS.json` with the case, expected
path, artifact class, expected/observed length and SHA-256, first differing
offset, CR/CRLF status and bounded hex excerpts. Failure diagnostics do not
weaken or replace exact byte equality.

This replay intentionally uses `PORTABLE_TRUSTED_BYTE_REPLAY_ONLY`. It proves
golden fixture identity, parser vectors, logical-hash reconstruction and wire
byte equality. It does not prove safe opening of an untrusted store, filesystem
publication atomicity, crash durability, or Windows `DURABLE_PUBLISH_V1`.

Required platform rows for the checkpoint are Linux, macOS and Windows. Do not
merge their raw outputs or convert a missing row to PASS.
