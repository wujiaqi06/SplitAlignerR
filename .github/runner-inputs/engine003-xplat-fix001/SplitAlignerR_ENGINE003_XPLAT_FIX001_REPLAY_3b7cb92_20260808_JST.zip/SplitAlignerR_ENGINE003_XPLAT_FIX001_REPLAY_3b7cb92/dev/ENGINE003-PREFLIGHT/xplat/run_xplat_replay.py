#!/usr/bin/env python3
"""Platform-neutral ENGINE003 byte/parser replay (diagnostic evidence only)."""

from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import os
import platform
import subprocess
import sys
import tempfile
from pathlib import Path


SCRIPT = Path(__file__).resolve()
ROOT = SCRIPT.parents[1]
FIXTURES = ROOT / "fixtures"
INDEPENDENT = ROOT / "independent"
REFERENCE = ROOT / "reference"

FIXTURE_CASES = (
    ("tiny", "tiny", "tiny_store", "registry_input.json", "tiny"),
    ("zero_rows", "tiny", "zero_rows_store", "zero_rows_registry.json", "zero_rows"),
    ("zero_columns", "tiny", "zero_columns_store", "zero_columns_registry.json", "zero_columns"),
    ("raw_ff", "tiny", "raw_ff_store", "raw_ff_registry.json", "raw_ff"),
    ("one_cell", "boundary", "one_cell_store", "one_cell_registry.json", "one_cell"),
    ("exact_256", "boundary", "exact_256_store", "exact_256_registry.json", "exact_256"),
    ("multi_257", "boundary", "multi_257_store", "multi_257_registry.json", "multi_257"),
    ("bstar_u32le", "boundary", "bstar_u32le_store", "bstar_u32le_registry.json", "bstar_u32le"),
)


def sha256(path: Path) -> str:
    hasher = hashlib.sha256()
    with path.open("rb") as handle:
        while True:
            value = handle.read(1024 * 1024)
            if not value:
                break
            hasher.update(value)
    return hasher.hexdigest()


def run(command: list[str], timeout: int = 180) -> subprocess.CompletedProcess:
    result = subprocess.run(
        command, check=False, capture_output=True, text=True, timeout=timeout,
        env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"},
    )
    if result.returncode != 0:
        raise RuntimeError(
            f"command failed rc={result.returncode}: {' '.join(command)}\n"
            f"stdout:\n{result.stdout}\nstderr:\n{result.stderr}"
        )
    return result


def verify_fixture_manifest() -> tuple[int, str]:
    manifest = FIXTURES / "FIXTURE_SHA256SUMS"
    checked = 0
    for line in manifest.read_text(encoding="ascii").splitlines():
        expected, relative = line.split("  ", 1)
        path = FIXTURES / relative
        if not path.is_file() or sha256(path) != expected:
            raise RuntimeError(f"fixture manifest mismatch: {relative}")
        checked += 1
    return checked, sha256(manifest)


def first_difference(left: bytes, right: bytes) -> int:
    for offset, (left_byte, right_byte) in enumerate(zip(left, right)):
        if left_byte != right_byte:
            return offset
    return min(len(left), len(right))


def mismatch_excerpt(raw: bytes, offset: int, radius: int = 24) -> dict[str, object]:
    start = max(0, offset - radius)
    end = min(len(raw), offset + radius)
    return {"start": start, "end": end, "hex": raw[start:end].hex()}


def record_byte_mismatch(
    output: Path, case_id: str, expected_path: Path, observed_path: Path,
    artifact_class: str,
) -> None:
    expected = expected_path.read_bytes()
    observed = observed_path.read_bytes()
    offset = first_difference(expected, observed)
    suffix = observed_path.suffix or ".bin"
    preserved_name = f"FAILED_OBSERVED_{case_id}_{artifact_class}{suffix}"
    preserved = output / preserved_name
    preserved.write_bytes(observed)
    diagnostic = {
        "status": "XPLAT_BYTE_MISMATCH",
        "case_id": case_id,
        "expected_path": str(expected_path),
        "observed_artifact_class": artifact_class,
        "preserved_observed_path": preserved_name,
        "expected_byte_length": len(expected),
        "observed_byte_length": len(observed),
        "expected_sha256": hashlib.sha256(expected).hexdigest(),
        "observed_sha256": hashlib.sha256(observed).hexdigest(),
        "first_differing_byte_offset": offset,
        "expected_contains_cr": b"\r" in expected,
        "observed_contains_cr": b"\r" in observed,
        "expected_crlf_count": expected.count(b"\r\n"),
        "observed_crlf_count": observed.count(b"\r\n"),
        "expected_excerpt": mismatch_excerpt(expected, offset),
        "observed_excerpt": mismatch_excerpt(observed, offset),
    }
    (output / "FAILURE_DIAGNOSTICS.json").write_bytes(
        (json.dumps(diagnostic, indent=2, sort_keys=True) + "\n").encode("utf-8")
    )
    raise RuntimeError(
        "byte mismatch: "
        f"case={case_id} class={artifact_class} expected={expected_path} "
        f"expected_len={len(expected)} observed_len={len(observed)} "
        f"expected_sha256={diagnostic['expected_sha256']} "
        f"observed_sha256={diagnostic['observed_sha256']} "
        f"first_offset={offset} observed_cr={diagnostic['observed_contains_cr']} "
        f"observed_crlf={diagnostic['observed_crlf_count']} "
        f"preserved={preserved}"
    )


def compare_tree(
    expected: Path, observed: Path, case_id: str, failure_output: Path
) -> tuple[int, str]:
    expected_files = sorted(
        path.relative_to(expected).as_posix() for path in expected.rglob("*") if path.is_file()
    )
    observed_files = sorted(
        path.relative_to(observed).as_posix() for path in observed.rglob("*") if path.is_file()
    )
    if expected_files != observed_files:
        raise RuntimeError("regenerated wire-format file set mismatch")
    hasher = hashlib.sha256()
    for relative in expected_files:
        left, right = expected / relative, observed / relative
        if left.read_bytes() != right.read_bytes():
            record_byte_mismatch(
                failure_output, case_id, left, right,
                "wire_" + relative.replace("/", "_").replace(".", "_"),
            )
        hasher.update(relative.encode("utf-8") + b"\0" + bytes.fromhex(sha256(left)))
    return len(expected_files), hasher.hexdigest()


def write_tsv(path: Path, rows: list[dict[str, object]]) -> None:
    handle = io.StringIO(newline="")
    writer = csv.DictWriter(
        handle, fieldnames=list(rows[0]), delimiter="\t", lineterminator="\n"
    )
    writer.writeheader()
    writer.writerows(rows)
    raw = handle.getvalue().encode("utf-8")
    if b"\r" in raw:
        raise RuntimeError(f"portable TSV renderer emitted CR: {path.name}")
    path.write_bytes(raw)


def generate_case(kind: str, profile: str, store: Path, descriptor: Path) -> None:
    if kind == "tiny":
        command = [
            sys.executable, "-B", str(REFERENCE / "encode_tiny_fixture.py"),
            "--profile", profile, "--store", str(store), "--registry", str(descriptor),
        ]
    else:
        command = [
            sys.executable, "-B", str(REFERENCE / "encode_boundary_fixture.py"),
            "--profile", profile, "--store", str(store), "--registry", str(descriptor),
        ]
    run(command)


def replay_case(case_id: str, kind: str, committed_store: str,
                committed_descriptor: str, profile: str, temp: Path,
                failure_output: Path) -> dict[str, object]:
    regenerated_root = temp / case_id
    regenerated_store = regenerated_root / "store"
    regenerated_descriptor = regenerated_root / "descriptor.json"
    generate_case(kind, profile, regenerated_store, regenerated_descriptor)
    expected_store = FIXTURES / committed_store
    expected_descriptor = FIXTURES / committed_descriptor
    count, aggregate = compare_tree(
        expected_store, regenerated_store, case_id, failure_output
    )
    if expected_descriptor.read_bytes() != regenerated_descriptor.read_bytes():
        record_byte_mismatch(
            failure_output, case_id, expected_descriptor,
            regenerated_descriptor, "descriptor",
        )
    checker_output = temp / f"{case_id}_bounded_checker.json"
    run([
        sys.executable, "-B", str(INDEPENDENT / "check_bounded_store.py"),
        "--store", str(expected_store), "--descriptor", str(expected_descriptor),
        "--portable-trusted-byte-replay", "--output", str(checker_output),
    ])
    result = json.loads(checker_output.read_text(encoding="utf-8"))
    if result["status"] != "BOUNDED_PREFLIGHT_CHECKER_PASS" or result["pass_count"] != 11:
        raise RuntimeError(f"bounded checker did not pass: {case_id}")
    return {
        "case_id": case_id,
        "fixture_manifest_status": "PASS",
        "regenerated_wire_bytes": "IDENTICAL",
        "compared_store_files": count,
        "wire_aggregate_sha256": aggregate,
        "descriptor_bytes": "IDENTICAL",
        "descriptor_sha256": sha256(expected_descriptor),
        "logical_reconstruction": "PASS",
        "logical_content_sha256": result["logical_content_sha256"],
        "bounded_checker_passes": result["pass_count"],
        "checker_input_mode": result["input_mode"],
        "durability_claim": "NONE_PORTABLE_REPLAY_ONLY",
    }


def make_sha256sums(output: Path) -> int:
    paths = sorted(
        path for path in output.iterdir()
        if path.is_file() and path.name != "SHA256SUMS"
    )
    text = "".join(f"{sha256(path)}  {path.name}\n" for path in paths)
    (output / "SHA256SUMS").write_bytes(text.encode("ascii"))
    return len(paths)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", required=True, type=Path)
    args = parser.parse_args()
    if args.output_dir.exists():
        raise SystemExit("refusing to overwrite an existing replay output directory")
    args.output_dir.mkdir(parents=True)
    fixture_count, fixture_manifest_sha = verify_fixture_manifest()
    with tempfile.TemporaryDirectory(prefix="e3-xplat-replay-") as temporary:
        temp = Path(temporary)
        rows = [replay_case(*case, temp, args.output_dir) for case in FIXTURE_CASES]
        write_tsv(args.output_dir / "WIRE_REPLAY_RESULTS.tsv", rows)
        run([
            sys.executable, "-B", str(INDEPENDENT / "run_descriptor_byte_cases.py"),
            "--output", str(args.output_dir / "DESCRIPTOR_BYTE_CASE_RESULTS.tsv"),
            "--python", sys.executable,
        ])
        validity = run([
            sys.executable, "-B", str(INDEPENDENT / "check_validity_vectors.py"),
            str(FIXTURES / "validity_vectors.tsv"),
        ])
        authority = run([
            sys.executable, "-B", str(REFERENCE / "run_encoder_authority_cases.py"),
            "--output", str(args.output_dir / "AUTHORITY_VECTOR_RESULTS.tsv"),
        ])
    metadata = {
        "status": "XPLAT_BYTE_PARSER_REPLAY_PASS",
        "evidence_scope": "HOSTED_OR_LOCAL_DIAGNOSTIC_NOT_DURABILITY_CERTIFICATION",
        "platform": platform.platform(),
        "system": platform.system(),
        "machine": platform.machine(),
        "python_implementation": platform.python_implementation(),
        "python_version": platform.python_version(),
        "fixture_manifest_sha256": fixture_manifest_sha,
        "fixture_manifest_entries_verified": fixture_count,
        "wire_cases_passed": len(rows),
        "wire_cases_failed": 0,
        "descriptor_byte_corpus": "PASS",
        "validity_vectors": validity.stdout.strip(),
        "authority_vectors": authority.stdout.strip(),
        "logical_hash_reconstruction": "PASS_ALL_WIRE_CASES",
        "wire_format_byte_equality": "PASS_ALL_WIRE_CASES",
        "windows_durability_interpretation": (
            "A_WINDOWS_REPLAY_PASS_DOES_NOT_ESTABLISH_DURABLE_PUBLISH_V1"
        ),
        "timing_executed": False,
    }
    (args.output_dir / "RUN_METADATA.json").write_bytes(
        (json.dumps(metadata, indent=2, sort_keys=True) + "\n").encode("utf-8")
    )
    count = make_sha256sums(args.output_dir)
    print(json.dumps({**metadata, "evidence_files_hashed": count}, sort_keys=True))


if __name__ == "__main__":
    main()
