# SplitAlignerR ENGINE003 VALIDATION/XPLAT replay

Frozen source identity:

```text
commit: 278192993c6bf2ae4d93b46bf9e8195aaf39f1a3
tree:   4df515d8f9de64290b811065568f13642534eb19
parent: be70d18019b356ded89c443847e094f818f60bb9
```

This package uses only standard-library Python. From this directory, run one
fresh platform-specific output directory:

```text
python -B dev/ENGINE003-PREFLIGHT/xplat/run_xplat_replay.py \
  --output-dir XPLAT_EVIDENCE_<PLATFORM>_<RUN_ID>
```

On Windows, `py -3` may replace `python` if that is the configured CPython
launcher. The output directory must not already exist. Preserve all five output
files, the printed JSON record, the exact command, runtime version, OS/runner
identity and external run ID.

Expected successful status:

```text
XPLAT_BYTE_PARSER_REPLAY_PASS
```

The replay covers 62 fixture-manifest entries, eight regenerated golden stores,
28 descriptor-byte cases, 15 authority vectors, seven validity vectors,
logical-hash reconstruction and exact wire bytes. It performs no timing.

A Windows replay PASS is diagnostic byte/parser evidence only. It does not
establish Windows `DURABLE_PUBLISH_V1`, safe opening of an untrusted store,
publication atomicity or crash durability. Linux, macOS and Windows outputs
must remain separate; a missing platform is not PASS.

Before running, verify the package-level `SHA256SUMS`. After running, verify the
new evidence directory's generated `SHA256SUMS` and return the raw directory
without editing any file.
