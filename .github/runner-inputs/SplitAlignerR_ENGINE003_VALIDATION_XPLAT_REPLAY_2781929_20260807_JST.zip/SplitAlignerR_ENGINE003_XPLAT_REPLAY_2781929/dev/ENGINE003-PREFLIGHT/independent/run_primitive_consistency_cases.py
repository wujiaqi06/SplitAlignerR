#!/usr/bin/env python3
"""Positive witness corpus for PrimitiveRowConsistency-v1.

This is a review-only runner.  It first requires the complete independent
store checker to accept the fixture, then records concrete logical-cell
witnesses for every mandatory positive pattern.  It does not import the
reference encoder or construct package data.
"""

from __future__ import annotations

import argparse
import json
import math
import struct
import subprocess
import sys
from pathlib import Path

from run_negative_cases import (
    component_geometry,
    get_numeric_bits,
    get_state,
    get_validity,
)


INVARIANT = "PrimitiveRowConsistency-v1"


def run_checker(checker: Path, store: Path, registry: Path) -> None:
    result = subprocess.run(
        [
            sys.executable, "-B", str(checker), "--store", str(store),
            "--registry", str(registry), "--phase", "PUBLISHED_STORE",
        ],
        check=False, capture_output=True, text=True,
    )
    if result.returncode != 0:
        raise SystemExit(
            "independent checker rejected positive corpus: "
            + result.stdout + result.stderr
        )


def witness_text(row: int, primitive: int, coordinate: int, state: int,
                 valid: bool) -> str:
    return (
        f"row={row};primitive={primitive};coordinate={coordinate};"
        f"state={state};validity={int(valid)}"
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--checker", required=True, type=Path)
    parser.add_argument("--store", required=True, type=Path)
    parser.add_argument("--registry", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()

    run_checker(args.checker, args.store, args.registry)
    authority = json.loads(args.registry.read_text(encoding="utf-8"))
    primitives = authority["primitive_entries"]
    bstar_members = authority["bstar_members"]
    rows, primitive_count, _, _ = component_geometry(args.store, "STATE.bin")
    _, numeric_count, _, _ = component_geometry(args.store, "NUMERIC.bin")
    if primitive_count != len(primitives):
        raise SystemExit("primitive authority/axis mismatch")
    if numeric_count != primitive_count + len(bstar_members):
        raise SystemExit("B* authority/axis mismatch")

    cells = []
    terminal_na_topo = 0
    nonmapped_valid = 0
    for row in range(rows):
        for primitive, entry in enumerate(primitives):
            state = get_state(args.store, row, primitive)
            valid = get_validity(args.store, row, primitive)
            cells.append((row, primitive, entry, state, valid))
            terminal_na_topo += int(entry["terminal"] and state == 3)
            nonmapped_valid += int(state != 0 and valid)

    specifications = [
        (
            "terminal_Mapped_validity_1",
            lambda item: item[2]["terminal"] and item[3] == 0 and item[4],
        ),
        (
            "terminal_Mapped_validity_0",
            lambda item: item[2]["terminal"] and item[3] == 0 and not item[4],
        ),
        (
            "terminal_NA_struct_validity_0",
            lambda item: item[2]["terminal"] and item[3] == 1 and not item[4],
        ),
        (
            "terminal_NA_fuse_validity_0",
            lambda item: item[2]["terminal"] and item[3] == 2 and not item[4],
        ),
        (
            "internal_NA_topo_validity_0",
            lambda item: not item[2]["terminal"] and item[3] == 3 and not item[4],
        ),
    ]
    output = ["case\tinvariant\twitness\tresult"]
    failures = []
    for name, predicate in specifications:
        witness = next((item for item in cells if predicate(item)), None)
        passed = witness is not None
        detail = "MISSING"
        if witness is not None:
            row, primitive, _entry, state, valid = witness
            detail = witness_text(row, primitive, primitive, state, valid)
        output.append(
            f"{name}\t{INVARIANT}\t{detail}\t{'PASS' if passed else 'FAIL'}"
        )
        if not passed:
            failures.append(name)

    composite_witness = None
    for row, primitive, _entry, state, valid in cells:
        if state != 2 or valid:
            continue
        for bstar_id, members in enumerate(bstar_members):
            coordinate = primitive_count + bstar_id
            if primitive not in members or not get_validity(args.store, row, coordinate):
                continue
            numeric = struct.unpack(
                "<d", get_numeric_bits(args.store, row, coordinate)
            )[0]
            if math.isfinite(numeric):
                composite_witness = (
                    row, primitive, coordinate, state, valid, bstar_id, numeric
                )
                break
        if composite_witness is not None:
            break
    if composite_witness is None:
        output.append(
            f"NA_fuse_primitive_unavailable_Bstar_available\t{INVARIANT}\t"
            "MISSING\tFAIL"
        )
        failures.append("NA_fuse_primitive_unavailable_Bstar_available")
    else:
        row, primitive, coordinate, state, valid, bstar_id, numeric = composite_witness
        detail = (
            witness_text(row, primitive, coordinate, state, valid)
            + f";bstar_id={bstar_id};bstar_value={numeric:.17g}"
        )
        output.append(
            f"NA_fuse_primitive_unavailable_Bstar_available\t{INVARIANT}\t"
            f"{detail}\tPASS"
        )

    invariant_pass = terminal_na_topo == 0 and nonmapped_valid == 0
    output.append(
        f"full_fixture_joint_scan\t{INVARIANT}\t"
        f"cells={len(cells)};terminal_NA_topo={terminal_na_topo};"
        f"nonmapped_valid={nonmapped_valid}\t"
        f"{'PASS' if invariant_pass else 'FAIL'}"
    )
    if not invariant_pass:
        failures.append("full_fixture_joint_scan")

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text("\n".join(output) + "\n", encoding="utf-8")
    if failures:
        raise SystemExit("primitive positive-corpus failures: " + ",".join(failures))
    print(f"PRIMITIVE_CONSISTENCY_POSITIVE_PASS {len(output) - 1}/{len(output) - 1}")


if __name__ == "__main__":
    main()
