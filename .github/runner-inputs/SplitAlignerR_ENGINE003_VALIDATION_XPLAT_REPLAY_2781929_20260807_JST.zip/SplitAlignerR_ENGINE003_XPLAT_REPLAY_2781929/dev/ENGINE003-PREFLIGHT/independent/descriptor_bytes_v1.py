#!/usr/bin/env python3
"""Platform-neutral descriptor-byte parser for ENGINE003 preflight.

This independent module has no filesystem safe-open dependency and imports no
reference encoder or package implementation.  POSIX and Windows evidence can
therefore invoke the same bounded byte parser directly.
"""

from __future__ import annotations

import json


DESCRIPTOR_SCHEMA = "SplitAlignerR/ENGINE003ExternalAuthorityDescriptor/v1"
DESCRIPTOR_KEYS = {
    "descriptor_schema", "taxon_label_bytes_hex", "primitive_entries",
    "gene_ids", "bstar_members",
}
DESCRIPTOR_MAX_RAW_BYTES = 8 * 1024 * 1024
DESCRIPTOR_MAX_JSON_DEPTH = 64
DESCRIPTOR_MAX_STRING_TOKEN_BYTES = 1024 * 1024
DESCRIPTOR_MAX_ARRAY_ELEMENTS = 250_000
DESCRIPTOR_MAX_OBJECT_MEMBERS = 64
DESCRIPTOR_MAX_TOTAL_VALUES = 2_000_000


class DescriptorBytesError(Exception):
    def __init__(self, code: str, detail: str):
        super().__init__(f"{code}: {detail}")
        self.code = code
        self.detail = detail


def reject(code: str, detail: str) -> None:
    raise DescriptorBytesError(code, detail)


def scan_descriptor_lexical_limits(raw: bytes) -> None:
    """Apply byte/depth/token limits without host-parser recursion."""
    if not isinstance(raw, bytes):
        reject("E3_DESCRIPTOR", "descriptor input must be bytes")
    if len(raw) > DESCRIPTOR_MAX_RAW_BYTES:
        reject("E3_DESCRIPTOR_LIMIT", "raw descriptor byte limit")
    depth = 0
    in_string = False
    string_bytes = 0
    index = 0
    while index < len(raw):
        byte = raw[index]
        if in_string:
            if byte == 0x22:
                in_string = False
                string_bytes = 0
            elif byte == 0x5C:
                string_bytes += 1
                index += 1
                if index < len(raw):
                    string_bytes += 1
            else:
                string_bytes += 1
            if string_bytes > DESCRIPTOR_MAX_STRING_TOKEN_BYTES:
                reject("E3_DESCRIPTOR_LIMIT", "JSON string-token byte limit")
        elif byte == 0x22:
            in_string = True
            string_bytes = 0
        elif byte in (0x7B, 0x5B):
            depth += 1
            if depth > DESCRIPTOR_MAX_JSON_DEPTH:
                reject("E3_DESCRIPTOR_LIMIT", "JSON nesting depth limit")
        elif byte in (0x7D, 0x5D):
            depth -= 1
            if depth < 0:
                depth = 0
        index += 1


def scan_descriptor_structural_limits(value) -> None:
    """Bound decoded container fanout with an iterative traversal."""
    stack = [value]
    total = 0
    while stack:
        item = stack.pop()
        total += 1
        if total > DESCRIPTOR_MAX_TOTAL_VALUES:
            reject("E3_DESCRIPTOR_LIMIT", "decoded JSON value-count limit")
        if isinstance(item, list):
            if len(item) > DESCRIPTOR_MAX_ARRAY_ELEMENTS:
                reject("E3_DESCRIPTOR_LIMIT", "JSON array element-count limit")
            stack.extend(item)
        elif isinstance(item, dict):
            if len(item) > DESCRIPTOR_MAX_OBJECT_MEMBERS:
                reject("E3_DESCRIPTOR_LIMIT", "JSON object member-count limit")
            stack.extend(item.values())


def parse_descriptor_bytes(raw: bytes) -> dict:
    """Parse an unambiguous bounded v1 descriptor from already-bounded bytes."""

    def reject_duplicate_keys(pairs):
        output = {}
        for key, value in pairs:
            if key in output:
                reject("E3_DESCRIPTOR", "duplicate decoded JSON object key")
            output[key] = value
        return output

    def reject_nonstandard_constant(_value):
        reject("E3_DESCRIPTOR", "nonstandard JSON constant")

    def reject_json_float(_value):
        reject("E3_DESCRIPTOR", "JSON floating-point number is not allowed")

    def parse_bounded_int(token):
        digits = token[1:] if token.startswith("-") else token
        if not digits or len(digits) > 10:
            reject("E3_DESCRIPTOR", "JSON integer token exceeds u32 lexical bound")
        return int(token, 10)

    try:
        scan_descriptor_lexical_limits(raw)
        value = json.loads(
            raw.decode("utf-8"), object_pairs_hook=reject_duplicate_keys,
            parse_constant=reject_nonstandard_constant,
            parse_float=reject_json_float, parse_int=parse_bounded_int,
        )
        scan_descriptor_structural_limits(value)
    except DescriptorBytesError:
        raise
    except (MemoryError, RecursionError):
        reject("E3_DESCRIPTOR", "JSON parser resource limit")
    except (UnicodeError, json.JSONDecodeError, KeyError, TypeError, ValueError):
        reject("E3_DESCRIPTOR", "invalid JSON descriptor")
    if not isinstance(value, dict):
        reject("E3_DESCRIPTOR", "registry descriptor must be an object")
    if set(value) != DESCRIPTOR_KEYS:
        reject("E3_DESCRIPTOR", "top-level key set mismatch")
    if value["descriptor_schema"] != DESCRIPTOR_SCHEMA:
        reject("E3_DESCRIPTOR", "descriptor schema mismatch")
    for key in (
        "taxon_label_bytes_hex", "primitive_entries", "gene_ids",
        "bstar_members",
    ):
        if not isinstance(value[key], list):
            reject("E3_DESCRIPTOR", f"{key} must be a list")
    return value
