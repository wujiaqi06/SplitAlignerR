#!/usr/bin/env python3
"""Exercise the two validation phases and exact directory grammar."""

from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path


def invoke(checker: Path, store: Path, registry: Path, phase: str):
    return subprocess.run(
        [sys.executable, "-B", str(checker), "--store", str(store),
         "--registry", str(registry), "--phase", phase],
        check=False, capture_output=True, text=True
    )


def classify(result: subprocess.CompletedProcess[str]) -> str:
    if result.returncode == 0:
        return json.loads(result.stdout)["status"]
    return result.stdout.split(":", 1)[0] if result.stdout else "NO_OUTPUT"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--checker", required=True, type=Path)
    parser.add_argument("--store", required=True, type=Path)
    parser.add_argument("--registry", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    rows = ["case\tphase\texpected\tobserved\treturn_code\tresult"]
    failures = []
    with tempfile.TemporaryDirectory(prefix="e3-phase-") as temporary:
        # Canonicalize the trusted OS tempfile root; the checker deliberately
        # rejects symlinks in the untrusted store path itself.
        root = Path(temporary).resolve(strict=True)
        published = root / "published"
        prepublication = root / "prepublication"
        shutil.copytree(args.store, published)
        shutil.copytree(args.store, prepublication)
        (prepublication / "VALIDATED").unlink()
        cases = (
            ("five_binary_bytes", prepublication, "PREPUBLICATION_BYTES",
             "PREPUBLICATION_BYTES_VALID", 0),
            ("five_binary_bytes_claimed_published", prepublication, "PUBLISHED_STORE",
             "E3_INCOMPLETE", 1),
            ("six_entry_published", published, "PUBLISHED_STORE",
             "PUBLISHED_VALIDATED", 0),
            ("manifest_present_in_prepublication", published, "PREPUBLICATION_BYTES",
             "E3_UNDECLARED_ENTRY", 1),
        )
        for name, store, phase, expected, expected_rc in cases:
            result = invoke(args.checker, store, args.registry, phase)
            observed = classify(result)
            passed = observed == expected and (result.returncode == expected_rc)
            rows.append(
                f"{name}\t{phase}\t{expected}\t{observed}\t{result.returncode}\t"
                f"{'PASS' if passed else 'FAIL'}"
            )
            if not passed:
                failures.append(name)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text("\n".join(rows) + "\n", encoding="utf-8")
    if failures:
        raise SystemExit("phase-case failures: " + ",".join(failures))
    print(f"PHASE_CASES_PASS {len(cases)}/{len(cases)}")


if __name__ == "__main__":
    main()
