#!/usr/bin/env python3
"""Cross-runtime corpus for the platform-neutral descriptor-byte parser."""

from __future__ import annotations

import argparse
import copy
import json
import subprocess
import sys
from pathlib import Path

from descriptor_bytes_v1 import (
    DESCRIPTOR_MAX_RAW_BYTES,
    DescriptorBytesError,
    parse_descriptor_bytes,
)


def canonical(value: dict) -> bytes:
    return (json.dumps(value, indent=2, ensure_ascii=True) + "\n").encode("utf-8")


def base_descriptor() -> dict:
    return {
        "descriptor_schema": "SplitAlignerR/ENGINE003ExternalAuthorityDescriptor/v1",
        "taxon_label_bytes_hex": ["41", "42", "43", "44"],
        "primitive_entries": [
            {
                "terminal": True,
                "terminal_taxon_id": 0,
                "authority_edge_split_hex": "01",
            },
            {
                "terminal": True,
                "terminal_taxon_id": 1,
                "authority_edge_split_hex": "02",
            },
            {
                "terminal": True,
                "terminal_taxon_id": 2,
                "authority_edge_split_hex": "04",
            },
            {
                "terminal": True,
                "terminal_taxon_id": 3,
                "authority_edge_split_hex": "08",
            },
            {
                "terminal": False,
                "terminal_taxon_id": 0xFFFFFFFF,
                "authority_edge_split_hex": "03",
            },
        ],
        "gene_ids": ["g0", "g1", "g2"],
        "bstar_members": [[0, 2], [1, 4]],
    }


def replace_once(raw: bytes, old: bytes, new: bytes) -> bytes:
    if old not in raw:
        raise RuntimeError("mutation anchor absent")
    return raw.replace(old, new, 1)


def cases() -> list[tuple[str, str, bytes]]:
    value = base_descriptor()
    base = canonical(value)
    output = [
        ("valid_baseline", "ACCEPT", base),
        ("depth_64", "ACCEPT", replace_once(
            base, b'"g0"', (b"[" * 62) + b"0" + (b"]" * 62))),
        ("depth_65", "E3_DESCRIPTOR_LIMIT", replace_once(
            base, b'"g0"', (b"[" * 63) + b"0" + (b"]" * 63))),
        ("depth_2000", "E3_DESCRIPTOR_LIMIT", replace_once(
            base, b'"g0"', (b"[" * 2000) + b"0" + (b"]" * 2000))),
        ("quoted_brackets", "ACCEPT", replace_once(
            base, b'"g0"', b'"[[[{{{]]]}}}"')),
        ("escaped_quote_bracket", "ACCEPT", replace_once(
            base, b'"g0"', b'"a\\\"[b"')),
        ("unicode_escaped_brackets", "ACCEPT", replace_once(
            base, b'"g0"', b'"\\u005b\\u005d"')),
        ("string_exact_1mib", "ACCEPT", replace_once(
            base, b'"g0"', b'"' + (b"x" * (1024 * 1024)) + b'"')),
        ("string_over_1mib", "E3_DESCRIPTOR_LIMIT", replace_once(
            base, b'"g0"', b'"' + (b"x" * (1024 * 1024 + 1)) + b'"')),
        ("array_exact_250000", "ACCEPT", replace_once(
            base, b'"g0",\n    "g1",\n    "g2"',
            b",".join([b"0"] * 250000))),
        ("array_over_250000", "E3_DESCRIPTOR_LIMIT", replace_once(
            base, b'"g0",\n    "g1",\n    "g2"',
            b",".join([b"0"] * 250001))),
        ("object_over_64", "E3_DESCRIPTOR_LIMIT", replace_once(
            base, b'  "gene_ids":',
            b"".join(
                f'  "limit_probe_{index}": 0,\n'.encode("ascii")
                for index in range(60)
            ) + b'  "gene_ids":')),
        ("total_values_over_2000000", "E3_DESCRIPTOR_LIMIT", replace_once(
            base, b'"g0",\n    "g1",\n    "g2"',
            b",".join(
                [b"[" + b",".join([b"0"] * 222223) + b"]"] * 9
            ))),
        ("raw_exact_8mib", "ACCEPT",
         base + (b" " * (DESCRIPTOR_MAX_RAW_BYTES - len(base)))),
        ("raw_over_8mib", "E3_DESCRIPTOR_LIMIT",
         base + (b" " * (DESCRIPTOR_MAX_RAW_BYTES + 1 - len(base)))),
        ("duplicate_root_key", "E3_DESCRIPTOR", replace_once(
            base, b'  "gene_ids":',
            b'  "gene_ids": ["evil"],\n  "gene_ids":')),
        ("duplicate_escaped_alias", "E3_DESCRIPTOR", replace_once(
            base, b'  "gene_ids":',
            b'  "g\\u0065ne_ids": ["evil"],\n  "gene_ids":')),
        ("duplicate_primitive_key", "E3_DESCRIPTOR", replace_once(
            base, b'      "terminal": true,',
            b'      "terminal": false,\n      "terminal": true,')),
        ("json_nan", "E3_DESCRIPTOR", replace_once(base, b'"g0"', b"NaN")),
        ("json_infinity", "E3_DESCRIPTOR", replace_once(
            base, b'"g0"', b"Infinity")),
        ("json_float", "E3_DESCRIPTOR", replace_once(
            base, b'"terminal_taxon_id": 0', b'"terminal_taxon_id": 0.5')),
        ("integer_token_too_long", "E3_DESCRIPTOR", replace_once(
            base, b'"terminal_taxon_id": 0',
            b'"terminal_taxon_id": ' + (b"9" * 10000))),
        ("invalid_utf8", "E3_DESCRIPTOR", replace_once(
            base, b'"g0"', b'"\xff"')),
        ("trailing_json_value", "E3_DESCRIPTOR", base + b"{}\n"),
    ]
    for name, edit in (
        ("extra_root_key", lambda item: item.__setitem__("extra", 1)),
        ("missing_root_key", lambda item: item.pop("gene_ids")),
        ("wrong_schema", lambda item: item.__setitem__("descriptor_schema", "wrong")),
        ("root_gene_ids_not_list", lambda item: item.__setitem__("gene_ids", "g0")),
    ):
        changed = copy.deepcopy(value)
        edit(changed)
        output.append((name, "E3_DESCRIPTOR", canonical(changed)))
    return output


def worker() -> int:
    failed = False
    for name, expected, raw in cases():
        try:
            parse_descriptor_bytes(raw)
        except DescriptorBytesError as error:
            observed = error.code
        else:
            observed = "ACCEPT"
        passed = observed == expected
        print(f"{name}\t{expected}\t{observed}\t{'PASS' if passed else 'FAIL'}")
        failed = failed or not passed
    return int(failed)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--worker", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--python", action="append", dest="pythons")
    args = parser.parse_args()
    if args.worker:
        raise SystemExit(worker())
    if args.output is None:
        raise SystemExit("--output is required")
    pythons = args.pythons or [sys.executable]
    rows = ["runtime\tcase\texpected_code\tobserved_code\tresult"]
    failures = []
    case_count = None
    for python in pythons:
        version_result = subprocess.run(
            [python, "--version"], check=True, capture_output=True, text=True
        )
        version = version_result.stdout.strip() or version_result.stderr.strip()
        runtime = version.replace(" ", "_")
        process = subprocess.run(
            [python, "-B", str(Path(__file__).resolve()), "--worker"],
            check=False, capture_output=True, text=True, timeout=60,
        )
        worker_rows = process.stdout.splitlines()
        if case_count is None:
            case_count = len(worker_rows)
        if process.returncode != 0 or len(worker_rows) != case_count or process.stderr:
            failures.append(
                f"{runtime}[rc={process.returncode},rows={len(worker_rows)},"
                f"stderr={bool(process.stderr)}]"
            )
        rows.extend(f"{runtime}\t{row}" for row in worker_rows)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text("\n".join(rows) + "\n", encoding="utf-8")
    if failures:
        raise SystemExit("descriptor-byte failures: " + ",".join(failures))
    total = len(pythons) * (case_count or 0)
    print(f"DESCRIPTOR_BYTE_CASES_PASS {total}/{total} runtimes={len(pythons)}")


if __name__ == "__main__":
    main()
