#!/usr/bin/env python3
"""Run the independent published-store checker over all review fixtures."""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path


def manifest_value(path: Path, key: str) -> str:
    prefix = key + "="
    for line in path.read_text(encoding="ascii").splitlines():
        if line.startswith(prefix):
            return line[len(prefix):]
    raise ValueError(key)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--checker", required=True, type=Path)
    parser.add_argument("--fixtures", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    cases = (
        ("tiny", "tiny_store", "registry_input.json"),
        ("zero_rows", "zero_rows_store", "zero_rows_registry.json"),
        ("zero_columns", "zero_columns_store", "zero_columns_registry.json"),
        ("one_cell", "one_cell_store", "one_cell_registry.json"),
        ("exact_256", "exact_256_store", "exact_256_registry.json"),
        ("multi_257", "multi_257_store", "multi_257_registry.json"),
        ("bstar_u32le", "bstar_u32le_store", "bstar_u32le_registry.json"),
        ("raw_ff", "raw_ff_store", "raw_ff_registry.json"),
    )
    rows = [
        "case\trows\tprimitive_count\tbstar_count\tindependent_logical_sha256\t"
        "manifest_logical_sha256\tlogical_hash_equal\tbstar_contains_id_above_255\t"
        "primitive_row_invariant\tprimitive_cells_checked\tprimitive_cells_expected\t"
        "primitive_coverage_equal\tmax_join_payload_bytes\t"
        "composite_row_invariant\tbstar_cells_checked\tbstar_cells_expected\t"
        "bstar_coverage_equal\tvalid_bstar_cells\tmax_occupied_members\t"
        "status\tresult"
    ]
    failures = []
    for case, store_name, registry_name in cases:
        store = args.fixtures / store_name
        registry_path = args.fixtures / registry_name
        process = subprocess.run(
            [sys.executable, "-B", str(args.checker), "--store", str(store),
             "--registry", str(registry_path), "--phase", "PUBLISHED_STORE"],
            check=False, capture_output=True, text=True
        )
        if process.returncode != 0:
            failures.append(case)
            rows.append(
                f"{case}\tNA\tNA\tNA\tNA\tNA\tFALSE\tNA\tNA\tNA\tNA\t"
                "FALSE\tNA\tNA\tNA\tNA\tFALSE\tNA\tNA\tERROR\tFAIL"
            )
            continue
        result = json.loads(process.stdout)
        registry = json.loads(registry_path.read_text(encoding="utf-8"))
        expected = manifest_value(store / "VALIDATED", "logical_content_sha256")
        equal = result["logical_content_sha256"] == expected
        above = any(any(member > 255 for member in members)
                    for members in registry["bstar_members"])
        consistency = result["primitive_row_consistency"]
        expected_cells = result["rows"] * result["primitive_count"]
        coverage_equal = consistency["checked_cells"] == expected_cells
        composite = result["composite_row_consistency"]
        expected_bstar_cells = result["rows"] * result["bstar_count"]
        bstar_coverage_equal = (
            composite["checked_bstar_cells"] == expected_bstar_cells
        )
        passed = (
            equal and result["status"] == "PUBLISHED_VALIDATED"
            and consistency["invariant"] == "PrimitiveRowConsistency-v1"
            and coverage_equal
            and composite["invariant"] == "CompositeRowConsistency-v1"
            and bstar_coverage_equal
        )
        rows.append(
            f"{case}\t{result['rows']}\t{result['primitive_count']}\t"
            f"{result['bstar_count']}\t{result['logical_content_sha256']}\t{expected}\t"
            f"{str(equal).upper()}\t{str(above).upper()}\t"
            f"{consistency['invariant']}\t{consistency['checked_cells']}\t"
            f"{expected_cells}\t{str(coverage_equal).upper()}\t"
            f"{consistency['max_join_payload_bytes']}\t"
            f"{composite['invariant']}\t{composite['checked_bstar_cells']}\t"
            f"{expected_bstar_cells}\t{str(bstar_coverage_equal).upper()}\t"
            f"{composite['valid_bstar_cells']}\t"
            f"{composite['max_occupied_members']}\t{result['status']}\t"
            f"{'PASS' if passed else 'FAIL'}"
        )
        if not passed:
            failures.append(case)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text("\n".join(rows) + "\n", encoding="utf-8")
    if failures:
        raise SystemExit("fixture matrix failures: " + ",".join(failures))
    print(f"FIXTURE_MATRIX_PASS {len(cases)}/{len(cases)}")


if __name__ == "__main__":
    main()
