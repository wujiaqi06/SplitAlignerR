#!/usr/bin/env python3
"""Bounded nonregular/growing-file rejection corpus for the fixture checker."""

from __future__ import annotations

import argparse
import os
import shutil
import signal
import socket
import subprocess
import sys
import tempfile
import time
from pathlib import Path


CAP = 64 * 1024 * 1024
TIMEOUT_SECONDS = 3.0
READY_BYTES = b"READY_AFTER_INITIAL_FSTAT\n"


def invoke(checker: Path, store: Path, registry: Path,
           delay_ms: float = 0.0) -> tuple[str, int, float, bool, str]:
    command = [
        sys.executable, "-B", str(checker), "--store", str(store),
        "--registry", str(registry), "--phase", "PUBLISHED_STORE",
    ]
    if delay_ms:
        command.extend(["--test-read-delay-ms", str(delay_ms)])
    popen_options = {}
    if os.name == "posix":
        popen_options["start_new_session"] = True
    started = time.monotonic()
    process = subprocess.Popen(
        command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
        **popen_options,
    )
    try:
        stdout, _ = process.communicate(timeout=TIMEOUT_SECONDS)
    except subprocess.TimeoutExpired:
        terminate_process_tree(process)
        process.communicate()
        return "TIMEOUT", 124, time.monotonic() - started, True, "TIMEOUT"
    line = stdout.splitlines()[0] if stdout else "NO_OUTPUT"
    return (line.split(":", 1)[0], process.returncode,
            time.monotonic() - started, False, line)


def terminate_process_tree(process: subprocess.Popen[str]) -> None:
    if process.poll() is not None:
        return
    if os.name == "posix":
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
    else:
        process.kill()


def invoke_after_initial_fstat(
    checker: Path, store: Path, registry: Path, label: str, mutation,
    delay_ms: float,
) -> tuple[str, int, float, bool, str]:
    # The marker lives under a pre-created harness-only directory so creating
    # it cannot itself change either the store directory or the external
    # authority descriptor's parent-directory identity.
    control = store.parent / "harness-control"
    control.mkdir()
    marker = control / "read-ready.marker"
    command = [
        sys.executable, "-B", str(checker), "--store", str(store),
        "--registry", str(registry), "--phase", "PUBLISHED_STORE",
        "--test-read-delay-ms", str(delay_ms),
        "--test-read-ready-path", str(marker),
        "--test-read-ready-label", label,
    ]
    popen_options = {}
    if os.name == "posix":
        popen_options["start_new_session"] = True
    started = time.monotonic()
    deadline = started + TIMEOUT_SECONDS
    process = subprocess.Popen(
        command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
        **popen_options,
    )
    ready = False
    while time.monotonic() < deadline:
        try:
            marker_bytes = marker.read_bytes()
        except FileNotFoundError:
            marker_bytes = None
        if marker_bytes == READY_BYTES:
            ready = True
            break
        if marker_bytes not in (None, b""):
            terminate_process_tree(process)
            process.communicate()
            elapsed = time.monotonic() - started
            return "HANDSHAKE_INVALID", 125, elapsed, False, "HANDSHAKE_INVALID"
        if process.poll() is not None:
            break
        time.sleep(0.005)

    if ready:
        try:
            mutation()
        except Exception:
            terminate_process_tree(process)
            process.communicate()
            raise

    remaining = max(0.001, deadline - time.monotonic())
    try:
        stdout, _ = process.communicate(timeout=remaining)
        timed_out = False
    except subprocess.TimeoutExpired:
        terminate_process_tree(process)
        stdout, _ = process.communicate()
        timed_out = True
    elapsed = time.monotonic() - started
    line = stdout.splitlines()[0] if stdout else "NO_OUTPUT"
    if timed_out:
        return "TIMEOUT", 124, elapsed, True, "TIMEOUT"
    if not ready:
        return "HANDSHAKE_MISSING", process.returncode, elapsed, False, line
    return line.split(":", 1)[0], process.returncode, elapsed, False, line


def fresh_copy(source_store: Path, source_registry: Path, root: Path) -> tuple[Path, Path]:
    store = root / "store"
    registry = root / "registry.json"
    shutil.copytree(source_store, store, symlinks=False)
    shutil.copy2(source_registry, registry)
    return store, registry


def record(rows: list[str], failures: list[str], name: str, expected: str,
           result: tuple[str, int, float, bool, str],
           availability: str = "SUPPORTED", expected_line=None) -> None:
    observed, return_code, elapsed, timed_out, observed_line = result
    available = availability != "NOT_AVAILABLE"
    passed = (
        not timed_out and return_code != 0 and observed == expected and
        (expected_line is None or observed_line == expected_line)
    )
    outcome = "NOT_AVAILABLE" if not available else ("PASS" if passed else "FAIL")
    rows.append(
        f"{name}\t{availability}\t{expected}\t{observed}\t{return_code}\t"
        f"{elapsed:.6f}\t{str(timed_out).upper()}\t{outcome}"
    )
    if available and not passed:
        failures.append(
            f"{name}[code={observed},rc={return_code},line={observed_line!r}]"
        )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--checker", required=True, type=Path)
    parser.add_argument("--store", required=True, type=Path)
    parser.add_argument("--registry", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()

    rows = [
        "case\tavailability\texpected_code\tobserved_code\treturn_code\t"
        "bounded_rejection_seconds\ttimed_out\tresult"
    ]
    failures: list[str] = []

    with tempfile.TemporaryDirectory(prefix="e3-nonregular-") as temporary:
        root = Path(temporary).resolve(strict=True)
        store, registry = fresh_copy(args.store, args.registry, root)
        (store / "STATE.bin").unlink()
        os.mkfifo(store / "STATE.bin", 0o600)
        result = invoke(args.checker, store, registry)
        record(rows, failures, "fifo_component", "E3_NOT_REGULAR", result)

    with tempfile.TemporaryDirectory(prefix="e3-nonregular-") as temporary:
        root = Path(temporary).resolve(strict=True)
        store, registry = fresh_copy(args.store, args.registry, root)
        registry.unlink()
        os.mkfifo(registry, 0o600)
        result = invoke(args.checker, store, registry)
        record(rows, failures, "fifo_authority", "E3_NOT_REGULAR", result)

    with tempfile.TemporaryDirectory(prefix="e3-nonregular-") as temporary:
        root = Path(temporary).resolve(strict=True)
        store, registry = fresh_copy(args.store, args.registry, root)
        registry.unlink()
        registry.symlink_to(args.registry.resolve(strict=True))
        result = invoke(args.checker, store, registry)
        record(rows, failures, "authority_symlink", "E3_SYMLINK_OR_OPEN", result)

    with tempfile.TemporaryDirectory(prefix="e3-nonregular-") as temporary:
        root = Path(temporary).resolve(strict=True)
        store, registry = fresh_copy(args.store, args.registry, root)
        (store / "STATE.bin").unlink()
        (store / "STATE.bin").mkdir()
        result = invoke(args.checker, store, registry)
        record(rows, failures, "directory_component", "E3_NOT_REGULAR", result)

    if hasattr(socket, "AF_UNIX"):
        with tempfile.TemporaryDirectory(prefix="e3-sock-") as temporary:
            root = Path(temporary).resolve(strict=True)
            store, registry = fresh_copy(args.store, args.registry, root)
            path = store / "STATE.bin"
            path.unlink()
            endpoint = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            try:
                try:
                    endpoint.bind(str(path))
                except OSError:
                    record(rows, failures, "socket_component", "NOT_AVAILABLE",
                           ("NOT_AVAILABLE", 0, 0.0, False, "NOT_AVAILABLE"),
                           availability="NOT_AVAILABLE")
                else:
                    result = invoke(args.checker, store, registry)
                    record(rows, failures, "socket_component",
                           "E3_SYMLINK_OR_OPEN", result)
            finally:
                endpoint.close()
    else:
        record(rows, failures, "socket_component", "NOT_AVAILABLE",
               ("NOT_AVAILABLE", 0, 0.0, False, "NOT_AVAILABLE"),
               availability="NOT_AVAILABLE")

    # Creating a device node is intentionally not attempted: it requires
    # privilege on supported hosts.  The platform contract still rejects all
    # nonregular file types after fstat().
    record(rows, failures, "device_component", "NOT_AVAILABLE",
           ("NOT_AVAILABLE", 0, 0.0, False, "NOT_AVAILABLE"),
           availability="NOT_AVAILABLE")

    with tempfile.TemporaryDirectory(prefix="e3-nonregular-") as temporary:
        root = Path(temporary).resolve(strict=True)
        store, registry = fresh_copy(args.store, args.registry, root)
        with (store / "STATE.bin").open("r+b") as handle:
            handle.truncate(CAP + 1)
        result = invoke(args.checker, store, registry)
        record(rows, failures, "initial_file_over_cap", "E3_FIXTURE_LIMIT", result)

    with tempfile.TemporaryDirectory(prefix="e3-nonregular-") as temporary:
        root = Path(temporary).resolve(strict=True)
        store, registry = fresh_copy(args.store, args.registry, root)
        state = store / "STATE.bin"
        with state.open("r+b") as handle:
            handle.truncate(CAP - 2 * 1024 * 1024)
        def grow_beyond_cap() -> None:
            with state.open("ab") as handle:
                handle.write(bytes(3 * 1024 * 1024))
                handle.flush()

        result = invoke_after_initial_fstat(
            args.checker, store, registry, "STATE.bin", grow_beyond_cap, 10.0
        )
        record(rows, failures, "file_growth_beyond_cap", "E3_FIXTURE_LIMIT",
               result,
               expected_line=(
                   "E3_FIXTURE_LIMIT: STATE.bin grew beyond tiny-checker cap"
               ))

    with tempfile.TemporaryDirectory(prefix="e3-nonregular-") as temporary:
        root = Path(temporary).resolve(strict=True)
        store, registry = fresh_copy(args.store, args.registry, root)
        state = store / "STATE.bin"
        with state.open("r+b") as handle:
            handle.truncate(32 * 1024 * 1024)
        def change_within_cap() -> None:
            with state.open("ab") as handle:
                handle.write(b"\x00")
                handle.flush()

        result = invoke_after_initial_fstat(
            args.checker, store, registry, "STATE.bin", change_within_cap, 10.0
        )
        record(rows, failures, "file_change_within_cap", "E3_FILE_CHANGED",
               result, expected_line="E3_FILE_CHANGED: STATE.bin")

    with tempfile.TemporaryDirectory(prefix="e3-nonregular-") as temporary:
        root = Path(temporary).resolve(strict=True)
        store, registry = fresh_copy(args.store, args.registry, root)

        def add_final_directory_entry() -> None:
            (store / "UNDECLARED").write_bytes(b"race")

        result = invoke_after_initial_fstat(
            args.checker, store, registry, "VALIDATED",
            add_final_directory_entry, 100.0
        )
        record(rows, failures, "final_directory_entry_addition",
               "E3_DIRECTORY_CHANGED", result,
               expected_line=(
                   "E3_DIRECTORY_CHANGED: store directory identity/metadata"
               ))

    with tempfile.TemporaryDirectory(prefix="e3-nonregular-") as temporary:
        root = Path(temporary).resolve(strict=True)
        store, registry = fresh_copy(args.store, args.registry, root)
        state = store / "STATE.bin"
        replacement = root / "replacement-state.bin"
        shutil.copy2(state, replacement)

        def rebind_state_name() -> None:
            os.replace(replacement, state)

        result = invoke_after_initial_fstat(
            args.checker, store, registry, "VALIDATED", rebind_state_name, 100.0
        )
        record(rows, failures, "final_name_rebinding",
               "E3_DIRECTORY_CHANGED", result,
               expected_line=(
                   "E3_DIRECTORY_CHANGED: store directory identity/metadata"
               ))

    with tempfile.TemporaryDirectory(prefix="e3-nonregular-") as temporary:
        root = Path(temporary).resolve(strict=True)
        store, registry = fresh_copy(args.store, args.registry, root)
        replacement = root / "replacement-registry.json"
        shutil.copy2(registry, replacement)

        def rebind_external_authority_name() -> None:
            os.replace(replacement, registry)

        result = invoke_after_initial_fstat(
            args.checker, store, registry, "VALIDATED",
            rebind_external_authority_name, 100.0
        )
        record(rows, failures, "final_authority_name_rebinding",
               "E3_DIRECTORY_CHANGED", result,
               expected_line=(
                   "E3_DIRECTORY_CHANGED: external authority parent identity/metadata"
               ))

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text("\n".join(rows) + "\n", encoding="utf-8")
    if failures:
        raise SystemExit("nonregular-case failures: " + ",".join(failures))
    available = sum("\tSUPPORTED\t" in row for row in rows[1:])
    unavailable = sum("\tNOT_AVAILABLE\t" in row for row in rows[1:])
    print(
        f"NONREGULAR_AVAILABLE_CASES_PASS {available}/{available}; "
        f"NOT_AVAILABLE {unavailable}"
    )


if __name__ == "__main__":
    main()
