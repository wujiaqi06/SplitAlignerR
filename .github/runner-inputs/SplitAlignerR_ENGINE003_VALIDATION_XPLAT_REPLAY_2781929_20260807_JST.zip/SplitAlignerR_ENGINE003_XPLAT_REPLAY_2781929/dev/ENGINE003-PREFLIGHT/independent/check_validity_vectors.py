#!/usr/bin/env python3
"""Independent LSB-first boundary-vector checker; non-production."""

from __future__ import annotations

import argparse
import csv
from pathlib import Path


def expected(count: int, bits: list[int]) -> bytes:
    output = bytearray((count + 7) // 8)
    for bit in bits:
        if bit < 0 or bit >= count:
            raise ValueError("bit out of range")
        output[bit // 8] |= 1 << (bit % 8)
    return bytes(output)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("path", type=Path)
    args = parser.parse_args()
    required = [1, 7, 8, 9, 63, 64, 65]
    seen = []
    with args.path.open(newline="", encoding="ascii") as handle:
        for row in csv.DictReader(handle, delimiter="\t"):
            count = int(row["logical_cells"])
            bits = [int(value) for value in row["set_bits_zero_based"].split(",")]
            actual = bytes.fromhex(row["expected_lsb_first_hex"])
            if actual != expected(count, bits):
                raise SystemExit(f"vector mismatch for {count}")
            if len(actual) != (count + 7) // 8:
                raise SystemExit(f"length mismatch for {count}")
            if count % 8 and actual[-1] >> (count % 8):
                raise SystemExit(f"nonzero unused high bit for {count}")
            seen.append(count)
    if seen != required:
        raise SystemExit(f"required vector order mismatch: {seen}")
    print("VALIDITY_BOUNDARY_VECTORS_PASS 7/7")


if __name__ == "__main__":
    main()
