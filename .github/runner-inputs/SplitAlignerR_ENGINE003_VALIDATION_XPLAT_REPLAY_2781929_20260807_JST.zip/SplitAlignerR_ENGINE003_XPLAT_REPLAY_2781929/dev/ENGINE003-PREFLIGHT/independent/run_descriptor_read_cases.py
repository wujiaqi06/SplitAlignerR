#!/usr/bin/env python3
"""Descriptor-specific bounded-read precedence and growth corpus."""

from __future__ import annotations

import argparse
import json
import os
import shutil
import signal
import subprocess
import sys
import tempfile
import time
from pathlib import Path


CAP = 8 * 1024 * 1024
TIMEOUT_SECONDS = 5.0
READY_BYTES = b"READY_AFTER_INITIAL_FSTAT\n"
LABEL = "registry descriptor"


def canonical(value: dict) -> bytes:
    return (json.dumps(value, indent=2, ensure_ascii=True) + "\n").encode("utf-8")


def terminate(process: subprocess.Popen[str]) -> None:
    if process.poll() is not None:
        return
    if os.name == "posix":
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
    else:
        process.kill()


def command(
    python: str, checker: Path, store: Path, registry: Path,
    marker: Path, delay_ms: float = 0.0,
) -> list[str]:
    return [
        python, "-B", str(checker), "--store", str(store), "--registry", str(registry),
        "--phase", "PUBLISHED_STORE", "--test-read-ready-path", str(marker),
        "--test-read-ready-label", LABEL, "--test-read-delay-ms", str(delay_ms),
    ]


def launch(args: list[str]) -> subprocess.Popen[str]:
    options = {"start_new_session": True} if os.name == "posix" else {}
    return subprocess.Popen(
        args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, **options
    )


def finish(process: subprocess.Popen[str]) -> tuple[str, int, str]:
    try:
        stdout, stderr = process.communicate(timeout=TIMEOUT_SECONDS)
    except subprocess.TimeoutExpired:
        terminate(process)
        process.communicate()
        return "TIMEOUT", 124, "TIMEOUT"
    first = stdout.splitlines()[0] if stdout else "NO_OUTPUT"
    observed = "ACCEPT" if process.returncode == 0 else first.split(":", 1)[0]
    return observed, process.returncode, stderr


def make_registry(path: Path, base: bytes, size: int) -> None:
    with path.open("wb") as handle:
        handle.write(base)
        handle.truncate(size)
    if size <= CAP:
        with path.open("r+b") as handle:
            handle.seek(len(base))
            handle.write(b" " * (size - len(base)))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--checker", required=True, type=Path)
    parser.add_argument("--store", required=True, type=Path)
    parser.add_argument("--registry", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--python", default=sys.executable)
    args = parser.parse_args()
    base = canonical(json.loads(args.registry.read_text(encoding="utf-8")))
    rows = [
        "case\tinitial_bytes\tfinal_bytes\texpected_code\tobserved_code\t"
        "return_code\tpayload_read_started\tstderr_empty\tresult"
    ]
    failures = []
    initial_cases = (
        ("descriptor_exactly_8mib", CAP, "ACCEPT", True),
        ("descriptor_8mib_plus_1", CAP + 1, "E3_DESCRIPTOR_LIMIT", False),
        ("descriptor_64mib", 64 * 1024 * 1024, "E3_DESCRIPTOR_LIMIT", False),
        ("descriptor_64mib_plus_1", 64 * 1024 * 1024 + 1,
         "E3_DESCRIPTOR_LIMIT", False),
    )
    for name, size, expected, expected_read in initial_cases:
        with tempfile.TemporaryDirectory(prefix="e3-descriptor-read-") as temporary:
            root = Path(temporary).resolve(strict=True)
            store = root / "store"
            shutil.copytree(args.store, store)
            input_dir = root / "input"
            control = root / "control"
            input_dir.mkdir()
            control.mkdir()
            registry = input_dir / "registry.json"
            marker = control / "ready.marker"
            make_registry(registry, base, size)
            observed, return_code, stderr = finish(launch(command(
                args.python, args.checker, store, registry, marker
            )))
            read_started = marker.exists()
            passed = (
                observed == expected and read_started == expected_read and not stderr
            )
            rows.append(
                f"{name}\t{size}\t{size}\t{expected}\t{observed}\t"
                f"{return_code}\t{str(read_started).upper()}\t"
                f"{str(not stderr).upper()}\t{'PASS' if passed else 'FAIL'}"
            )
            if not passed:
                failures.append(name)

    with tempfile.TemporaryDirectory(prefix="e3-descriptor-read-") as temporary:
        root = Path(temporary).resolve(strict=True)
        store = root / "store"
        shutil.copytree(args.store, store)
        input_dir = root / "input"
        control = root / "control"
        input_dir.mkdir()
        control.mkdir()
        registry = input_dir / "registry.json"
        marker = control / "ready.marker"
        initial = 7 * 1024 * 1024
        final = 9 * 1024 * 1024
        make_registry(registry, base, initial)
        process = launch(command(
            args.python, args.checker, store, registry, marker, delay_ms=20.0
        ))
        deadline = time.monotonic() + TIMEOUT_SECONDS
        while time.monotonic() < deadline and not marker.exists() and process.poll() is None:
            time.sleep(0.002)
        read_started = marker.exists() and marker.read_bytes() == READY_BYTES
        if read_started:
            with registry.open("ab") as handle:
                handle.write(b" " * (final - initial))
                handle.flush()
        observed, return_code, stderr = finish(process)
        passed = (
            read_started and observed == "E3_DESCRIPTOR_LIMIT" and
            return_code != 0 and not stderr and registry.stat().st_size == final
        )
        rows.append(
            f"descriptor_growth_over_8mib\t{initial}\t{registry.stat().st_size}\t"
            f"E3_DESCRIPTOR_LIMIT\t{observed}\t{return_code}\t"
            f"{str(read_started).upper()}\t{str(not stderr).upper()}\t"
            f"{'PASS' if passed else 'FAIL'}"
        )
        if not passed:
            failures.append("descriptor_growth_over_8mib")

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text("\n".join(rows) + "\n", encoding="utf-8")
    if failures:
        raise SystemExit("descriptor-read failures: " + ",".join(failures))
    print("DESCRIPTOR_READ_CASES_PASS 5/5")


if __name__ == "__main__":
    main()
