#!/usr/bin/env python3
"""Concrete positive witnesses for CompositeRowConsistency-v1."""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

from run_negative_cases import component_geometry, get_state, get_validity


INVARIANT = "CompositeRowConsistency-v1"
STATE_MAPPED = 0
STATE_NA_FUSE = 2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--checker", required=True, type=Path)
    parser.add_argument("--store", required=True, type=Path)
    parser.add_argument("--registry", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    checked = subprocess.run(
        [sys.executable, "-B", str(args.checker), "--store", str(args.store),
         "--registry", str(args.registry), "--phase", "PUBLISHED_STORE"],
        check=False, capture_output=True, text=True,
    )
    if checked.returncode != 0:
        raise SystemExit("independent checker rejected positive corpus: " + checked.stdout)
    registry = json.loads(args.registry.read_text(encoding="utf-8"))
    members = registry["bstar_members"]
    rows, primitive_count, _, _ = component_geometry(args.store, "STATE.bin")
    records = []
    violations = 0
    active_by_row: list[list[int]] = []
    for row in range(rows):
        active = [
            bstar_id for bstar_id in range(len(members))
            if get_validity(args.store, row, primitive_count + bstar_id)
        ]
        active_by_row.append(active)
        occupied: set[int] = set()
        for bstar_id in active:
            if any(get_state(args.store, row, member) != STATE_NA_FUSE
                   for member in members[bstar_id]):
                violations += 1
            if occupied.intersection(members[bstar_id]):
                violations += 1
            occupied.update(members[bstar_id])

    valid_witness = next(
        ((row, bstar_id) for row, active in enumerate(active_by_row)
         for bstar_id in active
         if all(get_state(args.store, row, member) == STATE_NA_FUSE
                for member in members[bstar_id])),
        None,
    )
    records.append((
        "valid_Bstar_all_members_NA_fuse",
        (f"row={valid_witness[0]};bstar={valid_witness[1]};"
         f"members={','.join(map(str, members[valid_witness[1]]))}"
         if valid_witness else "MISSING"),
        valid_witness is not None,
    ))

    disjoint_witness = next(
        ((row, active) for row, active in enumerate(active_by_row)
         if len(active) >= 2 and all(
             not set(members[left]).intersection(members[right])
             for position, left in enumerate(active)
             for right in active[position + 1:])),
        None,
    )
    records.append((
        "two_simultaneously_valid_disjoint_Bstar",
        (f"row={disjoint_witness[0]};bstar={','.join(map(str, disjoint_witness[1]))}"
         if disjoint_witness else "MISSING"),
        disjoint_witness is not None,
    ))

    unavailable_fuse = next(
        ((row, bstar_id) for row in range(rows) for bstar_id, member_set in enumerate(members)
         if not get_validity(args.store, row, primitive_count + bstar_id)
         and all(get_state(args.store, row, member) == STATE_NA_FUSE
                 for member in member_set)),
        None,
    )
    records.append((
        "NA_fuse_members_with_Bstar_validity_0",
        (f"row={unavailable_fuse[0]};bstar={unavailable_fuse[1]};"
         f"members={','.join(map(str, members[unavailable_fuse[1]]))}"
         if unavailable_fuse else "MISSING"),
        unavailable_fuse is not None,
    ))

    mapped_outside = next(
        ((row, primitive) for row, active in enumerate(active_by_row)
         for primitive in range(primitive_count)
         if get_state(args.store, row, primitive) == STATE_MAPPED
         and all(primitive not in members[bstar_id] for bstar_id in active)),
        None,
    )
    records.append((
        "Mapped_primitive_without_overlapping_valid_Bstar",
        (f"row={mapped_outside[0]};primitive={mapped_outside[1]}"
         if mapped_outside else "MISSING"),
        mapped_outside is not None,
    ))
    records.append((
        "full_fixture_composite_scan",
        f"rows={rows};bstar_cells={rows * len(members)};violations={violations}",
        violations == 0,
    ))

    lines = ["case\tinvariant\twitness\tresult"]
    failures = []
    for name, witness, passed in records:
        lines.append(
            f"{name}\t{INVARIANT}\t{witness}\t{'PASS' if passed else 'FAIL'}"
        )
        if not passed:
            failures.append(name)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text("\n".join(lines) + "\n", encoding="utf-8")
    if failures:
        raise SystemExit("composite positive failures: " + ",".join(failures))
    print(f"COMPOSITE_POSITIVE_CASES_PASS {len(records)}/{len(records)}")


if __name__ == "__main__":
    main()
