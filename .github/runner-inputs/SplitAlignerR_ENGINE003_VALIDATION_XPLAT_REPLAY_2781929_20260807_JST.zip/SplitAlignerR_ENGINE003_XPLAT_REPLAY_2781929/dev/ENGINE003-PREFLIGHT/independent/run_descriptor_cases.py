#!/usr/bin/env python3
"""Strict external-authority descriptor corpus for the independent checker."""

from __future__ import annotations

import argparse
import copy
import json
import subprocess
import sys
import tempfile
from pathlib import Path


MAX_ERROR_DETAIL_BYTES = 384


def canonical(value: dict) -> bytes:
    return (json.dumps(value, indent=2, ensure_ascii=True) + "\n").encode("utf-8")


def replace_once(raw: bytes, old: bytes, new: bytes) -> bytes:
    if old not in raw:
        raise RuntimeError("mutation anchor is absent")
    return raw.replace(old, new, 1)


def run(
    python: str, checker: Path, store: Path, registry: Path,
) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [python, "-B", str(checker), "--store", str(store),
         "--registry", str(registry), "--phase", "PUBLISHED_STORE"],
        check=False, capture_output=True, text=True, timeout=10,
    )


def first_code(process: subprocess.CompletedProcess[str]) -> str:
    line = process.stdout.splitlines()[0] if process.stdout else "NO_OUTPUT"
    return line.split(":", 1)[0]


def diagnostic_contract(
    process: subprocess.CompletedProcess[str],
) -> tuple[bool, int]:
    try:
        process.stdout.encode("ascii")
    except UnicodeEncodeError:
        return False, -1
    lines = process.stdout.splitlines()
    if len(lines) != 1 or ": " not in lines[0] or not process.stdout.endswith("\n"):
        return False, -1
    detail_bytes = len(lines[0].split(": ", 1)[1].encode("ascii"))
    return detail_bytes <= MAX_ERROR_DETAIL_BYTES, detail_bytes


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--checker", required=True, type=Path)
    parser.add_argument("--store", required=True, type=Path)
    parser.add_argument("--registry", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument(
        "--python", action="append", dest="pythons",
        help="Python interpreter to include; repeat for cross-version evidence",
    )
    args = parser.parse_args()
    pythons = args.pythons or [sys.executable]

    base_value = json.loads(args.registry.read_text(encoding="utf-8"))
    base_raw = canonical(base_value)
    mutations: list[tuple[str, str, bytes]] = []

    def changed(name: str, expected: str, edit) -> None:
        value = copy.deepcopy(base_value)
        edit(value)
        mutations.append((name, expected, canonical(value)))

    mutations.extend([
        ("duplicate_root_key", "E3_DESCRIPTOR", replace_once(
            base_raw, b'  "gene_ids":', b'  "gene_ids": ["evil"],\n  "gene_ids":')),
        ("duplicate_root_escaped_alias", "E3_DESCRIPTOR", replace_once(
            base_raw, b'  "gene_ids":',
            b'  "g\\u0065ne_ids": ["evil"],\n  "gene_ids":')),
        ("duplicate_primitive_key", "E3_DESCRIPTOR", replace_once(
            base_raw, b'      "terminal": true,',
            b'      "terminal": false,\n      "terminal": true,')),
        ("json_nan", "E3_DESCRIPTOR", replace_once(base_raw, b'"g0"', b'NaN')),
        ("json_infinity", "E3_DESCRIPTOR", replace_once(base_raw, b'"g0"', b'Infinity')),
        ("json_negative_infinity", "E3_DESCRIPTOR",
         replace_once(base_raw, b'"g0"', b'-Infinity')),
        ("utf8_bom", "E3_DESCRIPTOR", b"\xef\xbb\xbf" + base_raw),
        ("invalid_utf8", "E3_DESCRIPTOR", replace_once(base_raw, b'"g0"', b'"\xff"')),
        ("trailing_json_value", "E3_DESCRIPTOR", base_raw + b"{}\n"),
        ("integer_token_10000_digits", "E3_DESCRIPTOR", replace_once(
            base_raw, b'"terminal_taxon_id": 0',
            b'"terminal_taxon_id": ' + (b"9" * 10000))),
        ("json_nesting_2000_levels", "E3_DESCRIPTOR_LIMIT", replace_once(
            base_raw, b'"g0"', (b"[" * 2000) + b"0" + (b"]" * 2000))),
        ("json_nesting_depth_64_boundary", "E3_REGISTRY", replace_once(
            base_raw, b'"g0"', (b"[" * 62) + b"0" + (b"]" * 62))),
        ("json_nesting_depth_65_rejected", "E3_DESCRIPTOR_LIMIT", replace_once(
            base_raw, b'"g0"', (b"[" * 63) + b"0" + (b"]" * 63))),
        ("quoted_brackets_do_not_count", "E3_AUTHORITY", replace_once(
            base_raw, b'"g0"', b'"[[[{{{]]]}}}"')),
        ("escaped_quote_and_bracket_do_not_count", "E3_AUTHORITY", replace_once(
            base_raw, b'"g0"', b'"a\\\"[b"')),
        ("unicode_escaped_brackets_do_not_count", "E3_AUTHORITY", replace_once(
            base_raw, b'"g0"', b'"\\u005b\\u005d"')),
        ("string_token_over_1mib", "E3_DESCRIPTOR_LIMIT", replace_once(
            base_raw, b'"g0"', b'"' + (b"x" * (1024 * 1024 + 1)) + b'"')),
        ("string_token_exactly_1mib", "E3_AUTHORITY", replace_once(
            base_raw, b'"g0"', b'"' + (b"x" * (1024 * 1024)) + b'"')),
        ("array_over_250000_elements", "E3_DESCRIPTOR_LIMIT", replace_once(
            base_raw, b'"g0",\n    "g1",\n    "g2"',
            b",".join([b"0"] * 250001))),
        ("array_exactly_250000_elements", "E3_REGISTRY", replace_once(
            base_raw, b'"g0",\n    "g1",\n    "g2"',
            b",".join([b"0"] * 250000))),
        ("object_over_64_members", "E3_DESCRIPTOR_LIMIT", replace_once(
            base_raw, b'  "gene_ids":',
            b"".join(
                f'  "limit_probe_{index}": 0,\n'.encode("ascii")
                for index in range(60)
            ) + b'  "gene_ids":')),
        ("total_values_over_2000000", "E3_DESCRIPTOR_LIMIT", replace_once(
            base_raw, b'"g0",\n    "g1",\n    "g2"',
            b",".join(
                [b"[" + b",".join([b"0"] * 222223) + b"]"] * 9
            ))),
        ("raw_over_8mib", "E3_DESCRIPTOR_LIMIT",
         base_raw + (b" " * (8 * 1024 * 1024))),
        ("raw_exactly_8mib", "ACCEPT",
         base_raw + (b" " * (8 * 1024 * 1024 - len(base_raw)))),
        ("duplicate_surrogate_key", "E3_DESCRIPTOR", replace_once(
            base_raw, b'  "gene_ids":',
            b'  "\\ud800": 0,\n  "\\ud800": 1,\n  "gene_ids":')),
        ("duplicate_65536_byte_key", "E3_DESCRIPTOR", replace_once(
            base_raw, b'  "gene_ids":',
            b'  "' + (b"x" * 65536) + b'": 0,\n  "' +
            (b"x" * 65536) + b'": 1,\n  "gene_ids":')),
    ])
    changed("extra_root_key", "E3_DESCRIPTOR", lambda value: value.__setitem__("extra", 1))
    changed("missing_root_key", "E3_DESCRIPTOR", lambda value: value.pop("gene_ids"))
    changed("wrong_schema", "E3_DESCRIPTOR",
            lambda value: value.__setitem__("descriptor_schema", "wrong"))
    changed("root_taxa_not_list", "E3_DESCRIPTOR",
            lambda value: value.__setitem__("taxon_label_bytes_hex", False))
    changed("root_primitives_not_list", "E3_DESCRIPTOR",
            lambda value: value.__setitem__("primitive_entries", {}))
    changed("root_genes_not_list", "E3_DESCRIPTOR",
            lambda value: value.__setitem__("gene_ids", "g0"))
    changed("root_bstar_not_list", "E3_DESCRIPTOR",
            lambda value: value.__setitem__("bstar_members", {}))
    changed("taxon_label_element_not_string", "E3_DESCRIPTOR",
            lambda value: value["taxon_label_bytes_hex"].__setitem__(0, 1))
    changed("primitive_element_not_object", "E3_DESCRIPTOR",
            lambda value: value["primitive_entries"].__setitem__(0, "primitive"))
    changed("bstar_element_not_list", "E3_DESCRIPTOR",
            lambda value: value["bstar_members"].__setitem__(0, 0))
    changed("extra_primitive_key", "E3_DESCRIPTOR",
            lambda value: value["primitive_entries"][0].__setitem__("extra", 1))
    changed("missing_primitive_key", "E3_DESCRIPTOR",
            lambda value: value["primitive_entries"][0].pop("terminal_taxon_id"))
    changed("empty_label_hex", "E3_DESCRIPTOR",
            lambda value: value["taxon_label_bytes_hex"].__setitem__(0, ""))
    changed("odd_label_hex", "E3_DESCRIPTOR",
            lambda value: value["taxon_label_bytes_hex"].__setitem__(0, "4"))
    changed("uppercase_label_hex", "E3_DESCRIPTOR",
            lambda value: value["taxon_label_bytes_hex"].__setitem__(0, "4A"))
    changed("space_label_hex", "E3_DESCRIPTOR",
            lambda value: value["taxon_label_bytes_hex"].__setitem__(0, "41 42"))
    changed("nonhex_label", "E3_DESCRIPTOR",
            lambda value: value["taxon_label_bytes_hex"].__setitem__(0, "zz"))
    changed("terminal_id_bool", "E3_AUTHORITY",
            lambda value: value["primitive_entries"][0].__setitem__("terminal_taxon_id", True))
    changed("terminal_id_float", "E3_DESCRIPTOR",
            lambda value: value["primitive_entries"][0].__setitem__("terminal_taxon_id", 0.5))
    changed("terminal_id_string", "E3_AUTHORITY",
            lambda value: value["primitive_entries"][0].__setitem__("terminal_taxon_id", "0"))
    changed("terminal_id_negative", "E3_AUTHORITY",
            lambda value: value["primitive_entries"][0].__setitem__("terminal_taxon_id", -1))
    changed("terminal_id_u32_overflow", "E3_AUTHORITY",
            lambda value: value["primitive_entries"][0].__setitem__(
                "terminal_taxon_id", 1 << 32
            ))
    changed("terminal_flag_not_bool", "E3_AUTHORITY",
            lambda value: value["primitive_entries"][0].__setitem__("terminal", 1))
    changed("terminal_flag_string", "E3_AUTHORITY",
            lambda value: value["primitive_entries"][0].__setitem__("terminal", "true"))
    changed("split_not_string", "E3_DESCRIPTOR",
            lambda value: value["primitive_entries"][0].__setitem__(
                "authority_edge_split_hex", 1
            ))
    changed("split_odd_hex", "E3_DESCRIPTOR",
            lambda value: value["primitive_entries"][0].__setitem__(
                "authority_edge_split_hex", "1"
            ))
    changed("split_uppercase_hex", "E3_DESCRIPTOR",
            lambda value: value["primitive_entries"][0].__setitem__(
                "authority_edge_split_hex", "0A"
            ))
    changed("gene_id_not_string", "E3_REGISTRY",
            lambda value: value["gene_ids"].__setitem__(0, 0))
    changed("gene_id_invalid_unicode", "E3_REGISTRY",
            lambda value: value["gene_ids"].__setitem__(0, "\ud800"))
    changed("gene_id_duplicate", "E3_REGISTRY",
            lambda value: value["gene_ids"].__setitem__(1, value["gene_ids"][0]))
    changed("bstar_member_bool", "E3_REGISTRY",
            lambda value: value["bstar_members"][0].__setitem__(0, True))
    changed("bstar_member_float", "E3_DESCRIPTOR",
            lambda value: value["bstar_members"][0].__setitem__(0, 0.5))
    changed("bstar_member_string", "E3_REGISTRY",
            lambda value: value["bstar_members"][0].__setitem__(0, "0"))
    changed("bstar_member_negative", "E3_REGISTRY",
            lambda value: value["bstar_members"][0].__setitem__(0, -1))
    changed("bstar_member_u32_overflow", "E3_REGISTRY",
            lambda value: value["bstar_members"][0].__setitem__(0, 1 << 32))
    changed("bstar_member_duplicate", "E3_REGISTRY",
            lambda value: value["bstar_members"].__setitem__(0, [0, 0]))
    changed("bstar_member_singleton", "E3_REGISTRY",
            lambda value: value["bstar_members"].__setitem__(0, [0]))
    changed("bstar_member_out_of_order", "E3_REGISTRY",
            lambda value: value["bstar_members"].__setitem__(0, [2, 0]))
    changed("bstar_registry_duplicate", "E3_REGISTRY",
            lambda value: value.__setitem__("bstar_members", [[0, 2], [0, 2]]))
    changed("bstar_registry_wrong_byte_order", "E3_REGISTRY",
            lambda value: value["bstar_members"].reverse())

    rows = ["runtime\tcase\texpected_code\tobserved_code\treturn_code\tresult"]
    failures = []
    for python in pythons:
        version = subprocess.run(
            [python, "--version"], check=True, capture_output=True, text=True
        ).stdout.strip() or subprocess.run(
            [python, "--version"], check=True, capture_output=True, text=True
        ).stderr.strip()
        runtime = version.replace(" ", "_")
        baseline = run(python, args.checker, args.store, args.registry)
        if baseline.returncode == 0:
            rows.append(f"{runtime}\tvalid_baseline\tACCEPT\tACCEPT\t0\tPASS")
        else:
            rows.append(
                f"{runtime}\tvalid_baseline\tACCEPT\t{first_code(baseline)}\t"
                f"{baseline.returncode}\tFAIL"
            )
            failures.append(f"{runtime}:valid_baseline")

        for name, expected, raw in mutations:
            with tempfile.TemporaryDirectory(prefix="e3-descriptor-") as temporary:
                root = Path(temporary).resolve(strict=True)
                registry = root / "registry.json"
                registry.write_bytes(raw)
                process = run(python, args.checker, args.store, registry)
                observed = first_code(process)
                if expected == "ACCEPT":
                    detail_bytes = 0
                    passed = (
                        process.returncode == 0 and observed.startswith("{")
                        and not process.stderr
                    )
                    observed = "ACCEPT" if passed else observed
                else:
                    diagnostic_ok, detail_bytes = diagnostic_contract(process)
                    passed = (
                        process.returncode != 0 and observed == expected and
                        diagnostic_ok and not process.stderr
                    )
                rows.append(
                    f"{runtime}\t{name}\t{expected}\t{observed}\t"
                    f"{process.returncode}\t{'PASS' if passed else 'FAIL'}"
                )
                if not passed:
                    failures.append(
                        f"{runtime}:{name}[code={observed},rc={process.returncode},"
                        f"detail_bytes={detail_bytes},"
                        f"stderr={bool(process.stderr)}]"
                    )

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text("\n".join(rows) + "\n", encoding="utf-8")
    if failures:
        raise SystemExit("descriptor-case failures: " + ",".join(failures))
    total = len(pythons) * (len(mutations) + 1)
    print(f"DESCRIPTOR_CASES_PASS {total}/{total} runtimes={len(pythons)}")


if __name__ == "__main__":
    main()
