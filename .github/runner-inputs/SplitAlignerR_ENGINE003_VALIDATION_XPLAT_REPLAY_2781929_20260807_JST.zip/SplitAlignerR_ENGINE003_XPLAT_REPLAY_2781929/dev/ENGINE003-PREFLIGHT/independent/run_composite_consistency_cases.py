#!/usr/bin/env python3
"""Hash-refreshed adversarial corpus for CompositeRowConsistency-v1.

This disposable harness is independent of the reference encoder.  It mutates
already-published fixture bytes, refreshes every affected physical, logical and
authority binding, then requires the independent checker to reject for the
semantic reason in both prepublication and published phases.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import struct
import subprocess
import sys
import tempfile
from pathlib import Path

from run_negative_cases import (
    alter_bytes,
    get_state,
    get_validity,
    physical_cell_offset,
    refresh_semantic_hashes,
    semantic_hash_bindings_are_fresh,
    set_state,
    set_validity,
    update_manifest,
)


ERROR = "E3_COMPOSITE_ROW_CONSISTENCY"
STATE_MAPPED = 0
STATE_NA_STRUCT = 1
STATE_NA_FUSE = 2
STATE_NA_TOPO = 3


def u32(value: int) -> bytes:
    return struct.pack("<I", value)


def u64(value: int) -> bytes:
    return struct.pack("<Q", value)


def sized(value: bytes) -> bytes:
    return u64(len(value)) + value


def registry_digests(store: Path, registry: dict) -> tuple[bytes, bytes]:
    primitive = (store / "COMPLETION.bin").read_bytes()[288:320]
    encoded = [b"".join(u32(member) for member in members)
               for members in registry["bstar_members"]]
    if encoded != sorted(encoded) or len(encoded) != len(set(encoded)):
        raise RuntimeError("mutation registry is not canonically byte ordered")
    bstar_stream = bytearray(b"SplitAlignerR/BStarRegistry/v1\0")
    bstar_stream += primitive + u64(len(encoded))
    for index, value in enumerate(encoded):
        bstar_stream += u64(index) + sized(value)
    bstar = hashlib.sha256(bstar_stream).digest()
    numeric_stream = bytearray(b"SplitAlignerR/NumericCoordinateRegistry/v1\0")
    numeric_stream += primitive + u64(len(registry["primitive_entries"]))
    numeric_stream += bstar + u64(len(encoded))
    for index, value in enumerate(encoded):
        numeric_stream += u64(index) + sized(value)
    return bstar, hashlib.sha256(numeric_stream).digest()


def rebind_registry_and_refresh(
    store: Path, registry_path: Path, registry: dict, changed: set[str],
) -> tuple[str, str]:
    """Rebind a same-shape B* registry and refresh all affected hashes."""
    registry_path.write_text(json.dumps(registry, indent=2) + "\n", encoding="utf-8")
    bstar, numeric = registry_digests(store, registry)
    for name in ("NUMERIC.bin", "VALIDITY.bin"):
        path = store / name
        raw = bytearray(path.read_bytes())
        raw[192:224] = numeric
        path.write_bytes(raw)
    index_path = store / "TILE_INDEX.bin"
    index = bytearray(index_path.read_bytes())
    index[176:208] = bstar
    index[208:240] = numeric
    index_path.write_bytes(index)
    footer_path = store / "COMPLETION.bin"
    footer = bytearray(footer_path.read_bytes())
    footer[320:352] = bstar
    footer[352:384] = numeric
    footer_path.write_bytes(footer)
    update_manifest(store, {
        "bstar_registry_sha256": bstar.hex(),
        "numeric_coordinate_registry_sha256": numeric.hex(),
    })
    return refresh_semantic_hashes(
        store, changed.union({"NUMERIC.bin", "VALIDITY.bin"})
    )


def registry_bindings_are_fresh(store: Path, registry: dict) -> bool:
    bstar, numeric = registry_digests(store, registry)
    numeric_component = (store / "NUMERIC.bin").read_bytes()
    validity_component = (store / "VALIDITY.bin").read_bytes()
    index = (store / "TILE_INDEX.bin").read_bytes()
    footer = (store / "COMPLETION.bin").read_bytes()
    manifest = dict(
        line.split("=", 1)
        for line in (store / "VALIDATED").read_text(encoding="ascii").splitlines()
    )
    return (
        numeric_component[192:224] == numeric
        and validity_component[192:224] == numeric
        and index[176:208] == bstar
        and index[208:240] == numeric
        and footer[320:352] == bstar
        and footer[352:384] == numeric
        and manifest.get("bstar_registry_sha256") == bstar.hex()
        and manifest.get("numeric_coordinate_registry_sha256") == numeric.hex()
    )


def baseline_registry(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def set_numeric_zero(store: Path, row: int, coordinate: int) -> None:
    tile_offset, physical_cell = physical_cell_offset(
        store, "NUMERIC.bin", row, coordinate
    )
    alter_bytes(
        store / "NUMERIC.bin", tile_offset + physical_cell * 8, bytes(8)
    )


def mutate_member_state(
    store: Path, registry_path: Path, state_value: int,
) -> tuple[str, str, dict, str]:
    registry = baseline_registry(registry_path)
    set_state(store, 0, 0, state_value)
    old, new = refresh_semantic_hashes(store, {"STATE.bin"})
    return old, new, registry, f"row=0;bstar=0;member=0;state={state_value}"


def mutate_topo_member(
    store: Path, registry_path: Path,
) -> tuple[str, str, dict, str]:
    registry = baseline_registry(registry_path)
    # B*1 is [1,4].  Primitive 4 is the internal NA_topo witness in row 0.
    set_state(store, 0, 1, STATE_NA_FUSE)
    set_validity(store, 0, 1, False)
    set_numeric_zero(store, 0, 1)
    set_validity(store, 0, 6, True)
    old, new = refresh_semantic_hashes(
        store, {"STATE.bin", "NUMERIC.bin", "VALIDITY.bin"}
    )
    return old, new, registry, "row=0;bstar=1;member=4;state=3"


def mutate_overlap(
    store: Path, registry_path: Path,
) -> tuple[str, str, dict, str]:
    registry = baseline_registry(registry_path)
    registry["bstar_members"] = [[0, 1], [1, 2]]
    for primitive in (0, 1, 2):
        set_state(store, 0, primitive, STATE_NA_FUSE)
        set_validity(store, 0, primitive, False)
        set_numeric_zero(store, 0, primitive)
    set_validity(store, 0, 5, True)
    set_validity(store, 0, 6, True)
    old, new = rebind_registry_and_refresh(
        store, registry_path, registry,
        {"STATE.bin", "NUMERIC.bin", "VALIDITY.bin"}
    )
    return old, new, registry, "row=0;bstar=0,1;overlap_member=1"


CASES = (
    ("valid_Bstar_with_Mapped_member", lambda s, r: mutate_member_state(s, r, STATE_MAPPED)),
    ("valid_Bstar_with_NA_struct_member", lambda s, r: mutate_member_state(s, r, STATE_NA_STRUCT)),
    ("valid_Bstar_with_NA_topo_member", mutate_topo_member),
    ("two_valid_Bstar_overlap", mutate_overlap),
)


def run(checker: Path, store: Path, registry: Path, phase: str,
        checker_interface: str) -> subprocess.CompletedProcess[str]:
    if checker_interface == "bounded":
        command = [
            sys.executable, "-B", str(checker), "--store", str(store),
            "--descriptor", str(registry), "--phase", phase,
        ]
    else:
        command = [
            sys.executable, "-B", str(checker), "--store", str(store),
            "--registry", str(registry), "--phase", phase,
        ]
    return subprocess.run(
        command,
        check=False, capture_output=True, text=True,
    )


def code(process: subprocess.CompletedProcess[str]) -> str:
    output = process.stdout or process.stderr
    first = output.splitlines()[0] if output else "NO_OUTPUT"
    return first.split(":", 1)[0]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--checker", required=True, type=Path)
    parser.add_argument("--store", required=True, type=Path)
    parser.add_argument("--registry", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument(
        "--checker-interface", choices=("tiny", "bounded"), default="tiny"
    )
    args = parser.parse_args()
    header = (
        "case\texpected_code\tpublished_code\tprepublication_code\t"
        "old_logical_sha256\tnew_logical_sha256\tphysical_logical_hashes_fresh\t"
        "registry_bindings_fresh\twitness\tresult"
    )
    rows = [header]
    failures = []
    for name, mutation in CASES:
        with tempfile.TemporaryDirectory(
            prefix="e3-composite-negative-"
        ) as temporary:
            root = Path(temporary).resolve(strict=True)
            store = root / "store"
            registry_path = root / "registry.json"
            shutil.copytree(args.store, store)
            shutil.copy2(args.registry, registry_path)
            old, new, registry, witness = mutation(store, registry_path)
            hashes_fresh = old != new and semantic_hash_bindings_are_fresh(store)
            bindings_fresh = registry_bindings_are_fresh(store, registry)
            published = run(
                args.checker, store, registry_path, "PUBLISHED_STORE",
                args.checker_interface,
            )
            published_code = code(published)
            (store / "VALIDATED").unlink()
            prepublication = run(
                args.checker, store, registry_path, "PREPUBLICATION_BYTES",
                args.checker_interface,
            )
            prepublication_code = code(prepublication)
            passed = (
                published.returncode != 0 and published_code == ERROR
                and prepublication.returncode != 0 and prepublication_code == ERROR
                and hashes_fresh and bindings_fresh
            )
            rows.append(
                f"{name}\t{ERROR}\t{published_code}\t{prepublication_code}\t"
                f"{old}\t{new}\t{str(hashes_fresh).upper()}\t"
                f"{str(bindings_fresh).upper()}\t{witness}\t"
                f"{'PASS' if passed else 'FAIL'}"
            )
            if not passed:
                failures.append(
                    (name, published.stdout, published.stderr,
                     prepublication.stdout, prepublication.stderr)
                )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text("\n".join(rows) + "\n", encoding="utf-8")
    if failures:
        for failure in failures:
            print(failure)
        raise SystemExit(f"composite consistency failures: {len(failures)}")
    print(f"COMPOSITE_CONSISTENCY_CASES_PASS {len(CASES)}/{len(CASES)}")


if __name__ == "__main__":
    main()
