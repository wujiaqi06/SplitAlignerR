#!/usr/bin/env python3
"""Disposable adversarial mutations for the independent preflight checker."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import shutil
import struct
import subprocess
import sys
import tempfile
from pathlib import Path


HEADER = 256
ENTRY = 128
TILE_ROWS = 256
TILE_COLS = 256
U64_MAX = (1 << 64) - 1
SEMANTIC_ERROR = "E3_PRIMITIVE_ROW_CONSISTENCY"


COMPONENT_META = {
    "STATE.bin": (0, 64, "state_sha256"),
    "NUMERIC.bin": (1, 96, "numeric_sha256"),
    "VALIDITY.bin": (2, 128, "validity_sha256"),
}


def sha256(path: Path) -> bytes:
    return hashlib.sha256(path.read_bytes()).digest()


def write_ascii_lf(path: Path, value: str) -> None:
    with path.open("w", encoding="ascii", newline="\n") as handle:
        handle.write(value)


def u16(value: int) -> bytes:
    return struct.pack("<H", value)


def u64(value: int) -> bytes:
    return struct.pack("<Q", value)


def sized(value: bytes) -> bytes:
    return u64(len(value)) + value


def update_manifest(store: Path, replacements: dict[str, str]) -> None:
    path = store / "VALIDATED"
    lines = path.read_text(encoding="ascii").splitlines()
    output = []
    observed = set()
    for line in lines:
        key, value = line.split("=", 1)
        if key in replacements:
            value = replacements[key]
            observed.add(key)
        output.append(f"{key}={value}")
    if observed != set(replacements):
        raise RuntimeError("manifest replacement key mismatch")
    path.write_text("\n".join(output) + "\n", encoding="ascii")


def rebind_mutated_component(store: Path, component_name: str) -> None:
    """Refresh physical hashes so semantic checks, not stale hashes, reject."""
    entry_position, footer_hash_offset, manifest_key = COMPONENT_META[component_name]
    component_path = store / component_name
    component = component_path.read_bytes()
    index_path = store / "TILE_INDEX.bin"
    index = bytearray(index_path.read_bytes())
    tile_hash_offset = HEADER + entry_position * ENTRY + 80
    index[tile_hash_offset:tile_hash_offset + 32] = hashlib.sha256(component[HEADER:]).digest()
    index_path.write_bytes(index)

    footer_path = store / "COMPLETION.bin"
    footer = bytearray(footer_path.read_bytes())
    footer[footer_hash_offset:footer_hash_offset + 32] = hashlib.sha256(component).digest()
    footer[160:192] = hashlib.sha256(index).digest()
    footer_path.write_bytes(footer)
    update_manifest(store, {
        manifest_key: hashlib.sha256(component).hexdigest(),
        "index_sha256": hashlib.sha256(index).hexdigest(),
        "footer_sha256": hashlib.sha256(footer).hexdigest(),
    })


def component_geometry(store: Path, name: str) -> tuple[int, int, int, int]:
    raw = (store / name).read_bytes()
    return (
        struct.unpack_from("<Q", raw, 32)[0],
        struct.unpack_from("<Q", raw, 40)[0],
        struct.unpack_from("<Q", raw, 56)[0],
        struct.unpack_from("<Q", raw, 72)[0],
    )


def physical_cell_offset(store: Path, name: str, row: int, column: int) -> tuple[int, int]:
    rows, columns, tile_columns, tile_bytes = component_geometry(store, name)
    if not 0 <= row < rows or not 0 <= column < columns:
        raise RuntimeError(f"logical cell outside {name}")
    tile_row, local_row = divmod(row, TILE_ROWS)
    tile_column, local_column = divmod(column, TILE_COLS)
    tile_offset = HEADER + (tile_row * tile_columns + tile_column) * tile_bytes
    return tile_offset, local_row * TILE_COLS + local_column


def get_state(store: Path, row: int, primitive: int) -> int:
    tile_offset, physical_cell = physical_cell_offset(
        store, "STATE.bin", row, primitive
    )
    return (store / "STATE.bin").read_bytes()[tile_offset + physical_cell]


def set_state(store: Path, row: int, primitive: int, state: int) -> None:
    tile_offset, physical_cell = physical_cell_offset(
        store, "STATE.bin", row, primitive
    )
    alter_byte(store / "STATE.bin", tile_offset + physical_cell, state)


def get_validity(store: Path, row: int, coordinate: int) -> bool:
    tile_offset, physical_cell = physical_cell_offset(
        store, "VALIDITY.bin", row, coordinate
    )
    raw = (store / "VALIDITY.bin").read_bytes()
    return bool(raw[tile_offset + physical_cell // 8] & (1 << (physical_cell % 8)))


def set_validity(store: Path, row: int, coordinate: int, present: bool) -> None:
    tile_offset, physical_cell = physical_cell_offset(
        store, "VALIDITY.bin", row, coordinate
    )
    path = store / "VALIDITY.bin"
    raw = bytearray(path.read_bytes())
    offset = tile_offset + physical_cell // 8
    mask = 1 << (physical_cell % 8)
    raw[offset] = (raw[offset] | mask) if present else (raw[offset] & ~mask)
    path.write_bytes(raw)


def get_numeric_bits(store: Path, row: int, coordinate: int) -> bytes:
    tile_offset, physical_cell = physical_cell_offset(
        store, "NUMERIC.bin", row, coordinate
    )
    offset = tile_offset + physical_cell * 8
    return (store / "NUMERIC.bin").read_bytes()[offset:offset + 8]


def logical_component_streams(store: Path) -> tuple[bytes, bytes, bytes]:
    state_rows, primitive_count, _, _ = component_geometry(store, "STATE.bin")
    numeric_rows, numeric_count, _, _ = component_geometry(store, "NUMERIC.bin")
    validity_rows, validity_count, _, _ = component_geometry(store, "VALIDITY.bin")
    if (state_rows, numeric_rows, validity_rows) != (state_rows, state_rows, state_rows):
        raise RuntimeError("row geometry mismatch while refreshing logical digest")
    if numeric_count != validity_count:
        raise RuntimeError("numeric geometry mismatch while refreshing logical digest")
    state = bytearray()
    numeric = bytearray()
    validity = bytearray((state_rows * numeric_count + 7) // 8)
    for row in range(state_rows):
        for primitive in range(primitive_count):
            state.append(get_state(store, row, primitive))
        for coordinate in range(numeric_count):
            numeric += get_numeric_bits(store, row, coordinate)
            if get_validity(store, row, coordinate):
                logical_cell = row * numeric_count + coordinate
                validity[logical_cell // 8] |= 1 << (logical_cell % 8)
    return bytes(state), bytes(numeric), bytes(validity)


def logical_content_sha256(store: Path) -> bytes:
    rows, primitive_count, _, _ = component_geometry(store, "STATE.bin")
    _, numeric_count, _, _ = component_geometry(store, "NUMERIC.bin")
    bstar_count = numeric_count - primitive_count
    footer = (store / "COMPLETION.bin").read_bytes()
    species, genes = footer[224:256], footer[256:288]
    primitive, bstar = footer[288:320], footer[320:352]
    numeric_registry = footer[352:384]
    state, numeric, validity = logical_component_streams(store)
    stream = bytearray(b"SplitAlignerR/MatrixLogicalContent/v1\0")
    stream += u16(1) + u16(0)
    stream += u64(rows) + u64(primitive_count) + u64(bstar_count) + u64(numeric_count)
    stream += species + genes + primitive + bstar + numeric_registry
    stream += sized(state) + sized(numeric) + sized(validity)
    return hashlib.sha256(stream).digest()


def refresh_semantic_hashes(store: Path, component_names: set[str]) -> tuple[str, str]:
    """Refresh tile/component/index/logical/footer/manifest hashes after mutation."""
    old_logical = (store / "COMPLETION.bin").read_bytes()[192:224].hex()
    index_path = store / "TILE_INDEX.bin"
    index = bytearray(index_path.read_bytes())
    entry_count = struct.unpack_from("<Q", index, 24)[0]
    component_types = {"STATE.bin": 1, "NUMERIC.bin": 2, "VALIDITY.bin": 3}
    raw_components = {name: (store / name).read_bytes() for name in component_names}
    for position in range(entry_count):
        base = HEADER + position * ENTRY
        component_type = struct.unpack_from("<H", index, base)[0]
        matching_name = next(
            (name for name, value in component_types.items() if value == component_type),
            None,
        )
        if matching_name not in component_names:
            continue
        offset = struct.unpack_from("<Q", index, base + 48)[0]
        length = struct.unpack_from("<Q", index, base + 56)[0]
        payload = raw_components[matching_name][offset:offset + length]
        index[base + 80:base + 112] = hashlib.sha256(payload).digest()
    index_path.write_bytes(index)

    new_logical = logical_content_sha256(store)
    footer_path = store / "COMPLETION.bin"
    footer = bytearray(footer_path.read_bytes())
    footer_offsets = {"STATE.bin": 64, "NUMERIC.bin": 96, "VALIDITY.bin": 128}
    manifest_replacements = {
        "logical_content_sha256": new_logical.hex(),
        "index_sha256": hashlib.sha256(index).hexdigest(),
    }
    manifest_keys = {
        "STATE.bin": "state_sha256",
        "NUMERIC.bin": "numeric_sha256",
        "VALIDITY.bin": "validity_sha256",
    }
    for name in component_names:
        raw = raw_components[name]
        footer[footer_offsets[name]:footer_offsets[name] + 32] = hashlib.sha256(raw).digest()
        manifest_replacements[manifest_keys[name]] = hashlib.sha256(raw).hexdigest()
    footer[160:192] = hashlib.sha256(index).digest()
    footer[192:224] = new_logical
    footer_path.write_bytes(footer)
    manifest_replacements["footer_sha256"] = hashlib.sha256(footer).hexdigest()
    update_manifest(store, manifest_replacements)
    return old_logical, new_logical.hex()


def semantic_hash_bindings_are_fresh(store: Path) -> bool:
    """Independently confirm all physical and aggregate bindings after mutation."""
    components = {
        "STATE.bin": (1, 64, "state_sha256"),
        "NUMERIC.bin": (2, 96, "numeric_sha256"),
        "VALIDITY.bin": (3, 128, "validity_sha256"),
    }
    component_bytes = {
        name: (store / name).read_bytes() for name in components
    }
    index = (store / "TILE_INDEX.bin").read_bytes()
    entry_count = struct.unpack_from("<Q", index, 24)[0]
    by_type = {value[0]: name for name, value in components.items()}
    for position in range(entry_count):
        base = HEADER + position * ENTRY
        component_type = struct.unpack_from("<H", index, base)[0]
        if component_type not in by_type:
            return False
        raw = component_bytes[by_type[component_type]]
        offset = struct.unpack_from("<Q", index, base + 48)[0]
        length = struct.unpack_from("<Q", index, base + 56)[0]
        if hashlib.sha256(raw[offset:offset + length]).digest() != index[base + 80:base + 112]:
            return False
    footer = (store / "COMPLETION.bin").read_bytes()
    for name, (_component_type, footer_offset, _manifest_key) in components.items():
        if hashlib.sha256(component_bytes[name]).digest() != footer[footer_offset:footer_offset + 32]:
            return False
    if hashlib.sha256(index).digest() != footer[160:192]:
        return False
    logical = logical_content_sha256(store)
    if logical != footer[192:224]:
        return False
    manifest = dict(
        line.split("=", 1)
        for line in (store / "VALIDATED").read_text(encoding="ascii").splitlines()
    )
    for name, (_component_type, _footer_offset, manifest_key) in components.items():
        if manifest.get(manifest_key) != hashlib.sha256(component_bytes[name]).hexdigest():
            return False
    return (
        manifest.get("index_sha256") == hashlib.sha256(index).hexdigest()
        and manifest.get("footer_sha256") == hashlib.sha256(footer).hexdigest()
        and manifest.get("logical_content_sha256") == logical.hex()
    )


def alter_byte(path: Path, offset: int, value: int) -> None:
    data = bytearray(path.read_bytes())
    data[offset] = value
    path.write_bytes(data)


def alter_bytes(path: Path, offset: int, value: bytes) -> None:
    data = bytearray(path.read_bytes())
    data[offset:offset + len(value)] = value
    path.write_bytes(data)


def missing_manifest(store: Path, registry: Path, source: Path) -> None:
    (store / "VALIDATED").unlink()


def undeclared_entry(store: Path, registry: Path, source: Path) -> None:
    (store / "diagnostic.txt").write_text("undeclared\n", encoding="ascii")


def component_symlink(store: Path, registry: Path, source: Path) -> None:
    target = store / "STATE.bin"
    target.unlink()
    target.symlink_to(source / "STATE.bin")


def store_symlink(store: Path, registry: Path, source: Path) -> None:
    actual = store.with_name("actual-store")
    store.rename(actual)
    store.symlink_to(actual.name, target_is_directory=True)


def state_padding(store: Path, registry: Path, source: Path) -> None:
    _, columns, _, _ = component_geometry(store, "STATE.bin")
    if columns >= TILE_COLS:
        raise RuntimeError("tiny negative fixture unexpectedly lacks first-row state padding")
    alter_byte(store / "STATE.bin", HEADER + columns, 1)
    rebind_mutated_component(store, "STATE.bin")


def numeric_padding(store: Path, registry: Path, source: Path) -> None:
    _, columns, _, _ = component_geometry(store, "NUMERIC.bin")
    if columns >= TILE_COLS:
        raise RuntimeError("tiny negative fixture unexpectedly lacks first-row numeric padding")
    alter_bytes(store / "NUMERIC.bin", HEADER + columns * 8, struct.pack("<d", 1.0))
    rebind_mutated_component(store, "NUMERIC.bin")


def validity_padding(store: Path, registry: Path, source: Path) -> None:
    _, columns, _, _ = component_geometry(store, "VALIDITY.bin")
    if columns >= TILE_COLS:
        raise RuntimeError("tiny negative fixture unexpectedly lacks first-row validity padding")
    data = bytearray((store / "VALIDITY.bin").read_bytes())
    data[HEADER + columns // 8] |= 1 << (columns % 8)
    (store / "VALIDITY.bin").write_bytes(data)
    rebind_mutated_component(store, "VALIDITY.bin")


def invalid_numeric_payload(store: Path, registry: Path, source: Path) -> None:
    rows, columns, _, _ = component_geometry(store, "NUMERIC.bin")
    target = next(
        ((row, column) for row in range(rows) for column in range(columns)
         if not get_validity(store, row, column)),
        None,
    )
    if target is None:
        raise RuntimeError("tiny negative fixture lacks validity=0 logical cell")
    tile_offset, physical_cell = physical_cell_offset(
        store, "NUMERIC.bin", target[0], target[1]
    )
    alter_bytes(
        store / "NUMERIC.bin", tile_offset + physical_cell * 8,
        struct.pack("<d", 1.0),
    )
    rebind_mutated_component(store, "NUMERIC.bin")


def invalid_state_code(store: Path, registry: Path, source: Path) -> None:
    set_state(store, 0, 0, 4)
    rebind_mutated_component(store, "STATE.bin")


def valid_nan(store: Path, registry: Path, source: Path) -> None:
    rows, columns, _, _ = component_geometry(store, "NUMERIC.bin")
    target = next(
        ((row, column) for row in range(rows) for column in range(columns)
         if get_validity(store, row, column)),
        None,
    )
    if target is None:
        raise RuntimeError("tiny negative fixture lacks validity=1 logical cell")
    tile_offset, physical_cell = physical_cell_offset(
        store, "NUMERIC.bin", target[0], target[1]
    )
    alter_bytes(
        store / "NUMERIC.bin", tile_offset + physical_cell * 8,
        bytes.fromhex("000000000000f87f"),
    )
    rebind_mutated_component(store, "NUMERIC.bin")


def tile_corruption(store: Path, registry: Path, source: Path) -> None:
    alter_byte(store / "STATE.bin", HEADER, 1)


def index_duplicate(store: Path, registry: Path, source: Path) -> None:
    path = store / "TILE_INDEX.bin"
    data = bytearray(path.read_bytes())
    data[HEADER + ENTRY:HEADER + 2 * ENTRY] = data[HEADER:HEADER + ENTRY]
    path.write_bytes(data)


def registry_mismatch(store: Path, registry: Path, source: Path) -> None:
    text = registry.read_text(encoding="utf-8")
    registry.write_text(text.replace('"g2"', '"changed-g2"'), encoding="utf-8")


def zero_primitive_nonzero_bstar(store: Path, registry: Path, source: Path) -> None:
    value = json.loads(registry.read_text(encoding="utf-8"))
    value["primitive_entries"] = []
    value["bstar_members"] = [[0, 1]]
    registry.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


def footer_length(store: Path, registry: Path, source: Path) -> None:
    path = store / "COMPLETION.bin"
    data = bytearray(path.read_bytes())
    value = struct.unpack_from("<Q", data, 32)[0]
    struct.pack_into("<Q", data, 32, value + 1)
    path.write_bytes(data)


def manifest_crlf(store: Path, registry: Path, source: Path) -> None:
    path = store / "VALIDATED"
    path.write_bytes(path.read_bytes().replace(b"\n", b"\r\n"))


def manifest_noncanonical_decimal(store: Path, registry: Path, source: Path) -> None:
    path = store / "VALIDATED"
    raw = path.read_text(encoding="ascii")
    raw = re.sub(r"(?m)^row_count=([0-9]+)$", r"row_count=0\1", raw)
    write_ascii_lf(path, raw)


def manifest_decimal_overflow(store: Path, registry: Path, source: Path) -> None:
    path = store / "VALIDATED"
    raw = path.read_text(encoding="ascii")
    raw = re.sub(
        r"(?m)^row_count=[0-9]+$", f"row_count={U64_MAX + 1}", raw,
    )
    write_ascii_lf(path, raw)


def manifest_decimal_digit_bomb(store: Path, registry: Path, source: Path) -> None:
    path = store / "VALIDATED"
    raw = path.read_text(encoding="ascii")
    raw = re.sub(r"(?m)^row_count=[0-9]+$", "row_count=" + "9" * 5000, raw)
    write_ascii_lf(path, raw)


def manifest_over_8k(store: Path, registry: Path, source: Path) -> None:
    path = store / "VALIDATED"
    raw = path.read_text(encoding="ascii")
    raw = re.sub(r"(?m)^row_count=[0-9]+$", "row_count=" + "9" * 9000, raw)
    write_ascii_lf(path, raw)


def manifest_uppercase_digest(store: Path, registry: Path, source: Path) -> None:
    path = store / "VALIDATED"
    raw = path.read_text(encoding="ascii")
    raw = re.sub(
        r"(?m)^state_sha256=([0-9a-f]+)$",
        lambda match: "state_sha256=" + match.group(1).upper(),
        raw,
    )
    write_ascii_lf(path, raw)


def footer_trailing_byte(store: Path, registry: Path, source: Path) -> None:
    path = store / "COMPLETION.bin"
    path.write_bytes(path.read_bytes() + b"\x00")


def index_entry_count_overflow(store: Path, registry: Path, source: Path) -> None:
    path = store / "TILE_INDEX.bin"
    raw = bytearray(path.read_bytes())
    struct.pack_into("<Q", raw, 24, U64_MAX)
    path.write_bytes(raw)


def trailing_byte(store: Path, registry: Path, source: Path) -> None:
    path = store / "NUMERIC.bin"
    path.write_bytes(path.read_bytes() + b"\x00")


def rewrite_registry(registry: Path, transform) -> None:
    value = json.loads(registry.read_text(encoding="utf-8"))
    transform(value)
    registry.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


def zero_taxa(store: Path, registry: Path, source: Path) -> None:
    rewrite_registry(registry, lambda value: value.__setitem__("taxon_label_bytes_hex", []))


def empty_taxon_label(store: Path, registry: Path, source: Path) -> None:
    rewrite_registry(registry, lambda value: value["taxon_label_bytes_hex"].__setitem__(0, ""))


def duplicate_taxon_label(store: Path, registry: Path, source: Path) -> None:
    rewrite_registry(
        registry,
        lambda value: value["taxon_label_bytes_hex"].__setitem__(
            1, value["taxon_label_bytes_hex"][0]
        ),
    )


def primitive_update(registry: Path, terminal: bool, taxon_id: int, split_hex: str) -> None:
    def transform(value):
        value["primitive_entries"][0] = {
            "terminal": terminal,
            "terminal_taxon_id": taxon_id,
            "authority_edge_split_hex": split_hex,
        }
    rewrite_registry(registry, transform)


def wrong_terminal_singleton(store: Path, registry: Path, source: Path) -> None:
    primitive_update(registry, True, 0, "02")


def terminal_out_of_range(store: Path, registry: Path, source: Path) -> None:
    primitive_update(registry, True, 4, "01")


def internal_nonsentinel_id(store: Path, registry: Path, source: Path) -> None:
    primitive_update(registry, False, 0, "03")


def internal_empty_side(store: Path, registry: Path, source: Path) -> None:
    primitive_update(registry, False, 0xFFFFFFFF, "00")


def internal_full_side(store: Path, registry: Path, source: Path) -> None:
    primitive_update(registry, False, 0xFFFFFFFF, "0f")


def internal_larger_side(store: Path, registry: Path, source: Path) -> None:
    primitive_update(registry, False, 0xFFFFFFFF, "07")


def internal_tie_wrong_lex(store: Path, registry: Path, source: Path) -> None:
    primitive_update(registry, False, 0xFFFFFFFF, "0c")


def nonzero_split_padding(store: Path, registry: Path, source: Path) -> None:
    primitive_update(registry, True, 0, "11")


def empty_gene_id(store: Path, registry: Path, source: Path) -> None:
    rewrite_registry(registry, lambda value: value["gene_ids"].__setitem__(0, ""))


def nul_gene_id(store: Path, registry: Path, source: Path) -> None:
    rewrite_registry(registry, lambda value: value["gene_ids"].__setitem__(0, "g\0bad"))


def find_primitive_cell(store: Path, registry: Path, predicate) -> tuple[int, int]:
    authority = json.loads(registry.read_text(encoding="utf-8"))
    rows, primitive_count, _, _ = component_geometry(store, "STATE.bin")
    primitives = authority["primitive_entries"]
    if len(primitives) != primitive_count:
        raise RuntimeError("fixture primitive authority/axis mismatch")
    for row in range(rows):
        for primitive, entry in enumerate(primitives):
            state = get_state(store, row, primitive)
            valid = get_validity(store, row, primitive)
            if predicate(entry, state, valid):
                return row, primitive
    raise RuntimeError("fixture lacks required semantic mutation source cell")


def semantic_record(
    store: Path, row: int, primitive: int, changed: set[str]
) -> tuple[str, str, int, int, int, int]:
    old_logical, new_logical = refresh_semantic_hashes(store, changed)
    return (
        old_logical, new_logical, row, primitive,
        get_state(store, row, primitive),
        int(get_validity(store, row, primitive)),
    )


def terminal_na_topo_semantic(
    store: Path, registry: Path, source: Path
) -> tuple[str, str, int, int, int, int]:
    row, primitive = find_primitive_cell(
        store, registry,
        lambda entry, state, valid: entry["terminal"] and not valid,
    )
    set_state(store, row, primitive, 3)
    return semantic_record(store, row, primitive, {"STATE.bin"})


def na_struct_valid_semantic(
    store: Path, registry: Path, source: Path
) -> tuple[str, str, int, int, int, int]:
    row, primitive = find_primitive_cell(
        store, registry,
        lambda entry, state, valid: state == 0 and valid,
    )
    set_state(store, row, primitive, 1)
    return semantic_record(store, row, primitive, {"STATE.bin"})


def na_fuse_valid_semantic(
    store: Path, registry: Path, source: Path
) -> tuple[str, str, int, int, int, int]:
    row, primitive = find_primitive_cell(
        store, registry,
        lambda entry, state, valid: state == 0 and valid,
    )
    set_state(store, row, primitive, 2)
    return semantic_record(store, row, primitive, {"STATE.bin"})


def na_topo_valid_semantic(
    store: Path, registry: Path, source: Path
) -> tuple[str, str, int, int, int, int]:
    row, primitive = find_primitive_cell(
        store, registry,
        lambda entry, state, valid: not entry["terminal"] and state == 3 and not valid,
    )
    set_validity(store, row, primitive, True)
    return semantic_record(store, row, primitive, {"VALIDITY.bin"})


CASES = [
    ("missing_manifest", "E3_INCOMPLETE", missing_manifest),
    ("undeclared_entry", "E3_UNDECLARED_ENTRY", undeclared_entry),
    ("store_symlink", "E3_STORE_PATH", store_symlink),
    ("component_symlink", "E3_SYMLINK_OR_OPEN", component_symlink),
    ("state_padding", "E3_PADDING", state_padding),
    ("numeric_padding", "E3_PADDING", numeric_padding),
    ("validity_padding", "E3_PADDING", validity_padding),
    ("invalid_numeric_payload", "E3_NUMERIC", invalid_numeric_payload),
    ("invalid_state_code", "E3_STATE", invalid_state_code),
    ("valid_nan", "E3_NUMERIC", valid_nan),
    ("tile_corruption", "E3_TILE_HASH", tile_corruption),
    ("index_duplicate", "E3_INDEX_ORDER", index_duplicate),
    ("registry_mismatch", "E3_AUTHORITY", registry_mismatch),
    ("zero_primitive_nonzero_bstar", "E3_REGISTRY", zero_primitive_nonzero_bstar),
    ("footer_length", "E3_FOOTER", footer_length),
    ("manifest_crlf", "E3_MANIFEST_GRAMMAR", manifest_crlf),
    ("manifest_noncanonical_decimal", "E3_MANIFEST_GRAMMAR", manifest_noncanonical_decimal),
    ("manifest_decimal_overflow", "E3_OVERFLOW", manifest_decimal_overflow),
    ("manifest_uppercase_digest", "E3_MANIFEST_GRAMMAR", manifest_uppercase_digest),
    ("footer_trailing_byte", "E3_FOOTER", footer_trailing_byte),
    ("index_entry_count_overflow", "E3_OVERFLOW", index_entry_count_overflow),
    ("trailing_byte", "E3_LENGTH", trailing_byte),
    ("zero_taxa", "E3_AUTHORITY", zero_taxa),
    ("empty_taxon_label", "E3_DESCRIPTOR", empty_taxon_label),
    ("duplicate_taxon_label", "E3_AUTHORITY", duplicate_taxon_label),
    ("wrong_terminal_singleton", "E3_AUTHORITY", wrong_terminal_singleton),
    ("terminal_out_of_range", "E3_AUTHORITY", terminal_out_of_range),
    ("internal_nonsentinel_id", "E3_AUTHORITY", internal_nonsentinel_id),
    ("internal_empty_side", "E3_AUTHORITY", internal_empty_side),
    ("internal_full_side", "E3_AUTHORITY", internal_full_side),
    ("internal_larger_side", "E3_AUTHORITY", internal_larger_side),
    ("internal_tie_wrong_lex", "E3_AUTHORITY", internal_tie_wrong_lex),
    ("nonzero_split_padding", "E3_AUTHORITY", nonzero_split_padding),
    ("empty_gene_id", "E3_REGISTRY", empty_gene_id),
    ("nul_gene_id", "E3_REGISTRY", nul_gene_id),
]


BOUNDED_ONLY_CASES = [
    ("manifest_decimal_digit_bomb", "E3_OVERFLOW", manifest_decimal_digit_bomb),
    ("manifest_over_8k", "E3_MANIFEST_GRAMMAR", manifest_over_8k),
]


SEMANTIC_CASES = [
    ("terminal_NA_topo", SEMANTIC_ERROR, terminal_na_topo_semantic),
    ("NA_struct_with_primitive_validity_1", SEMANTIC_ERROR, na_struct_valid_semantic),
    ("NA_fuse_with_primitive_validity_1", SEMANTIC_ERROR, na_fuse_valid_semantic),
    ("NA_topo_with_primitive_validity_1", SEMANTIC_ERROR, na_topo_valid_semantic),
]


def run(
    checker: Path, store: Path, registry: Path,
    phase: str = "PUBLISHED_STORE",
    checker_interface: str = "tiny",
) -> subprocess.CompletedProcess[str]:
    if checker_interface == "bounded":
        command = [
            sys.executable, "-B", str(checker), "--store", str(store),
            "--descriptor", str(registry), "--phase", phase,
        ]
    else:
        command = [
            sys.executable, "-B", str(checker), "--store", str(store),
            "--registry", str(registry), "--phase", phase,
        ]
    return subprocess.run(
        command,
        check=False, capture_output=True, text=True
    )


def first_output(result: subprocess.CompletedProcess[str]) -> str:
    output = result.stdout or result.stderr
    return output.splitlines()[0] if output else "NO_OUTPUT"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--checker", required=True, type=Path)
    parser.add_argument("--store", required=True, type=Path)
    parser.add_argument("--registry", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--semantic-output", type=Path)
    parser.add_argument(
        "--checker-interface", choices=("tiny", "bounded"), default="tiny"
    )
    args = parser.parse_args()

    baseline = run(
        args.checker, args.store, args.registry,
        checker_interface=args.checker_interface,
    )
    if baseline.returncode != 0:
        raise SystemExit(f"baseline checker failed: {baseline.stdout}{baseline.stderr}")
    rows = ["case\texpected_code\tobserved_code\treturn_code\tresult"]
    semantic_rows = [
        "case\texpected_code\tpublished_observed_code\tpublished_return_code\t"
        "prepublication_observed_code\tprepublication_return_code\t"
        "row\tprimitive_id\tmutated_state\tmutated_validity\t"
        "old_logical_sha256\tnew_logical_sha256\thashes_refreshed\tresult"
    ]
    failures = []
    active_cases = CASES + (
        BOUNDED_ONLY_CASES if args.checker_interface == "bounded" else []
    )
    for name, expected, mutation in active_cases:
        with tempfile.TemporaryDirectory(prefix="e3-negative-") as temporary:
            # macOS exposes /var as a platform symlink to /private/var. Resolve
            # the trusted tempfile root before exercising the checker's strict
            # no-follow path traversal.
            root = Path(temporary).resolve(strict=True)
            copy_store = root / "store"
            copy_registry = root / "registry.json"
            shutil.copytree(args.store, copy_store, symlinks=False)
            shutil.copy2(args.registry, copy_registry)
            mutation(copy_store, copy_registry, args.store)
            result = run(
                args.checker, copy_store, copy_registry,
                checker_interface=args.checker_interface,
            )
            first = first_output(result)
            observed = first.split(":", 1)[0]
            passed = result.returncode != 0 and observed == expected
            rows.append(f"{name}\t{expected}\t{observed}\t{result.returncode}\t"
                        f"{'PASS' if passed else 'FAIL'}")
            if not passed:
                failures.append((name, expected, first, result.stderr))
    for name, expected, mutation in SEMANTIC_CASES:
        with tempfile.TemporaryDirectory(prefix="e3-semantic-negative-") as temporary:
            root = Path(temporary).resolve(strict=True)
            copy_store = root / "store"
            copy_registry = root / "registry.json"
            shutil.copytree(args.store, copy_store, symlinks=False)
            shutil.copy2(args.registry, copy_registry)
            (old_logical, new_logical, row, primitive, mutated_state,
             mutated_validity) = mutation(copy_store, copy_registry, args.store)
            hashes_refreshed = (
                old_logical != new_logical
                and semantic_hash_bindings_are_fresh(copy_store)
            )
            published_result = run(
                args.checker, copy_store, copy_registry,
                checker_interface=args.checker_interface,
            )
            published_first = first_output(published_result)
            published_observed = published_first.split(":", 1)[0]
            (copy_store / "VALIDATED").unlink()
            prepublication_result = run(
                args.checker, copy_store, copy_registry, "PREPUBLICATION_BYTES",
                args.checker_interface,
            )
            prepublication_first = first_output(prepublication_result)
            prepublication_observed = prepublication_first.split(":", 1)[0]
            passed = (
                published_result.returncode != 0
                and published_observed == expected
                and prepublication_result.returncode != 0
                and prepublication_observed == expected
                and hashes_refreshed
            )
            rows.append(
                f"{name}\t{expected}\t{published_observed}\t"
                f"{published_result.returncode}\t"
                f"{'PASS' if passed else 'FAIL'}"
            )
            semantic_rows.append(
                f"{name}\t{expected}\t{published_observed}\t"
                f"{published_result.returncode}\t{prepublication_observed}\t"
                f"{prepublication_result.returncode}\t{row}\t{primitive}\t"
                f"{mutated_state}\t{mutated_validity}\t"
                f"{old_logical}\t{new_logical}\t"
                f"{'PASS' if hashes_refreshed else 'FAIL'}\t"
                f"{'PASS' if passed else 'FAIL'}"
            )
            if not passed:
                failures.append((
                    name, expected, published_first, prepublication_first,
                    published_result.stderr, prepublication_result.stderr,
                ))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text("\n".join(rows) + "\n", encoding="utf-8")
    if args.semantic_output is not None:
        args.semantic_output.parent.mkdir(parents=True, exist_ok=True)
        args.semantic_output.write_text(
            "\n".join(semantic_rows) + "\n", encoding="utf-8"
        )
    if failures:
        for item in failures:
            print(item)
        raise SystemExit(f"negative-case failures: {len(failures)}")
    total = len(active_cases) + len(SEMANTIC_CASES)
    print(f"NEGATIVE_CASES_PASS {total}/{total}")


if __name__ == "__main__":
    main()
