// Independent dev-only cross-check against the frozen ENGINE002 authority API.
// This file is not compiled into the package and changes no production source.

#include "engine002_hash.h"
#include "engine002_species_authority_binding.h"

#include <cstdint>
#include <exception>
#include <iostream>
#include <string>
#include <vector>

namespace e2 = splitaligner::engine002;

bool rejects(const std::vector<std::string>& labels,
             const std::vector<std::uint32_t>& terminal,
             const std::vector<std::vector<std::uint8_t>>& splits) {
  try {
    (void)e2::make_species_authority(labels, terminal, splits);
    return false;
  } catch (const std::exception&) {
    return true;
  }
}

int main() {
  const std::vector<std::string> labels{"A", "B", "C", "D"};
  const std::vector<std::uint32_t> terminal{0U, 1U, 2U, 3U};
  const std::vector<std::vector<std::uint8_t>> splits{
      {0x01U}, {0x02U}, {0x04U}, {0x08U}};
  const auto authority = e2::make_species_authority(labels, terminal, splits);
  std::cout << "valid_species_authority_sha256="
            << e2::hex_lower(authority->fingerprint) << "\n";

  const std::vector<std::string> raw_labels{
      std::string(1, static_cast<char>(0xff)), "B"};
  const std::vector<std::uint32_t> raw_terminal{0U, 1U};
  const std::vector<std::vector<std::uint8_t>> raw_splits{{0x01U}, {0x02U}};
  const auto raw_authority =
      e2::make_species_authority(raw_labels, raw_terminal, raw_splits);
  const std::string raw_digest = e2::hex_lower(raw_authority->fingerprint);
  const std::string expected_raw_digest =
      "591b83db63e8100d81f27959db30e3314ff213196cb0fa2f4f18dca3f1f8b838";
  const bool raw_digest_equal = raw_digest == expected_raw_digest;
  std::cout << "raw_ff_species_authority_sha256=" << raw_digest << "\n";
  std::cout << "raw_ff_expected_equal="
            << (raw_digest_equal ? "TRUE" : "FALSE") << "\n";

  const bool duplicate_rejected =
      rejects({"A", "A", "C", "D"}, terminal, splits);
  auto wrong_singleton = splits;
  wrong_singleton[0] = {0x02U};
  const bool singleton_rejected = rejects(labels, terminal, wrong_singleton);
  auto internal_terminal = terminal;
  internal_terminal[0] = e2::kInternalTaxon;
  auto noncanonical_internal = splits;
  noncanonical_internal[0] = {0x0cU};
  const bool internal_rejected =
      rejects(labels, internal_terminal, noncanonical_internal);
  const std::size_t passed = static_cast<std::size_t>(raw_digest_equal) +
                             static_cast<std::size_t>(duplicate_rejected) +
                             static_cast<std::size_t>(singleton_rejected) +
                             static_cast<std::size_t>(internal_rejected);

  std::cout << "duplicate_label="
            << (duplicate_rejected ? "REJECT" : "ACCEPT") << "\n";
  std::cout << "wrong_terminal_singleton="
            << (singleton_rejected ? "REJECT" : "ACCEPT") << "\n";
  std::cout << "noncanonical_internal_tie="
            << (internal_rejected ? "REJECT" : "ACCEPT") << "\n";
  std::cout << "frozen_engine002_crosscheck_cases=" << passed << "/4\n";
  return passed == 4U ? 0 : 1;
}
