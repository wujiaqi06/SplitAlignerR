#!/usr/bin/env python3
"""Independent NON-PRODUCTION checker for ENGINE003-PREFLIGHT fixtures.

This parser does not import the reference encoder or package implementation.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import stat
import struct
import time
from pathlib import Path

from descriptor_bytes_v1 import (
    DESCRIPTOR_MAX_RAW_BYTES,
    DescriptorBytesError,
    parse_descriptor_bytes,
)


TILE_ROWS = 256
TILE_COLS = 256
HEADER_BYTES = 256
ENTRY_BYTES = 128
FOOTER_BYTES = 512
U64_MAX = (1 << 64) - 1
TINY_CHECKER_MAX_FILE_BYTES = 64 * 1024 * 1024
ERROR_DETAIL_MAX_BYTES = 384
BINARY_NAMES = (
    "STATE.bin", "NUMERIC.bin", "VALIDITY.bin", "TILE_INDEX.bin",
    "COMPLETION.bin"
)
PUBLISHED_NAMES = BINARY_NAMES + ("VALIDATED",)
PREPUBLICATION_BYTES = "PREPUBLICATION_BYTES"
PUBLISHED_STORE = "PUBLISHED_STORE"
DESCRIPTOR_SCHEMA = "SplitAlignerR/ENGINE003ExternalAuthorityDescriptor/v1"
PRIMITIVE_KEYS = {
    "terminal", "terminal_taxon_id", "authority_edge_split_hex"
}
READ_LOOP_TEST_DELAY_SECONDS = 0.0
READ_LOOP_TEST_READY_PATH = None
READ_LOOP_TEST_READY_LABEL = None
STATE_MAPPED = 0
STATE_NA_STRUCT = 1
STATE_NA_FUSE = 2
STATE_NA_TOPO = 3
PRIMITIVE_ROW_INVARIANT = "PrimitiveRowConsistency-v1"
COMPOSITE_ROW_INVARIANT = "CompositeRowConsistency-v1"


class ValidationError(Exception):
    def __init__(self, code: str, detail: str):
        super().__init__(f"{code}: {detail}")
        self.code = code


def fail(code: str, detail: str) -> None:
    # Error details cross a text boundary and can be influenced by hostile
    # descriptor/path bytes.  Keep them ASCII-safe and bounded; stable codes,
    # rather than attacker-controlled spellings, are the review contract.
    encoded = str(detail).encode("ascii", errors="backslashreplace")
    suffix = b"...[truncated]"
    if len(encoded) > ERROR_DETAIL_MAX_BYTES:
        encoded = encoded[:ERROR_DETAIL_MAX_BYTES - len(suffix)] + suffix
    raise ValidationError(code, encoded.decode("ascii"))


def le16(data: bytes, offset: int) -> int:
    return struct.unpack_from("<H", data, offset)[0]


def le32(data: bytes, offset: int) -> int:
    return struct.unpack_from("<I", data, offset)[0]


def le64(data: bytes, offset: int) -> int:
    return struct.unpack_from("<Q", data, offset)[0]


def enc16(value: int) -> bytes:
    return struct.pack("<H", value)


def enc32(value: int) -> bytes:
    return struct.pack("<I", value)


def enc64(value: int) -> bytes:
    return struct.pack("<Q", value)


def length_prefix(value: bytes) -> bytes:
    return enc64(len(value)) + value


def digest(value: bytes) -> bytes:
    return hashlib.sha256(value).digest()


def checked_add(left: int, right: int, label: str) -> int:
    value = left + right
    if value > U64_MAX:
        fail("E3_OVERFLOW", label)
    return value


def checked_mul(left: int, right: int, label: str) -> int:
    value = left * right
    if value > U64_MAX:
        fail("E3_OVERFLOW", label)
    return value


def ceil_div(value: int, divisor: int) -> int:
    quotient, remainder = divmod(value, divisor)
    return quotient + int(remainder != 0)


def require_zero(data: bytes, start: int, end: int, label: str) -> None:
    if any(data[start:end]):
        fail("E3_RESERVED_NONZERO", label)


def nofollow_flags() -> int:
    required = ("O_NOFOLLOW", "O_NONBLOCK", "O_CLOEXEC")
    missing = [name for name in required if not hasattr(os, name)]
    if missing:
        fail("E3_PLATFORM", "required open flags unavailable: " + ",".join(missing))
    return os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC


def read_regular_path(
    path: Path, label: str, snapshot_out=None,
    max_bytes: int = TINY_CHECKER_MAX_FILE_BYTES,
    over_limit_error_code: str = "E3_FIXTURE_LIMIT",
) -> bytes:
    """Traverse parents no-follow, then read from the verified file descriptor."""
    parent = open_directory_chain(path.parent)
    try:
        parent_identity = directory_identity(os.fstat(parent))
        file_identities = {}
        raw = read_regular_at(
            parent, path.name, label, identity_out=file_identities,
            max_bytes=max_bytes,
            over_limit_error_code=over_limit_error_code,
        )
        if snapshot_out is not None:
            snapshot_out["parent_identity"] = parent_identity
            snapshot_out["name"] = path.name
            snapshot_out["file_identity"] = file_identities[path.name]
        return raw
    finally:
        os.close(parent)


def open_directory_chain(path: Path) -> int:
    """Open every path component relative to an already-open directory."""
    flags = nofollow_flags()
    if not hasattr(os, "O_DIRECTORY"):
        fail("E3_PLATFORM", "O_DIRECTORY is required by this independent checker")
    try:
        if path.is_absolute():
            descriptor = os.open("/", flags | os.O_DIRECTORY)
            parts = path.parts[1:]
        else:
            descriptor = os.open(".", flags | os.O_DIRECTORY)
            parts = path.parts
    except OSError as error:
        fail("E3_STORE_PATH", f"cannot anchor directory traversal: {error}")
    for part in parts:
        if part in ("", "."):
            continue
        if part == "..":
            os.close(descriptor)
            fail("E3_STORE_PATH", "parent traversal is forbidden")
        try:
            next_descriptor = os.open(part, flags | os.O_DIRECTORY,
                                      dir_fd=descriptor)
        except OSError as error:
            os.close(descriptor)
            fail("E3_STORE_PATH", f"no-follow directory traversal failed at {part}: {error}")
        os.close(descriptor)
        descriptor = next_descriptor
    return descriptor


def open_store_directory(path: Path) -> int:
    descriptor = open_directory_chain(path)
    if not stat.S_ISDIR(os.fstat(descriptor).st_mode):
        os.close(descriptor)
        fail("E3_STORE_PATH", "store must be a directory")
    return descriptor


def stat_identity(value) -> tuple[int, int, int, int, int]:
    return (value.st_dev, value.st_ino, value.st_size,
            value.st_mtime_ns, value.st_ctime_ns)


def directory_identity(value) -> tuple[int, int, int, int]:
    return (value.st_dev, value.st_ino, value.st_mtime_ns, value.st_ctime_ns)


def signal_test_read_ready(label: str) -> None:
    if READ_LOOP_TEST_READY_PATH is None or label != READ_LOOP_TEST_READY_LABEL:
        return
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_CLOEXEC
    try:
        descriptor = os.open(str(READ_LOOP_TEST_READY_PATH), flags, 0o600)
        try:
            os.write(descriptor, b"READY_AFTER_INITIAL_FSTAT\n")
        finally:
            os.close(descriptor)
    except OSError as error:
        fail("E3_TEST_SEAM", f"cannot create read-ready marker: {error.errno}")


def read_regular_at(
    directory: int, name: str, label=None, identity_out=None,
    max_bytes: int = TINY_CHECKER_MAX_FILE_BYTES,
    over_limit_error_code: str = "E3_FIXTURE_LIMIT",
) -> bytes:
    label = label or name
    try:
        descriptor = os.open(name, nofollow_flags(), dir_fd=directory)
    except FileNotFoundError:
        fail("E3_INCOMPLETE", f"missing {label}")
    except OSError as error:
        fail("E3_SYMLINK_OR_OPEN", f"{label}: {error}")
    try:
        before = os.fstat(descriptor)
        if not stat.S_ISREG(before.st_mode):
            fail("E3_NOT_REGULAR", label)
        cap_label = (
            "tiny-checker cap"
            if over_limit_error_code == "E3_FIXTURE_LIMIT"
            else "descriptor cap"
        )
        if before.st_size > max_bytes:
            fail(over_limit_error_code, f"{label} exceeds {cap_label}")
        signal_test_read_ready(label)
        chunks = []
        total = 0
        while total < max_bytes:
            chunk = os.read(descriptor, min(1024 * 1024, max_bytes - total))
            if not chunk:
                break
            total += len(chunk)
            chunks.append(chunk)
            during = os.fstat(descriptor)
            if during.st_size > max_bytes:
                fail(over_limit_error_code, f"{label} grew beyond {cap_label}")
            if READ_LOOP_TEST_DELAY_SECONDS:
                time.sleep(READ_LOOP_TEST_DELAY_SECONDS)
        after = os.fstat(descriptor)
        if after.st_size > max_bytes:
            fail(over_limit_error_code, f"{label} grew beyond {cap_label}")
        before_identity = stat_identity(before)
        after_identity = stat_identity(after)
        if before_identity != after_identity or total != after.st_size:
            fail("E3_FILE_CHANGED", label)
        if identity_out is not None:
            identity_out[name] = before_identity
        return b"".join(chunks)
    finally:
        os.close(descriptor)


def exact_store_entries(directory: int, phase: str) -> tuple[str, ...]:
    expected = BINARY_NAMES if phase == PREPUBLICATION_BYTES else PUBLISHED_NAMES
    observed = set(os.listdir(directory))
    missing = set(expected) - observed
    extra = observed - set(expected)
    if missing:
        fail("E3_INCOMPLETE", "missing " + ",".join(sorted(missing)))
    if extra:
        fail("E3_UNDECLARED_ENTRY", f"{len(extra)} undeclared store entry/entries")
    return expected


def verify_store_snapshot(
    store: Path, phase: str,
    expected_directory_identity: tuple[int, int, int, int],
    file_identities: dict[str, tuple[int, int, int, int, int]],
) -> None:
    """Final name-to-inode barrier for the fixture oracle's accepted snapshot."""
    directory = open_store_directory(store)
    try:
        current = os.fstat(directory)
        current_directory_identity = directory_identity(current)
        if current_directory_identity != expected_directory_identity:
            fail("E3_DIRECTORY_CHANGED", "store directory identity/metadata")
        expected = exact_store_entries(directory, phase)
        if set(file_identities) != set(expected):
            fail("E3_DIRECTORY_CHANGED", "recorded component identity set")
        for name in expected:
            try:
                descriptor = os.open(name, nofollow_flags(), dir_fd=directory)
            except OSError:
                fail("E3_DIRECTORY_CHANGED", f"cannot reopen {name}")
            try:
                value = os.fstat(descriptor)
                if not stat.S_ISREG(value.st_mode):
                    fail("E3_DIRECTORY_CHANGED", f"nonregular final {name}")
                if stat_identity(value) != file_identities[name]:
                    fail("E3_DIRECTORY_CHANGED", f"rebound final {name}")
            finally:
                os.close(descriptor)
        final = os.fstat(directory)
        final_directory_identity = directory_identity(final)
        if final_directory_identity != expected_directory_identity:
            fail("E3_DIRECTORY_CHANGED", "store directory changed during final barrier")
    finally:
        os.close(directory)


def verify_external_snapshot(path: Path, snapshot: dict) -> None:
    """Final pathname-to-file barrier for the external authority descriptor."""
    parent = open_directory_chain(path.parent)
    try:
        if directory_identity(os.fstat(parent)) != snapshot["parent_identity"]:
            fail("E3_DIRECTORY_CHANGED", "external authority parent identity/metadata")
        try:
            descriptor = os.open(snapshot["name"], nofollow_flags(), dir_fd=parent)
        except OSError:
            fail("E3_DIRECTORY_CHANGED", "cannot reopen external authority")
        try:
            value = os.fstat(descriptor)
            if not stat.S_ISREG(value.st_mode):
                fail("E3_DIRECTORY_CHANGED", "external authority became nonregular")
            if stat_identity(value) != snapshot["file_identity"]:
                fail("E3_DIRECTORY_CHANGED", "external authority name rebound")
        finally:
            os.close(descriptor)
        if directory_identity(os.fstat(parent)) != snapshot["parent_identity"]:
            fail("E3_DIRECTORY_CHANGED", "external authority parent changed at barrier")
    finally:
        os.close(parent)


def exact_lower_hex(value, label: str, allow_empty: bool = False) -> bytes:
    if not isinstance(value, str):
        fail("E3_DESCRIPTOR", f"{label} must be a lowercase hex string")
    if (not allow_empty and not value) or len(value) % 2:
        fail("E3_DESCRIPTOR", f"{label} has empty/odd-length hex")
    if any(character not in "0123456789abcdef" for character in value):
        fail("E3_DESCRIPTOR", f"{label} is not canonical lowercase hex")
    return bytes.fromhex(value)


def species_digest(registry: dict) -> bytes:
    taxa_raw = registry["taxon_label_bytes_hex"]
    primitives = registry["primitive_entries"]
    if not isinstance(taxa_raw, list) or not taxa_raw:
        fail("E3_AUTHORITY", "taxon count must be nonzero")
    if len(taxa_raw) > 0xFFFFFFFF or not isinstance(primitives, list) or len(primitives) > 0xFFFFFFFF:
        fail("E3_AUTHORITY", "taxon or primitive count does not fit u32")
    taxa = []
    observed_labels = set()
    for taxon_id, value in enumerate(taxa_raw):
        label = exact_lower_hex(value, f"taxon_label_bytes_hex[{taxon_id}]")
        if not label:
            fail("E3_AUTHORITY", "taxon labels must be nonempty")
        if label in observed_labels:
            fail("E3_AUTHORITY", "duplicate taxon label")
        observed_labels.add(label)
        taxa.append(label)
    stream = bytearray(b"SplitAlignerR/SpeciesAuthority/v1\0")
    stream += enc32(len(taxa)) + enc32(len(primitives))
    for taxon_id, label in enumerate(taxa):
        stream += enc32(taxon_id) + length_prefix(label)
    width = ceil_div(len(taxa), 8)
    all_mask = (1 << len(taxa)) - 1
    for primitive_id, item in enumerate(primitives):
        if not isinstance(item, dict) or set(item) != PRIMITIVE_KEYS:
            fail("E3_DESCRIPTOR", f"primitive {primitive_id} key set")
        if not isinstance(item.get("terminal"), bool):
            fail("E3_AUTHORITY", "primitive terminal flag must be boolean")
        split = exact_lower_hex(
            item["authority_edge_split_hex"],
            f"primitive_entries[{primitive_id}].authority_edge_split_hex",
            allow_empty=(width == 0)
        )
        if len(split) != width:
            fail("E3_AUTHORITY", "split width")
        used_bits = len(taxa) % 8 or 8
        if split[-1] & ~((1 << used_bits) - 1):
            fail("E3_AUTHORITY", "nonzero split padding")
        terminal = item["terminal"]
        raw_taxon_id = item.get("terminal_taxon_id")
        if not isinstance(raw_taxon_id, int) or isinstance(raw_taxon_id, bool):
            fail("E3_AUTHORITY", "terminal taxon ID must be an integer")
        if not 0 <= raw_taxon_id <= 0xFFFFFFFF:
            fail("E3_AUTHORITY", "terminal taxon ID does not fit u32")
        selected = int.from_bytes(split, "little")
        if terminal:
            taxon_id = raw_taxon_id
            if not 0 <= taxon_id < len(taxa):
                fail("E3_AUTHORITY", "terminal taxon out of range")
            if selected != (1 << taxon_id):
                fail("E3_AUTHORITY", "terminal split is not its exact singleton")
        else:
            taxon_id = raw_taxon_id
            if taxon_id != 0xFFFFFFFF:
                fail("E3_AUTHORITY", "internal terminal taxon ID must be sentinel")
            complement = all_mask ^ selected
            if selected == 0 or complement == 0:
                fail("E3_AUTHORITY", "internal split side is empty")
            selected_count = bin(selected).count("1")
            complement_count = bin(complement).count("1")
            complement_bytes = complement.to_bytes(width, "little")
            if selected_count > complement_count:
                fail("E3_AUTHORITY", "internal split uses larger side")
            if selected_count == complement_count and split > complement_bytes:
                fail("E3_AUTHORITY", "internal split violates unsigned-byte lex tie rule")
        stream += enc32(primitive_id)
        stream += bytes([1 if terminal else 0]) + bytes(3)
        stream += enc32(taxon_id) + length_prefix(split)
    return digest(bytes(stream))


def gene_digest(gene_ids: list[str]) -> bytes:
    if not isinstance(gene_ids, list):
        fail("E3_REGISTRY", "gene IDs must be a list")
    stream = bytearray(b"SplitAlignerR/GeneRegistry/v1\0") + enc64(len(gene_ids))
    observed = set()
    for index, label in enumerate(gene_ids):
        if not isinstance(label, str):
            fail("E3_REGISTRY", "gene ID must be a string")
        try:
            raw = label.encode("utf-8")
        except UnicodeError as error:
            fail("E3_REGISTRY", f"invalid UTF-8 gene ID: {error}")
        if not raw or b"\0" in raw:
            fail("E3_REGISTRY", "gene IDs must be nonempty and NUL-free")
        if raw in observed:
            fail("E3_REGISTRY", "duplicate gene ID")
        observed.add(raw)
        stream += enc64(index) + length_prefix(raw)
    return digest(bytes(stream))


def member_encodings(registry: dict) -> list[bytes]:
    primitive_count = len(registry["primitive_entries"])
    encoded = []
    for index, members in enumerate(registry["bstar_members"]):
        if not isinstance(members, list):
            fail("E3_DESCRIPTOR", f"bstar_members[{index}] must be a list")
        if any(not isinstance(member, int) or isinstance(member, bool) or
               not 0 <= member <= 0xFFFFFFFF for member in members):
            fail("E3_REGISTRY", "B* members must be u32 integers")
        if len(members) < 2 or members != sorted(set(members)):
            fail("E3_REGISTRY", "noncanonical B* member list")
        if members[0] < 0 or members[-1] >= primitive_count:
            fail("E3_REGISTRY", "B* member out of range")
        encoded.append(b"".join(enc32(member) for member in members))
    if encoded != sorted(encoded) or len(set(encoded)) != len(encoded):
        fail("E3_REGISTRY", "B* order or duplicate")
    return encoded


def bstar_digest(primitive: bytes, encoded: list[bytes]) -> bytes:
    stream = bytearray(b"SplitAlignerR/BStarRegistry/v1\0")
    stream += primitive + enc64(len(encoded))
    for index, value in enumerate(encoded):
        stream += enc64(index) + length_prefix(value)
    return digest(bytes(stream))


def numeric_digest(
    primitive: bytes, primitive_count: int, bstar: bytes, encoded: list[bytes]
) -> bytes:
    stream = bytearray(b"SplitAlignerR/NumericCoordinateRegistry/v1\0")
    stream += primitive + enc64(primitive_count) + bstar + enc64(len(encoded))
    for index, value in enumerate(encoded):
        stream += enc64(index) + length_prefix(value)
    return digest(bytes(stream))


def load_registry(path: Path, snapshot_out=None) -> dict:
    try:
        raw = read_regular_path(
            path, "registry descriptor", snapshot_out=snapshot_out,
            max_bytes=DESCRIPTOR_MAX_RAW_BYTES,
            over_limit_error_code="E3_DESCRIPTOR_LIMIT",
        )
        value = parse_descriptor_bytes(raw)
    except ValidationError:
        raise
    except DescriptorBytesError as error:
        fail(error.code, error.detail)
    return value


def parse_manifest(raw: bytes) -> dict[str, str]:
    if not raw.endswith(b"\n") or b"\r" in raw or raw.startswith(b"\xef\xbb\xbf"):
        fail("E3_MANIFEST_GRAMMAR", "line ending/BOM")
    try:
        text = raw.decode("ascii")
    except UnicodeDecodeError:
        fail("E3_MANIFEST_GRAMMAR", "non-ASCII byte")
    expected_keys = [
        "magic", "manifest_schema_major", "manifest_schema_minor",
        "completion_state", "store_schema", "layout", "tile_rows",
        "tile_columns", "row_count", "primitive_count", "bstar_count",
        "numeric_coordinate_count", "species_authority_sha256",
        "gene_registry_sha256", "primitive_registry_sha256",
        "bstar_registry_sha256", "numeric_coordinate_registry_sha256",
        "logical_content_sha256", "state_component", "state_bytes",
        "state_sha256", "numeric_component", "numeric_bytes",
        "numeric_sha256", "validity_component", "validity_bytes",
        "validity_sha256", "index_component", "index_bytes", "index_sha256",
        "footer_component", "footer_bytes", "footer_sha256",
        "publication_timestamp_policy"
    ]
    lines = text[:-1].split("\n")
    if len(lines) != len(expected_keys):
        fail("E3_MANIFEST_GRAMMAR", "key count")
    result = {}
    for expected, line in zip(expected_keys, lines):
        if "=" not in line:
            fail("E3_MANIFEST_GRAMMAR", "missing equals")
        key, value = line.split("=", 1)
        if key != expected or not value or value != value.strip():
            fail("E3_MANIFEST_GRAMMAR", f"expected {expected}")
        result[key] = value
    fixed = {
        "magic": "SplitAlignerR-MatrixStore-VALIDATED",
        "manifest_schema_major": "1", "manifest_schema_minor": "0",
        "completion_state": "VALIDATED", "store_schema": "1.0-candidate",
        "layout": "tiled_row_major_provisional", "tile_rows": "256",
        "tile_columns": "256", "state_component": "STATE.bin",
        "numeric_component": "NUMERIC.bin", "validity_component": "VALIDITY.bin",
        "index_component": "TILE_INDEX.bin", "footer_component": "COMPLETION.bin",
        "footer_bytes": "512", "publication_timestamp_policy": "OMITTED_V1"
    }
    for key, value in fixed.items():
        if result[key] != value:
            fail("E3_MANIFEST_VALUE", key)
    for key in ("row_count", "primitive_count", "bstar_count",
                "numeric_coordinate_count", "state_bytes", "numeric_bytes",
                "validity_bytes", "index_bytes"):
        if not result[key].isdigit() or (len(result[key]) > 1 and result[key][0] == "0"):
            fail("E3_MANIFEST_GRAMMAR", f"canonical decimal {key}")
        if int(result[key]) > U64_MAX:
            fail("E3_OVERFLOW", key)
    for key in ("species_authority_sha256", "gene_registry_sha256",
                "primitive_registry_sha256", "bstar_registry_sha256",
                "numeric_coordinate_registry_sha256", "logical_content_sha256",
                "state_sha256", "numeric_sha256", "validity_sha256",
                "index_sha256", "footer_sha256"):
        value = result[key]
        if len(value) != 64 or any(ch not in "0123456789abcdef" for ch in value):
            fail("E3_MANIFEST_GRAMMAR", f"lowercase digest {key}")
    return result


def parse_data_header(
    raw: bytes, magic: bytes, component_type: int, encoding: int,
    coordinate_digest: bytes, species: bytes, genes: bytes
) -> dict:
    if len(raw) < HEADER_BYTES or raw[:8] != magic:
        fail("E3_HEADER", magic.decode("ascii"))
    if (le16(raw, 8), le16(raw, 10), le16(raw, 12), le16(raw, 14)) != (
        1, 0, HEADER_BYTES, component_type
    ):
        fail("E3_HEADER", "schema/type")
    if raw[16:20] != bytes([1, 1, encoding, 0]):
        fail("E3_HEADER", "byte order/layout/encoding/flags")
    if le32(raw, 20) != TILE_ROWS or le32(raw, 24) != TILE_COLS:
        fail("E3_HEADER", "tile shape")
    require_zero(raw, 28, 32, "data header reserved 28")
    require_zero(raw, 104, 128, "data header reserved 104")
    require_zero(raw, 224, 256, "data header reserved 224")
    rows, columns = le64(raw, 32), le64(raw, 40)
    rt, ct, count = le64(raw, 48), le64(raw, 56), le64(raw, 64)
    expected_rt = ceil_div(rows, TILE_ROWS) if rows else 0
    expected_ct = ceil_div(columns, TILE_COLS) if columns else 0
    if rt != expected_rt or ct != expected_ct:
        fail("E3_GEOMETRY", "tile counts")
    if count != checked_mul(rt, ct, "tile count"):
        fail("E3_GEOMETRY", "tile product")
    expected_tile_bytes = {1: TILE_ROWS * TILE_COLS,
                           2: TILE_ROWS * TILE_COLS * 8,
                           3: TILE_ROWS * TILE_COLS // 8}[component_type]
    if le64(raw, 72) != expected_tile_bytes or le64(raw, 80) != HEADER_BYTES:
        fail("E3_GEOMETRY", "tile payload/start")
    payload_bytes = checked_mul(count, expected_tile_bytes, "payload bytes")
    exact = checked_add(HEADER_BYTES, payload_bytes, "component bytes")
    if le64(raw, 88) != payload_bytes or le64(raw, 96) != exact or len(raw) != exact:
        fail("E3_LENGTH", "data component")
    if raw[128:160] != species or raw[160:192] != genes:
        fail("E3_AUTHORITY", "species/gene header binding")
    if raw[192:224] != coordinate_digest:
        fail("E3_AUTHORITY", "coordinate header binding")
    return {"rows": rows, "columns": columns, "tile_rows": rt,
            "tile_columns": ct, "tile_count": count,
            "tile_bytes": expected_tile_bytes}


def parse_index_header(
    raw: bytes, species: bytes, genes: bytes, primitive: bytes,
    bstar: bytes, numeric: bytes
) -> dict:
    if len(raw) < HEADER_BYTES or raw[:8] != b"SARIX001":
        fail("E3_INDEX", "magic/truncation")
    if (le16(raw, 8), le16(raw, 10), le16(raw, 12), le16(raw, 14)) != (1, 0, 256, 4):
        fail("E3_INDEX", "schema/type")
    if raw[16:18] != b"\x01\x01" or le32(raw, 20) != ENTRY_BYTES:
        fail("E3_INDEX", "encoding/entry width")
    require_zero(raw, 18, 20, "index header reserved 18")
    require_zero(raw, 240, 256, "index header reserved 240")
    count = le64(raw, 24)
    exact = checked_add(HEADER_BYTES, checked_mul(count, ENTRY_BYTES, "index bytes"), "index total")
    if le64(raw, 32) != exact or len(raw) != exact:
        fail("E3_LENGTH", "index")
    if le32(raw, 72) != TILE_ROWS or le32(raw, 76) != TILE_COLS:
        fail("E3_INDEX", "tile shape")
    if raw[80:112] != species or raw[112:144] != genes or raw[144:176] != primitive:
        fail("E3_AUTHORITY", "index base registry binding")
    if raw[176:208] != bstar or raw[208:240] != numeric:
        fail("E3_AUTHORITY", "index composite registry binding")
    return {"count": count, "rows": le64(raw, 40), "primitive": le64(raw, 48),
            "bstar": le64(raw, 56), "numeric": le64(raw, 64)}


def parse_entries(raw: bytes, headers: dict[int, dict], components: dict[int, bytes]) -> list[dict]:
    entries = []
    expected = []
    for component_type in (1, 2, 3):
        header = headers[component_type]
        for tile_row in range(header["tile_rows"]):
            for tile_column in range(header["tile_columns"]):
                expected.append((component_type, tile_row, tile_column))
    count = (len(raw) - HEADER_BYTES) // ENTRY_BYTES
    if count != len(expected):
        fail("E3_INDEX", "entry count versus geometry")
    for position, wanted in enumerate(expected):
        item = raw[HEADER_BYTES + position * ENTRY_BYTES:
                   HEADER_BYTES + (position + 1) * ENTRY_BYTES]
        component_type, schema = le16(item, 0), le16(item, 2)
        tile_row, tile_column = le64(item, 8), le64(item, 16)
        if (component_type, tile_row, tile_column) != wanted or schema != 1:
            fail("E3_INDEX_ORDER", f"entry {position}")
        require_zero(item, 4, 8, "index entry reserved 4")
        require_zero(item, 74, 80, "index entry reserved 74")
        require_zero(item, 112, 128, "index entry reserved 112")
        header = headers[component_type]
        row_start = checked_mul(tile_row, TILE_ROWS, "row start")
        column_start = checked_mul(tile_column, TILE_COLS, "column start")
        row_extent = min(TILE_ROWS, header["rows"] - row_start)
        column_extent = min(TILE_COLS, header["columns"] - column_start)
        if row_start >= header["rows"] or column_start >= header["columns"]:
            fail("E3_INDEX", "tile starts outside logical axes")
        linear_tile = checked_add(
            checked_mul(tile_row, header["tile_columns"], "linear tile row"),
            tile_column, "linear tile coordinate"
        )
        offset = checked_add(HEADER_BYTES,
                             checked_mul(linear_tile, header["tile_bytes"], "tile offset"),
                             "payload offset")
        expected_encoding = component_type
        if (le64(item, 24), le64(item, 32), le32(item, 40), le32(item, 44)) != (
            row_start, column_start, row_extent, column_extent
        ):
            fail("E3_INDEX", "logical geometry")
        if le64(item, 48) != offset or le64(item, 56) != header["tile_bytes"]:
            fail("E3_INDEX", "offset/length")
        if le32(item, 64) != TILE_ROWS or le32(item, 68) != TILE_COLS:
            fail("E3_INDEX", "physical geometry")
        if le16(item, 72) != expected_encoding:
            fail("E3_INDEX", "scalar encoding")
        payload = components[component_type][offset:offset + header["tile_bytes"]]
        if len(payload) != header["tile_bytes"] or digest(payload) != item[80:112]:
            fail("E3_TILE_HASH", f"entry {position}")
        entries.append({"component_type": component_type, "tile_row": tile_row,
                        "tile_column": tile_column, "row_start": row_start,
                        "column_start": column_start, "row_extent": row_extent,
                        "column_extent": column_extent, "payload": payload})
    return entries


def reconstruct(headers: dict[int, dict], entries: list[dict]) -> tuple[bytes, bytes, bytes]:
    state_header, numeric_header = headers[1], headers[2]
    state_cells = checked_mul(state_header["rows"], state_header["columns"],
                              "logical state cell product")
    numeric_cells = checked_mul(numeric_header["rows"], numeric_header["columns"],
                                "logical numeric cell product")
    numeric_bytes = checked_mul(numeric_cells, 8, "logical numeric byte product")
    state = bytearray(state_cells)
    numeric = bytearray(numeric_bytes)
    validity_values = [False] * numeric_cells
    entry_map = {(item["component_type"], item["tile_row"], item["tile_column"]): item
                 for item in entries}
    for component_type, header in headers.items():
        for tile_row in range(header["tile_rows"]):
            for tile_column in range(header["tile_columns"]):
                item = entry_map[(component_type, tile_row, tile_column)]
                payload = item["payload"]
                for local_row in range(TILE_ROWS):
                    for local_column in range(TILE_COLS):
                        logical = (local_row < item["row_extent"] and
                                   local_column < item["column_extent"])
                        physical_cell = local_row * TILE_COLS + local_column
                        if component_type == 1:
                            value = payload[physical_cell]
                            if logical:
                                if value > 3:
                                    fail("E3_STATE", f"invalid logical state {value}")
                                row = item["row_start"] + local_row
                                column = item["column_start"] + local_column
                                state[row * header["columns"] + column] = value
                            elif value != 0:
                                fail("E3_PADDING", "state padding")
                        elif component_type == 2:
                            bits = payload[physical_cell * 8:physical_cell * 8 + 8]
                            if not logical and bits != bytes(8):
                                fail("E3_PADDING", "numeric padding")
                            if logical:
                                row = item["row_start"] + local_row
                                column = item["column_start"] + local_column
                                target = (row * header["columns"] + column) * 8
                                numeric[target:target + 8] = bits
                        else:
                            value = bool(payload[physical_cell // 8] & (1 << (physical_cell % 8)))
                            if not logical and value:
                                fail("E3_PADDING", "validity padding")
                            if logical:
                                row = item["row_start"] + local_row
                                column = item["column_start"] + local_column
                                validity_values[row * header["columns"] + column] = value
    validity = bytearray(ceil_div(len(validity_values), 8))
    for index, present in enumerate(validity_values):
        bits = bytes(numeric[index * 8:index * 8 + 8])
        if present:
            value = struct.unpack("<d", bits)[0]
            if not math.isfinite(value):
                fail("E3_NUMERIC", "nonfinite valid value")
            validity[index // 8] |= 1 << (index % 8)
        elif bits != bytes(8):
            fail("E3_NUMERIC", "invalid numeric payload is not +0.0 bits")
    return bytes(state), bytes(numeric), bytes(validity)


def validate_primitive_row_consistency(
    headers: dict[int, dict], entries: list[dict], primitive_entries: list[dict]
) -> dict:
    """Join primitive state/numeric/validity tiles without a matrix materialization.

    This is deliberately a tile-bounded pass.  It never constructs a
    row_count x primitive_count object and it does not inspect B* state (there
    are no B* columns in STATE.bin).  The numeric tile is read jointly so the
    primitive-prefix validity/payload contract and the state/validity contract
    are checked over exactly the same logical cells.
    """
    primitive_count = headers[1]["columns"]
    if len(primitive_entries) != primitive_count:
        fail("E3_AUTHORITY", "primitive terminal-flag count")
    terminal_flags = [item["terminal"] for item in primitive_entries]
    entry_map = {
        (item["component_type"], item["tile_row"], item["tile_column"]): item
        for item in entries
    }
    checked_cells = 0
    tile_triplets = 0
    max_join_payload_bytes = 0
    for state_item in entries:
        if state_item["component_type"] != 1:
            continue
        key = (state_item["tile_row"], state_item["tile_column"])
        try:
            numeric_item = entry_map[(2, *key)]
            validity_item = entry_map[(3, *key)]
        except KeyError:
            fail("E3_PRIMITIVE_PREFIX", "missing numeric/validity tile for state tile")
        if (numeric_item["row_start"], numeric_item["column_start"]) != (
            state_item["row_start"], state_item["column_start"]
        ) or (validity_item["row_start"], validity_item["column_start"]) != (
            state_item["row_start"], state_item["column_start"]
        ):
            fail("E3_PRIMITIVE_PREFIX", "primitive tile origins disagree")
        if (numeric_item["row_extent"] < state_item["row_extent"] or
                numeric_item["column_extent"] < state_item["column_extent"] or
                validity_item["row_extent"] < state_item["row_extent"] or
                validity_item["column_extent"] < state_item["column_extent"]):
            fail("E3_PRIMITIVE_PREFIX", "primitive tile extents disagree")

        state_payload = state_item["payload"]
        numeric_payload = numeric_item["payload"]
        validity_payload = validity_item["payload"]
        tile_triplets += 1
        max_join_payload_bytes = max(
            max_join_payload_bytes,
            len(state_payload) + len(numeric_payload) + len(validity_payload),
        )
        for local_row in range(state_item["row_extent"]):
            for local_column in range(state_item["column_extent"]):
                primitive_id = state_item["column_start"] + local_column
                if primitive_id >= primitive_count:
                    fail("E3_PRIMITIVE_PREFIX", "state coordinate exceeds primitive authority")
                physical_cell = local_row * TILE_COLS + local_column
                state = state_payload[physical_cell]
                if state > STATE_NA_TOPO:
                    fail("E3_STATE", f"invalid logical state {state}")
                valid = bool(
                    validity_payload[physical_cell // 8]
                    & (1 << (physical_cell % 8))
                )
                numeric_bits = numeric_payload[
                    physical_cell * 8:physical_cell * 8 + 8
                ]
                if valid:
                    if not math.isfinite(struct.unpack("<d", numeric_bits)[0]):
                        fail("E3_NUMERIC", "nonfinite valid primitive value")
                elif numeric_bits != bytes(8):
                    fail("E3_NUMERIC", "invalid primitive payload is not +0.0 bits")
                if state != STATE_MAPPED and valid:
                    fail(
                        "E3_PRIMITIVE_ROW_CONSISTENCY",
                        f"row {state_item['row_start'] + local_row} primitive "
                        f"{primitive_id}: non-Mapped state {state} has validity 1",
                    )
                if terminal_flags[primitive_id] and state == STATE_NA_TOPO:
                    fail(
                        "E3_PRIMITIVE_ROW_CONSISTENCY",
                        f"row {state_item['row_start'] + local_row} primitive "
                        f"{primitive_id}: terminal primitive has NA_topo",
                    )
                checked_cells += 1
    expected_cells = checked_mul(
        headers[1]["rows"], primitive_count, "primitive row consistency cells"
    )
    if checked_cells != expected_cells:
        fail("E3_PRIMITIVE_PREFIX", "primitive consistency coverage")
    return {
        "invariant": PRIMITIVE_ROW_INVARIANT,
        "checked_cells": checked_cells,
        "tile_triplets": tile_triplets,
        "max_join_payload_bytes": max_join_payload_bytes,
    }


def validate_composite_row_consistency(
    headers: dict[int, dict], registry: dict, state: bytes, validity: bytes,
) -> dict:
    """Review-only whole-fixture oracle for CompositeRowConsistency-v1.

    The independent checker is explicitly capped at 64 MiB and is not the
    production-scale bounded checker.  This pass uses only reconstructed stored
    state, reconstructed stored validity and the frozen B* registry.
    """
    rows = headers[1]["rows"]
    primitive_count = headers[1]["columns"]
    numeric_count = headers[2]["columns"]
    bstar_members = registry["bstar_members"]
    checked_bstar_cells = 0
    valid_bstar_cells = 0
    max_occupied_members = 0
    for row in range(rows):
        occupied: set[int] = set()
        for bstar_id, members in enumerate(bstar_members):
            checked_bstar_cells += 1
            coordinate = primitive_count + bstar_id
            logical_cell = row * numeric_count + coordinate
            valid = bool(
                validity[logical_cell // 8] & (1 << (logical_cell % 8))
            )
            if not valid:
                continue
            valid_bstar_cells += 1
            non_fused = [
                member for member in members
                if state[row * primitive_count + member] != STATE_NA_FUSE
            ]
            if non_fused:
                fail(
                    "E3_COMPOSITE_ROW_CONSISTENCY",
                    f"row {row} valid B* {bstar_id} has non-NA_fuse member(s) "
                    + ",".join(str(member) for member in non_fused),
                )
            overlap = occupied.intersection(members)
            if overlap:
                fail(
                    "E3_COMPOSITE_ROW_CONSISTENCY",
                    f"row {row} valid B* {bstar_id} overlaps earlier valid B* "
                    + ",".join(str(member) for member in sorted(overlap)),
                )
            occupied.update(members)
            max_occupied_members = max(max_occupied_members, len(occupied))
    return {
        "invariant": COMPOSITE_ROW_INVARIANT,
        "checked_bstar_cells": checked_bstar_cells,
        "valid_bstar_cells": valid_bstar_cells,
        "max_occupied_members": max_occupied_members,
        "checker_scope": "NON_PRODUCTION_64_MIB_FIXTURE_CAP",
    }


def logical_digest(
    rows: int, primitive_count: int, bstar_count: int, species: bytes,
    genes: bytes, primitive: bytes, bstar: bytes, numeric_registry: bytes,
    state: bytes, numeric: bytes, validity: bytes
) -> bytes:
    stream = bytearray(b"SplitAlignerR/MatrixLogicalContent/v1\0")
    stream += enc16(1) + enc16(0)
    stream += enc64(rows) + enc64(primitive_count) + enc64(bstar_count)
    stream += enc64(checked_add(primitive_count, bstar_count,
                                "logical numeric coordinate count"))
    stream += species + genes + primitive + bstar + numeric_registry
    stream += length_prefix(state) + length_prefix(numeric) + length_prefix(validity)
    return digest(bytes(stream))


def parse_footer(
    raw: bytes, component_bytes: dict[str, bytes], logical: bytes,
    species: bytes, genes: bytes, primitive: bytes, bstar: bytes,
    numeric: bytes, rows: int, primitive_count: int, bstar_count: int
) -> None:
    if len(raw) != FOOTER_BYTES or raw[:8] != b"SARFT001":
        fail("E3_FOOTER", "magic/length")
    if (le16(raw, 8), le16(raw, 10), le16(raw, 12), le16(raw, 14), le32(raw, 16)) != (
        1, 0, 512, 0, 4
    ):
        fail("E3_FOOTER", "schema/count")
    require_zero(raw, 20, 32, "footer reserved 20")
    require_zero(raw, 426, 512, "footer reserved 426")
    names = ["STATE.bin", "NUMERIC.bin", "VALIDITY.bin", "TILE_INDEX.bin"]
    for index, name in enumerate(names):
        if le64(raw, 32 + index * 8) != len(component_bytes[name]):
            fail("E3_FOOTER", f"length {name}")
        if raw[64 + index * 32:96 + index * 32] != digest(component_bytes[name]):
            fail("E3_FOOTER", f"hash {name}")
    if raw[192:224] != logical:
        fail("E3_LOGICAL_HASH", "footer")
    if raw[224:256] != species or raw[256:288] != genes or raw[288:320] != primitive:
        fail("E3_AUTHORITY", "footer base registry")
    if raw[320:352] != bstar or raw[352:384] != numeric:
        fail("E3_AUTHORITY", "footer composite registry")
    if (le64(raw, 384), le64(raw, 392), le64(raw, 400), le64(raw, 408)) != (
        rows, primitive_count, bstar_count,
        checked_add(primitive_count, bstar_count, "footer numeric coordinate count")
    ):
        fail("E3_FOOTER", "dimensions")
    if le32(raw, 416) != TILE_ROWS or le32(raw, 420) != TILE_COLS or le16(raw, 424) != 1:
        fail("E3_FOOTER", "layout")


def validate(store: Path, registry_path: Path, phase: str) -> dict:
    if phase not in (PREPUBLICATION_BYTES, PUBLISHED_STORE):
        fail("E3_PHASE", phase)
    registry_snapshot = {}
    registry = load_registry(registry_path, snapshot_out=registry_snapshot)
    species = species_digest(registry)
    primitive = species
    genes = gene_digest(registry["gene_ids"])
    encoded = member_encodings(registry)
    bstar = bstar_digest(primitive, encoded)
    numeric_registry = numeric_digest(primitive, len(registry["primitive_entries"]), bstar, encoded)

    # External authority is fully validated before any matrix component bytes
    # are accepted or read by this tiny fixture checker.
    store_descriptor = open_store_directory(store)
    directory_stat = os.fstat(store_descriptor)
    initial_directory_identity = directory_identity(directory_stat)
    file_identities = {}
    try:
        expected_names = exact_store_entries(store_descriptor, phase)
        files = {
            name: read_regular_at(
                store_descriptor, name, identity_out=file_identities
            )
            for name in expected_names
        }
    finally:
        os.close(store_descriptor)

    rows = len(registry["gene_ids"])
    primitive_count = len(registry["primitive_entries"])
    bstar_count = len(encoded)
    numeric_count = checked_add(primitive_count, bstar_count,
                                "numeric coordinate count")
    headers = {
        1: parse_data_header(files["STATE.bin"], b"SARST001", 1, 1, primitive,
                             species, genes),
        2: parse_data_header(files["NUMERIC.bin"], b"SARNM001", 2, 2,
                             numeric_registry, species, genes),
        3: parse_data_header(files["VALIDITY.bin"], b"SARVL001", 3, 3,
                             numeric_registry, species, genes),
    }
    if headers[1]["rows"] != rows or headers[2]["rows"] != rows or headers[3]["rows"] != rows:
        fail("E3_GENE_AXIS", "row count")
    if headers[1]["columns"] != primitive_count:
        fail("E3_PRIMITIVE_PREFIX", "state columns")
    if headers[2]["columns"] != numeric_count or headers[3]["columns"] != headers[2]["columns"]:
        fail("E3_NUMERIC_AXIS", "numeric/validity columns")
    index_header = parse_index_header(
        files["TILE_INDEX.bin"], species, genes, primitive, bstar, numeric_registry
    )
    if (index_header["rows"], index_header["primitive"], index_header["bstar"],
        index_header["numeric"]) != (rows, primitive_count, bstar_count,
                                      numeric_count):
        fail("E3_INDEX", "registry dimensions")
    component_by_type = {1: files["STATE.bin"], 2: files["NUMERIC.bin"],
                         3: files["VALIDITY.bin"]}
    entries = parse_entries(files["TILE_INDEX.bin"], headers, component_by_type)
    primitive_row_consistency = validate_primitive_row_consistency(
        headers, entries, registry["primitive_entries"]
    )
    state, numeric_stream, validity = reconstruct(headers, entries)
    composite_row_consistency = validate_composite_row_consistency(
        headers, registry, state, validity
    )
    logical = logical_digest(rows, primitive_count, bstar_count, species, genes,
                             primitive, bstar, numeric_registry, state,
                             numeric_stream, validity)
    parse_footer(files["COMPLETION.bin"], files, logical, species, genes,
                 primitive, bstar, numeric_registry, rows, primitive_count,
                 bstar_count)
    if phase == PUBLISHED_STORE:
        manifest = parse_manifest(files["VALIDATED"])
        authority_pairs = {
            "species_authority_sha256": species,
            "gene_registry_sha256": genes,
            "primitive_registry_sha256": primitive,
            "bstar_registry_sha256": bstar,
            "numeric_coordinate_registry_sha256": numeric_registry,
        }
        for key, expected in authority_pairs.items():
            if bytes.fromhex(manifest[key]) != expected:
                fail("E3_AUTHORITY", f"manifest {key}")
        if bytes.fromhex(manifest["logical_content_sha256"]) != logical:
            fail("E3_LOGICAL_HASH", "manifest")
        manifest_pairs = {
            "STATE.bin": ("state_bytes", "state_sha256"),
            "NUMERIC.bin": ("numeric_bytes", "numeric_sha256"),
            "VALIDITY.bin": ("validity_bytes", "validity_sha256"),
            "TILE_INDEX.bin": ("index_bytes", "index_sha256"),
            "COMPLETION.bin": ("footer_bytes", "footer_sha256"),
        }
        for name, (length_key, digest_key) in manifest_pairs.items():
            if int(manifest[length_key]) != len(files[name]):
                fail("E3_MANIFEST_VALUE", f"length {name}")
            if manifest[digest_key] != digest(files[name]).hex():
                fail("E3_MANIFEST_VALUE", f"hash {name}")
        if (int(manifest["row_count"]), int(manifest["primitive_count"]),
            int(manifest["bstar_count"]), int(manifest["numeric_coordinate_count"])) != (
            rows, primitive_count, bstar_count, numeric_count
        ):
            fail("E3_MANIFEST_VALUE", "dimensions")
    verify_store_snapshot(
        store, phase, initial_directory_identity, file_identities
    )
    verify_external_snapshot(registry_path, registry_snapshot)
    return {
        "status": ("PREPUBLICATION_BYTES_VALID" if phase == PREPUBLICATION_BYTES
                   else "PUBLISHED_VALIDATED"),
        "phase": phase,
        "rows": rows,
        "primitive_count": primitive_count,
        "bstar_count": bstar_count,
        "primitive_row_consistency": primitive_row_consistency,
        "composite_row_consistency": composite_row_consistency,
        "species_authority_sha256": species.hex(),
        "logical_content_sha256": logical.hex(),
        "physical_sha256": {name: digest(value).hex() for name, value in files.items()},
    }


def main() -> None:
    global READ_LOOP_TEST_DELAY_SECONDS, READ_LOOP_TEST_READY_PATH
    global READ_LOOP_TEST_READY_LABEL
    parser = argparse.ArgumentParser()
    parser.add_argument("--store", required=True, type=Path)
    parser.add_argument("--registry", required=True, type=Path)
    parser.add_argument("--phase", choices=(PREPUBLICATION_BYTES, PUBLISHED_STORE),
                        default=PUBLISHED_STORE)
    parser.add_argument("--test-read-delay-ms", type=float, default=0.0,
                        help=argparse.SUPPRESS)
    parser.add_argument("--test-read-ready-path", type=Path, help=argparse.SUPPRESS)
    parser.add_argument("--test-read-ready-label", help=argparse.SUPPRESS)
    args = parser.parse_args()
    if not 0.0 <= args.test_read_delay_ms <= 1000.0:
        raise SystemExit("test read delay must be between 0 and 1000 ms")
    READ_LOOP_TEST_DELAY_SECONDS = args.test_read_delay_ms / 1000.0
    if (args.test_read_ready_path is None) != (args.test_read_ready_label is None):
        raise SystemExit("test read-ready path and label must be supplied together")
    if args.test_read_ready_path is not None and args.test_read_ready_path.exists():
        raise SystemExit("test read-ready path must not exist")
    READ_LOOP_TEST_READY_PATH = args.test_read_ready_path
    READ_LOOP_TEST_READY_LABEL = args.test_read_ready_label
    try:
        result = validate(args.store, args.registry, args.phase)
    except ValidationError as error:
        print(str(error))
        raise SystemExit(1)
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
