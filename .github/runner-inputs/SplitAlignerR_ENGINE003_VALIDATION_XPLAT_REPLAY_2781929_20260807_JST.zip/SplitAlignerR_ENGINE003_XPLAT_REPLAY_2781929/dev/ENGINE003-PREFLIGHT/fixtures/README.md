# Tiny golden fixtures

These files are synthetic ENGINE003-PREFLIGHT review fixtures. They are not
scientific outputs and are not a production store.

`tiny_store/` contains exactly the six authoritative candidate components for:

```text
genes:                 3
primitive coordinates: 5
composite coordinates: 2
numeric coordinates:   7
physical layout:       provisional 256 × 256 tiled
```

The tiny authority contains four terminal primitives (`01`, `02`, `04`,
`08`) and the internal canonical split `03|0c`. Its three rows jointly cover
Mapped with valid numeric evidence, Mapped without numeric evidence, terminal
`NA_struct` without evidence, terminal `NA_fuse` without evidence, internal
`NA_topo` without evidence, and a primitive `NA_fuse` whose independent B*
coordinate remains available. It also contains two simultaneously valid,
disjoint composites; a fully fused but unavailable B*; and a mapped primitive
outside every valid B*. This is the positive `PrimitiveRowConsistency-v1` and
`CompositeRowConsistency-v1` fixture. B* validity is not inferred in reverse
from `NA_fuse`, but an available B* is bound to its exact fusion fiber.

`registry_input.json` is the strict external synthetic authority descriptor
used by the independent checker. Taxon labels are canonical lowercase hex for
their exact raw bytes (`41` for ASCII `A`); they are never reinterpreted as
Unicode. The descriptor is deliberately outside `tiny_store/`; real stores
bind external frozen run authorities rather than trusting labels inside the
store.

Two additional zero-axis stores exercise the storage-layer D10 boundary:

```text
zero_rows_store:    0 genes, 5 primitives, 2 composites, zero tiles
zero_columns_store: 3 genes, 0 primitives, 0 composites, zero tiles
```

Both retain headers, an empty index, completion footer, and `VALIDATED`
manifest, and both pass the independent checker. Their external descriptors are
`zero_rows_registry.json` and `zero_columns_registry.json`.

`validity_vectors.tsv` contains independent LSB-first boundary cases for 1, 7,
8, 9, 63, 64, and 65 logical cells.

FIX001 adds four store-level boundary fixtures:

```text
one_cell_store:   1 row, 1 primitive, 0 B*, one logical cell
exact_256_store:  256 rows, 256 primitives, exact one-tile boundary
multi_257_store:  257 rows, 257 primitives, 2 B*, multiple tile rows/columns
bstar_u32le_store: 257 rows, 301 primitives, 2 B*, byte-vs-integer order torture
```

`multi_257_store` exercises nonzero tile offsets, edge padding, logical
state/numeric/validity continuity, and B* member ordering with primitive ID 256
encoded as u32 little-endian bytes. Corresponding external descriptors are
`one_cell_registry.json`, `exact_256_registry.json`, and
`multi_257_registry.json`. `bstar_u32le_store` orders `[256,257]` before
`[255,300]` because exact u32le bytes begin `00` versus `ff`; an incorrect
integer-list comparator would reverse them. Its descriptor is
`bstar_u32le_registry.json`.

Regeneration must use `reference/encode_tiny_fixture.py` or
`reference/encode_boundary_fixture.py` into an empty target. Validation must use
`independent/check_tiny_store.py`; the checker does not import either encoder.
All committed stores are published-form fixtures with exactly six entries.
`run_phase_cases.py` makes a disposable five-binary copy to prove the distinct
prepublication behavior.

The frozen logical-content digest for the current fixture is:

```text
66384a9a7c4e2213a5140d1b161de80abd3f23ff4b9d79251da83623a06d8471
```

Zero-axis logical digests:

```text
zero rows:    72f77f4bdb15dab015346fcd2d13663b7cdcb3a4d252bfcc79e5ac02afb38db8
zero columns: cef607d26385658d99831ed9e1ed3c8b5c06eda4a2169294b0697d1935bd1bdc
```

Boundary logical digests:

```text
one cell:  a94857b83f0d908f7f9093715ca83599033bb94e34208de2cc321f81986e6501
exact 256: f93691dfbfeb975b64a43542a8f0a70dec9c4b8818ba73ecb4a51c006e0fd1b8
multi 257: 3121b7a3fbcb3c88fec69544d81276866f91253655a425e8e5c37858398248d5
B* u32le: 87253598e3c4249dab770f0d672b6b740492449264bf457029e5ed146eb3a09b
```

FIX002 adds `raw_ff_store/` and `raw_ff_registry.json`. Its first taxon is the
single raw byte `ff`, its second is `42`, and its two terminal splits are `01`
and `02`. The independent checker and frozen ENGINE002 implementation both
recover this exact SpeciesAuthority-v1 digest:

```text
591b83db63e8100d81f27959db30e3314ff213196cb0fa2f4f18dca3f1f8b838
```

Its logical-content digest is:

```text
f4ce03128c703505571808bbeeb6deac728d1c85748a5255f136bc2fec6a1551
```

FIX004 regenerates every affected semantic fixture through both reference
row-admission gates. Two separate empty target trees are compared byte-for-byte
before publication; all eight stores pass the independent published-store
checker, including both row invariants over their complete logical axes. The
zero-column fixture remains the intentional empty-axis case.

`stage_a_v3_descriptors/` contains the four complete, no-timing descriptors
for the executable `ENGINE003_STAGE_A_FIBER_CONSISTENT_BITS_V3` oracle. They are
not MatrixStore outputs and are excluded from the store directory grammar.
