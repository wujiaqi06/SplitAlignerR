#!/usr/bin/env python3
"""Platform-neutral ENGINE003 byte/parser replay (diagnostic evidence only)."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import platform
import subprocess
import sys
import tempfile
from pathlib import Path


SCRIPT = Path(__file__).resolve()
ROOT = SCRIPT.parents[1]
FIXTURES = ROOT / "fixtures"
INDEPENDENT = ROOT / "independent"
REFERENCE = ROOT / "reference"

FIXTURE_CASES = (
    ("tiny", "tiny", "tiny_store", "registry_input.json", "tiny"),
    ("zero_rows", "tiny", "zero_rows_store", "zero_rows_registry.json", "zero_rows"),
    ("zero_columns", "tiny", "zero_columns_store", "zero_columns_registry.json", "zero_columns"),
    ("raw_ff", "tiny", "raw_ff_store", "raw_ff_registry.json", "raw_ff"),
    ("one_cell", "boundary", "one_cell_store", "one_cell_registry.json", "one_cell"),
    ("exact_256", "boundary", "exact_256_store", "exact_256_registry.json", "exact_256"),
    ("multi_257", "boundary", "multi_257_store", "multi_257_registry.json", "multi_257"),
    ("bstar_u32le", "boundary", "bstar_u32le_store", "bstar_u32le_registry.json", "bstar_u32le"),
)


def sha256(path: Path) -> str:
    hasher = hashlib.sha256()
    with path.open("rb") as handle:
        while True:
            value = handle.read(1024 * 1024)
            if not value:
                break
            hasher.update(value)
    return hasher.hexdigest()


def run(command: list[str], timeout: int = 180) -> subprocess.CompletedProcess:
    result = subprocess.run(
        command, check=False, capture_output=True, text=True, timeout=timeout,
        env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"},
    )
    if result.returncode != 0:
        raise RuntimeError(
            f"command failed rc={result.returncode}: {' '.join(command)}\n"
            f"stdout:\n{result.stdout}\nstderr:\n{result.stderr}"
        )
    return result


def verify_fixture_manifest() -> tuple[int, str]:
    manifest = FIXTURES / "FIXTURE_SHA256SUMS"
    checked = 0
    for line in manifest.read_text(encoding="ascii").splitlines():
        expected, relative = line.split("  ", 1)
        path = FIXTURES / relative
        if not path.is_file() or sha256(path) != expected:
            raise RuntimeError(f"fixture manifest mismatch: {relative}")
        checked += 1
    return checked, sha256(manifest)


def compare_tree(expected: Path, observed: Path) -> tuple[int, str]:
    expected_files = sorted(
        path.relative_to(expected).as_posix() for path in expected.rglob("*") if path.is_file()
    )
    observed_files = sorted(
        path.relative_to(observed).as_posix() for path in observed.rglob("*") if path.is_file()
    )
    if expected_files != observed_files:
        raise RuntimeError("regenerated wire-format file set mismatch")
    hasher = hashlib.sha256()
    for relative in expected_files:
        left, right = expected / relative, observed / relative
        if left.read_bytes() != right.read_bytes():
            raise RuntimeError(f"regenerated wire-format bytes mismatch: {relative}")
        hasher.update(relative.encode("utf-8") + b"\0" + bytes.fromhex(sha256(left)))
    return len(expected_files), hasher.hexdigest()


def write_tsv(path: Path, rows: list[dict[str, object]]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def generate_case(kind: str, profile: str, store: Path, descriptor: Path) -> None:
    if kind == "tiny":
        command = [
            sys.executable, "-B", str(REFERENCE / "encode_tiny_fixture.py"),
            "--profile", profile, "--store", str(store), "--registry", str(descriptor),
        ]
    else:
        command = [
            sys.executable, "-B", str(REFERENCE / "encode_boundary_fixture.py"),
            "--profile", profile, "--store", str(store), "--registry", str(descriptor),
        ]
    run(command)


def replay_case(case_id: str, kind: str, committed_store: str,
                committed_descriptor: str, profile: str, temp: Path) -> dict[str, object]:
    regenerated_root = temp / case_id
    regenerated_store = regenerated_root / "store"
    regenerated_descriptor = regenerated_root / "descriptor.json"
    generate_case(kind, profile, regenerated_store, regenerated_descriptor)
    expected_store = FIXTURES / committed_store
    expected_descriptor = FIXTURES / committed_descriptor
    count, aggregate = compare_tree(expected_store, regenerated_store)
    if expected_descriptor.read_bytes() != regenerated_descriptor.read_bytes():
        raise RuntimeError(f"regenerated descriptor bytes mismatch: {case_id}")
    checker_output = temp / f"{case_id}_bounded_checker.json"
    run([
        sys.executable, "-B", str(INDEPENDENT / "check_bounded_store.py"),
        "--store", str(expected_store), "--descriptor", str(expected_descriptor),
        "--portable-trusted-byte-replay", "--output", str(checker_output),
    ])
    result = json.loads(checker_output.read_text(encoding="utf-8"))
    if result["status"] != "BOUNDED_PREFLIGHT_CHECKER_PASS" or result["pass_count"] != 11:
        raise RuntimeError(f"bounded checker did not pass: {case_id}")
    return {
        "case_id": case_id,
        "fixture_manifest_status": "PASS",
        "regenerated_wire_bytes": "IDENTICAL",
        "compared_store_files": count,
        "wire_aggregate_sha256": aggregate,
        "descriptor_bytes": "IDENTICAL",
        "descriptor_sha256": sha256(expected_descriptor),
        "logical_reconstruction": "PASS",
        "logical_content_sha256": result["logical_content_sha256"],
        "bounded_checker_passes": result["pass_count"],
        "checker_input_mode": result["input_mode"],
        "durability_claim": "NONE_PORTABLE_REPLAY_ONLY",
    }


def make_sha256sums(output: Path) -> int:
    paths = sorted(
        path for path in output.iterdir()
        if path.is_file() and path.name != "SHA256SUMS"
    )
    text = "".join(f"{sha256(path)}  {path.name}\n" for path in paths)
    (output / "SHA256SUMS").write_text(text, encoding="ascii")
    return len(paths)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", required=True, type=Path)
    args = parser.parse_args()
    if args.output_dir.exists():
        raise SystemExit("refusing to overwrite an existing replay output directory")
    args.output_dir.mkdir(parents=True)
    fixture_count, fixture_manifest_sha = verify_fixture_manifest()
    with tempfile.TemporaryDirectory(prefix="e3-xplat-replay-") as temporary:
        temp = Path(temporary)
        rows = [replay_case(*case, temp) for case in FIXTURE_CASES]
        write_tsv(args.output_dir / "WIRE_REPLAY_RESULTS.tsv", rows)
        run([
            sys.executable, "-B", str(INDEPENDENT / "run_descriptor_byte_cases.py"),
            "--output", str(args.output_dir / "DESCRIPTOR_BYTE_CASE_RESULTS.tsv"),
            "--python", sys.executable,
        ])
        validity = run([
            sys.executable, "-B", str(INDEPENDENT / "check_validity_vectors.py"),
            str(FIXTURES / "validity_vectors.tsv"),
        ])
        authority = run([
            sys.executable, "-B", str(REFERENCE / "run_encoder_authority_cases.py"),
            "--output", str(args.output_dir / "AUTHORITY_VECTOR_RESULTS.tsv"),
        ])
    metadata = {
        "status": "XPLAT_BYTE_PARSER_REPLAY_PASS",
        "evidence_scope": "HOSTED_OR_LOCAL_DIAGNOSTIC_NOT_DURABILITY_CERTIFICATION",
        "platform": platform.platform(),
        "system": platform.system(),
        "machine": platform.machine(),
        "python_implementation": platform.python_implementation(),
        "python_version": platform.python_version(),
        "fixture_manifest_sha256": fixture_manifest_sha,
        "fixture_manifest_entries_verified": fixture_count,
        "wire_cases_passed": len(rows),
        "wire_cases_failed": 0,
        "descriptor_byte_corpus": "PASS",
        "validity_vectors": validity.stdout.strip(),
        "authority_vectors": authority.stdout.strip(),
        "logical_hash_reconstruction": "PASS_ALL_WIRE_CASES",
        "wire_format_byte_equality": "PASS_ALL_WIRE_CASES",
        "windows_durability_interpretation": (
            "A_WINDOWS_REPLAY_PASS_DOES_NOT_ESTABLISH_DURABLE_PUBLISH_V1"
        ),
        "timing_executed": False,
    }
    (args.output_dir / "RUN_METADATA.json").write_text(
        json.dumps(metadata, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    count = make_sha256sums(args.output_dir)
    print(json.dumps({**metadata, "evidence_files_hashed": count}, sort_keys=True))


if __name__ == "__main__":
    main()
