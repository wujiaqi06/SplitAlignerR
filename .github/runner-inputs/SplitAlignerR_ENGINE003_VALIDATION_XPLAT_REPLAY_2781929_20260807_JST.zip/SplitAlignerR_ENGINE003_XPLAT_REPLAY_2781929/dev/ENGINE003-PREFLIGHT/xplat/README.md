# Platform-neutral replay

Run from any checkout of the reviewed commit with standard-library Python:

```text
python -B dev/ENGINE003-PREFLIGHT/xplat/run_xplat_replay.py \
  --output-dir <new-empty-output-directory>
```

The command performs no timing and writes five evidence files. The output
directory must not already exist. Preserve it byte-for-byte and report the
runtime, commit and external run identifier alongside its `SHA256SUMS`.

This replay intentionally uses `PORTABLE_TRUSTED_BYTE_REPLAY_ONLY`. It proves
golden fixture identity, parser vectors, logical-hash reconstruction and wire
byte equality. It does not prove safe opening of an untrusted store, filesystem
publication atomicity, crash durability, or Windows `DURABLE_PUBLISH_V1`.

Required platform rows for the checkpoint are Linux, macOS and Windows. Do not
merge their raw outputs or convert a missing row to PASS.
